<?php

$MESS['INSTALLATION_INSTRUCTIONS'] = "Чтобы установить приложение, в меню браузера найдите «Добавить на главный экран».";
$MESS['INSTALL_APP'] = "Установите приложение";
$MESS['INSTALLATION_TITLE'] = "Установите Сотбит: Розница";
$MESS['INSTALLATION_SUBTITLE'] = "Всего за два шага";
$MESS['INSTALLATION_DESCRIPTION'] = 'Нажмите на иконку “Поделиться” <img loading="lazy" src="' . SITE_TEMPLATE_PATH . '/assets/image/share_arrow_up.svg" alt="Поделиться"> внизу экрана, пролистайте вниз и выберите <img loading="lazy" src="'. SITE_TEMPLATE_PATH . '/assets/image/plus.svg" alt="Плюс">  На экран “Домой”';
$MESS['INSTALL_APP_POPUP_DISMISS'] = "Закрыть";
$MESS['INSTALL_APP_POPUP_LOGO'] = "Логотип";
$MESS['INSTALL_APP_IOS'] = "Установить приложение на iOS";
$MESS['INSTALL_APP_ANDROID'] = "Установить приложение на Android";
$MESS['INSTALL_APP_AVAILABILITY'] = "Приложение доступно для мобильных устройств";