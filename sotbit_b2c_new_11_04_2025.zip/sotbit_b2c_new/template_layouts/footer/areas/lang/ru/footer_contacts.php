<?php

$MESS['PHONE'] = 'Телефон';
$MESS['ADDRESS'] = 'Адрес';