<?php

$MESS["INSTALLATION_INSTRUCTIONS"] = "To install the application, find 'Add to Home Screen' in the browser menu.";
$MESS["INSTALL_APP"] = "Install the application";
$MESS["INSTALLATION_TITLE"] = "Install Sothebit: Retail";
$MESS["INSTALLATION_SUBTITLE"] = "In just two steps";
$MESS["INSTALLATION_DESCRIPTION"] = "Click on the 'Share' icon<img loading=\"lazy\" src=\"/bitrix/templates/sotbit_b2c/assets/image/share_arrow_up.svg\" alt=\"Share\" loading=\"lazy\"> at the bottom of the screen, scroll down and select<img loading=\"lazy\" src=\"/bitrix/templates/sotbit_b2c/assets/image/plus.svg\" alt=\"Plus\" loading=\"lazy\"> To the Home screen";
$MESS["INSTALL_APP_POPUP_DISMISS"] = "Close";
$MESS["INSTALL_APP_POPUP_LOGO"] = "Logo";
$MESS["INSTALL_APP_IOS"] = "Install the application on iOS";
$MESS["INSTALL_APP_ANDROID"] = "Install the application on Android";
$MESS["INSTALL_APP_AVAILABILITY"] = "The application is available for mobile devices";