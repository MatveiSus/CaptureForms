<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Application, File\Image as ImageFile};
use Sotbit\B2C\{Helper\Config, Public\Image};

global $site;

$logoSrc = Config::getLogo('FOOTER', SITE_ID);
$siteName = Application::getInstance()->getContext()->getSiteObject()->getSiteName();

if ($logoSrc) {
    $logoImage = new ImageFile(Application::getDocumentRoot() . $logoSrc);

    if ($logoImage->load()) {
        $logoImageWidth = $logoImage->getWidth();
        $logoImageHeight = $logoImage->getHeight();
    } ?>
    <div class="footer__logo-container">
        <?php
        $imageElement = Image::loadLazy(
            $logoSrc,
            $siteName,
            [
                'IMAGE' => [
                    'class' => 'footer__logo-image',
                    'width' => $logoImageWidth,
                    'height' => $logoImageHeight,
                ]
            ]
        );

        $logoLink = Config::getLogoLink();

        if ($logoLink) { ?>
            <a class="footer__image-container"
               href="<?= $logoLink ?>"
               title="<?= $siteName ?>"
            >
                <?= $imageElement ?>
            </a>
            <?php
        } else { ?>
            <div class="footer__image-container"
                 title="<?= $siteName ?>"
            >
                <?= $imageElement ?>
            </div>
            <?php
        } ?>
    </div>
    <?php
}
