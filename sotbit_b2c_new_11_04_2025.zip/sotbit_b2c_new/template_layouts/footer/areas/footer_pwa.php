<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Application, Localization\Loc, Web\Json};
use Sotbit\B2C\Public\Image;

if (Application::getInstance()->getContext()->getRequest()->getCookieRaw('IS_MOBILE_APP') === 'true') {
    return;
}

?>

<div class="install-PWA">
    <p class="install-PWA__title"><?= Loc::getMessage("INSTALL_APP") ?></p>
    <div class="install-PWA__btns">
        <div id="installPwaAndroid" class="install-PWA__btn">
            <?= Image::loadLazy(
                SITE_TEMPLATE_PATH . "/assets/image/android.svg",
                Loc::getMessage("INSTALL_APP_ANDROID"),
                [
                    'CONTAINER' => [
                        'class' => 'install-PWA__image'
                    ],
                    'LOADER' => [
                        'style' => 'transform: scale(3);'
                    ]
                ]
            ) ?>
        </div>
        <div id="installPwaIos" class="install-PWA__btn">
            <?= Image::loadLazy(
                SITE_TEMPLATE_PATH . "/assets/image/ios.svg",
                Loc::getMessage("INSTALL_APP_IOS"),
                [
                    'CONTAINER' => [
                        'class' => 'install-PWA__image'
                    ],
                    'LOADER' => [
                        'style' => 'transform: scale(3);'
                    ]
                ]
            ) ?>
        </div>
    </div>
</div>

<div id="popup-PWA-IOS" class="popup-PWA-IOS">
    <div class="popup-PWA-IOS__wrap">
        <button id="closePopupIos" class="popup-PWA-IOS__close">
            <img src="<?= SITE_TEMPLATE_PATH . "/assets/image/Dismiss.svg" ?>"
                 alt="<?= Loc::getMessage('INSTALL_APP_POPUP_DISMISS') ?>"
                 width="16"
                 height="16"
                 loading="lazy"
            >
        </button>
        <img class="popup-PWA-IOS__logo"
             src="<?= SITE_TEMPLATE_PATH . "/assets/image/icon-512x512.png" ?>"
             alt="<?= Loc::getMessage("INSTALL_APP_POPUP_LOGO") ?>"
             width="100"
             height="100"
             loading="lazy"
        >
        <h2 class="popup-PWA-IOS__title"><?= Loc::getMessage("INSTALLATION_TITLE") ?></h2>
        <span class="popup-PWA-IOS__subtitle"><?= Loc::getMessage("INSTALLATION_SUBTITLE") ?></span>
        <p class="popup-PWA-IOS__description"><?= Loc::getMessage("INSTALLATION_DESCRIPTION") ?></p>
    </div>
</div>

<script>
    BX.message(<?= Json::encode(Loc::loadLanguageFile(__FILE__)) ?>);
</script>
