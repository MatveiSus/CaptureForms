<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\{Helper\Config, Helper\Modules, Public\Icon};

$address = Modules::useRegions() ? $_SESSION['SOTBIT_REGIONS']['UF_ADDRESS'] : Config::get(
    'CONTACTS_ADDRESS'
);
$phone = Modules::useRegions() ? $_SESSION['SOTBIT_REGIONS']['UF_PHONE'][0] : current(
    Config::get('CONTACTS_PHONE')
)['PHONE'];
?>

<ul class="footer__contacts">
    <?php
    if ($phone) { ?>
        <li class="footer__contact">
            <svg class="footer__contact-icon" width="32" height="32">
                <use xlink:href="<?= Icon::get('phone') ?>"></use>
            </svg>
            <div class="footer__contact-info">
                <span class="footer__contact-title"><?= Loc::getMessage('PHONE') ?></span>
                <a href="tel:<?= str_replace(' ', '', $phone) ?>" class="footer__contact-value"><?= $phone ?></a>
            </div>
        </li>
        <?php
    } ?>

    <?php
    if ($address) { ?>
        <li class="footer__contact">
            <svg class="footer__contact-icon" width="32" height="32">
                <use xlink:href="<?= Icon::get('location') ?>"></use>
            </svg>
            <div class="footer__contact-info">
                <span class="footer__contact-title"><?= Loc::getMessage('ADDRESS') ?></span>
                <span class="footer__contact-value"><?= $address ?></span>
            </div>
        </li>
        <?php
    } ?>
</ul>
