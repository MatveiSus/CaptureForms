<?php

$MESS['FOOTER_2_TITLE'] = 'Футер 2';
