<?php

$MESS['FOOTER_2_TITLE'] = 'Footer 2';
