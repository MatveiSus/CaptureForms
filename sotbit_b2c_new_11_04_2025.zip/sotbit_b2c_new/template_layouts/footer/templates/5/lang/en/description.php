<?php

$MESS['FOOTER_5_TITLE'] = 'Footer 5';
