<?php

$MESS['FOOTER_5_TITLE'] = 'Футер 5';
