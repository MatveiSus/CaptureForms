<?php

$MESS['FOOTER_1_TITLE'] = 'Footer 1';
