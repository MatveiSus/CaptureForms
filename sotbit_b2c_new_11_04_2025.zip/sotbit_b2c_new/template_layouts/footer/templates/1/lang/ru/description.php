<?php

$MESS['FOOTER_1_TITLE'] = 'Футер 1';
