<?php

$MESS['FOOTER_3_TITLE'] = 'Footer 3';
