<?php

$MESS['FOOTER_3_TITLE'] = 'Футер 3';
