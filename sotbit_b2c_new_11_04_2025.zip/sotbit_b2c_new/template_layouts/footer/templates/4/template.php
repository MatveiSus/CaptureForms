<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{
    Application,
    Config\Option,
    Page\Asset
};
use Sotbit\B2C\Helper\Config;

global $APPLICATION;

$useMinifiedAssets = Option::get('main', 'use_minified_assets', 'N') === 'Y';
$areasFolderPath = Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/template_layouts/footer/areas';

Asset::getInstance()->addCss(
    SITE_TEMPLATE_PATH . '/template_layouts/footer/templates/4/style' . ($useMinifiedAssets ? '.min' : '') . '.css'
);
?>

<footer class="footer footer--4 container container-footer">
    <div class="footer__logo">
        <?php
        include($areasFolderPath . '/footer_logo.php') ?>
    </div>

    <div class="footer__description">
        <?php
        $APPLICATION->IncludeComponent(
            "bitrix:main.include",
            "",
            array(
                "AREA_FILE_SHOW" => "file",
                "PATH" => SITE_TEMPLATE_PATH . "/include/footer/description.php",
            )
        ); ?>
    </div>

    <div class="footer__menu-wrapper footer__menu-wrapper--buyers">
        <span class="footer__menu-title">
            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:main.include",
                "",
                array(
                    "AREA_FILE_SHOW" => "file",
                    "PATH" => SITE_TEMPLATE_PATH . "/include/footer/menu_buyers.php",
                )
            ); ?>
        </span>

        <?php
        $APPLICATION->IncludeComponent(
            "bitrix:menu",
            "footer_menu",
            array(
                "ROOT_MENU_TYPE" => "sotbit_b2c_footer_buyers",
                "MAX_LEVEL" => "1",
            )
        ); ?>
    </div>

    <div class="footer__menu-wrapper footer__menu-wrapper--company">
        <span class="footer__menu-title">
            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:main.include",
                "",
                array(
                    "AREA_FILE_SHOW" => "file",
                    "PATH" => SITE_TEMPLATE_PATH . "/include/footer/menu_company.php",
                )
            ); ?>
        </span>

        <?php
        $APPLICATION->IncludeComponent(
            "bitrix:menu",
            "footer_menu",
            array(
                "ROOT_MENU_TYPE" => "sotbit_b2c_footer_company",
                "MAX_LEVEL" => "1",
            )
        ); ?>
    </div>

    <div class="footer__contacts-wrapper">
        <?php
        include($areasFolderPath . '/footer_contacts.php') ?>
    </div>

    <div class="footer__pwa">
        <?php
        include($areasFolderPath . '/footer_pwa.php') ?>
    </div>

    <div class="footer__bottom">
        <div class="footer__bottom-inner">
            <?php
            $APPLICATION->IncludeFile(
                SITE_TEMPLATE_PATH . '/include/footer/copyright.php',
                [],
                [
                    'MODE' => 'php'
                ]
            ) ?>

            <div class="footer__socnet">
                <?php
                $APPLICATION->IncludeComponent(
                    "bitrix:eshop.socnet.links",
                    ".default",
                    array(
                        "COMPONENT_TEMPLATE" => ".default",
                        "FACEBOOK" => Config::get('FACEBOOK_URL'),
                        "VKONTAKTE" => Config::get('VKONTAKTE_URL'),
                        "TWITTER" => Config::get('TWITTER_URL'),
                        "GOOGLE" => Config::get('GOOGLE_URL'),
                        "INSTAGRAM" => Config::get('INSTAGRAM_URL'),
                        "LINKEDIN" => Config::get('LINKEDIN_URL'),
                        "YOUTUBE" => Config::get('YOUTUBE_URL'),
                        "TELEGRAM" => Config::get('TELEGRAM_URL'),
                        "VK_VIDEO" => Config::get('VK_VIDEO_URL'),
                        "RUTUBE" => Config::get('RUTUBE_URL')
                    ),
                    false
                );
                ?>
            </div>

            <?php
            $APPLICATION->IncludeFile(
                SITE_TEMPLATE_PATH . '/include/footer/vendor.php',
                [],
                [
                    'MODE' => 'php'
                ]
            ) ?>
        </div>
    </div>
</footer>
