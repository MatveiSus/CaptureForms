<?php

$MESS['FOOTER_4_TITLE'] = 'Footer 4';
