<?php

$MESS['FOOTER_4_TITLE'] = 'Футер 4';
