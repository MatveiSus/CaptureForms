<?php
$MESS["CONTACTS"] = "Contacts";
$MESS["CONTACTS_BUTTON_TEXT"] = "Request a call";
$MESS["FORM_SUCCESS"] = "<span class=\"fw-bold fs-3\">Thank you!</span><br> <span class=\"fw-medium\">Your call back request has been successfully sent!</span>";
