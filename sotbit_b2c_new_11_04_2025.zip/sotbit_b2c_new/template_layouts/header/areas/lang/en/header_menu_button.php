<?php
$MESS["CATALOG"] = "Catalog";
