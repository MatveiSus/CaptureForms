<?php

$MESS['CONTACTS'] = 'Контакты';
$MESS['CONTACTS_BUTTON_TEXT'] = 'Заказать звонок';
$MESS['FORM_SUCCESS'] = '<span class="fw-bold fs-3">Спасибо!</span><br><span class="fw-medium">Заявка на обратный звонок успешно отправлена!</span>';