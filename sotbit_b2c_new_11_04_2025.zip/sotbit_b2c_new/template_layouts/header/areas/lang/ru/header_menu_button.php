<?php

$MESS['CATALOG'] = 'Каталог';