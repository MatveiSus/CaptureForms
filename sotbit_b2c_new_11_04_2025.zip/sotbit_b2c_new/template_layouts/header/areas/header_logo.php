<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Application, Localization\Loc};
use Sotbit\B2C\Helper\Config;

Loc::loadMessages(__FILE__);

$headerLogoSrc = Config::getLogo('HEADER');
$mobileLogo = Config::get('LOGO_MOBILE');
$mobileLogoSrc = is_numeric($mobileLogo) ? CFile::GetPath($mobileLogo) : $mobileLogo;
$site = Application::getInstance()->getContext()->getSiteObject();

?>
<?if($headerLogoSrc){?>
<?= (Config::getLogoLink() ? '<a href="' . Config::getLogoLink() . '"' : '<span')
. ' title="'
. $site->getSiteName()
. '" class="header__logo">' ?>
    <picture>
        <?php
        if ($mobileLogoSrc) { ?>
            <source srcset="<?= $mobileLogoSrc ?>" media="(max-width: 1024px)">
            <?php
        } ?>
        <img class="header__logo-image" src="<?= $headerLogoSrc ?>" alt="<?= $site->getSiteName() ?>">
    </picture>
<?= Config::getLogoLink() ? '</a>' : '</span>';
}
