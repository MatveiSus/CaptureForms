<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Loader, Localization\Loc, Application};
$request = Application::getInstance()->getContext()->getRequest();

global $APPLICATION;

Loc::loadMessages(__FILE__);

if (Loader::includeModule('sotbit.notification')) {
    if ($request->getCookieRaw('IS_MOBILE_APP') === 'true') {
        $APPLICATION->IncludeComponent(
            'sotbit:notification.notice',
            'b2c',
            array()
        );
    }

    $APPLICATION->IncludeComponent(
	'sotbit:notification.notice.pwa',
	'b2c',
        array()
    );
}
