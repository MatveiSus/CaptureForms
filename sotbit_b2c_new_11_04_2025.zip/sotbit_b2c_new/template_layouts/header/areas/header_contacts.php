<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{
    Localization\Loc,
};
use Sotbit\B2C\Helper\{
    Config,
    Modules,
};
use Sotbit\B2C\Public\Icon;

Loc::loadMessages(__FILE__);

if (Config::get('CONTACTS_IS_ACTIVE') === 'Y') {
    $regionData = Modules::getRegionData();
    $showRegionData = Modules::useRegions() && $regionData !== null;
    $phoneData = $email = $workingHours = $address = [];

    if ($showRegionData) {
        if (is_array($regionData['UF_PHONE'])) {
            $phoneData = array_map(fn($item) => ['PHONE' => $item], $regionData['UF_PHONE']);
        }

        if (is_array($regionData['UF_EMAIL'])) {
            $email = implode('<br>', $regionData['UF_EMAIL']);
        }

        if (!empty($regionData['UF_WORKING_MODE'])) {
            $workingHours = $regionData['UF_WORKING_MODE'];
        }

        if (!empty($regionData['UF_ADDRESS'])) {
            $address = $regionData['UF_ADDRESS'];
        }
    }

    if (empty($phoneData)) {
        $phoneData = Config::get('CONTACTS_PHONE');
    }

    $phoneData = array_filter($phoneData, fn($e) => $e['PHONE'] !== '');
    $firstPhoneItem = reset($phoneData)['PHONE'];

    if (empty($email)) {
        $email = Config::get('CONTACTS_EMAIL');
    }

    if (empty($workingHours)) {
        $workingHours = Config::get('CONTACTS_WORKING_HOURS');
    }

    if (empty($address)) {
        $address = Config::get('CONTACTS_ADDRESS');
    }

    $firstContactItem = htmlspecialcharsEx($firstPhoneItem ?: $email ?: $address ?: $workingHours);
    $firstContactItemIcon = $firstContactItemAttributes = null;

    switch ($firstContactItem) {
        case $firstPhoneItem:
            $htmlPhone = str_replace(' ', '', $firstContactItem);
            $firstContactItemAttributes = " href=\"tel:$htmlPhone\"";
            $firstContactItemIcon = 'phone';
            break;
        case $email:
            $firstContactItemAttributes = " href=\"mailto:$firstContactItem\"";
            $firstContactItemIcon = 'envelope';
            break;
        case $address:
            $firstContactItemAttributes = " title=\"$firstContactItem\"";
            $firstContactItemIcon = 'location';
            break;
        case $workingHours:
            $firstContactItemIcon = 'clock';
            break;
        default:
            break;
    }
    ?>
    <div class="contacts">
        <a class="contacts-header"<?= $firstContactItemAttributes ?>>
            <?php
            if ($firstContactItemIcon) { ?>
                <svg width="24" height="24">
                    <use xlink:href="<?= Icon::get($firstContactItemIcon) ?>"></use>
                </svg>
                <?php
            } ?>
            <span class="contacts-main"><?= $firstContactItem ?></span>
            <svg class="contacts-arrow" width="24" height="24">
                <use xlink:href="<?= Icon::get('chevron') ?>"></use>
            </svg>
        </a>

        <div class="contacts-popup">
            <ul class="contacts-popup__list">
                <li class="contacts-popup__item">
                    <?php
                    if ($firstPhoneItem) { ?>
                        <div class="contacts-popup__item-content">
                            <svg class="contacts-popup__item-icon" width="24" height="24">
                                <use xlink:href="<?= Icon::get('phone') ?>"></use>
                            </svg>
                            <ul class="contacts-popup__item-list">
                                <?php
                                $index = 0;
                                foreach ($phoneData as $phoneItem) { ?>
                                    <li class="contacts-popup__phone <?= $index === 0 ? 'contacts-popup__phone--first' : '' ?>">
                                        <a class="contacts-popup__item-link"
                                           href="tel:<?= htmlspecialcharsEx(
                                               str_replace(
                                                   ' ',
                                                   '',
                                                   $phoneItem['PHONE']
                                               )
                                           ) ?>"><?= $phoneItem['PHONE'] ?></a>
                                        <span class="contacts-popup__phone-caption"><?= $phoneItem['DESCRIPTION'] ?></span>
                                    </li>
                                    <?php
                                    $index++;
                                } ?>
                            </ul>
                        </div>
                        <?php
                    } ?>
                </li>

                <?php
                if ($email) { ?>
                    <li class="contacts-popup__item">
                        <svg class="contacts-popup__item-icon" width="24" height="24">
                            <use xlink:href="<?= Icon::get('envelope') ?>"></use>
                        </svg>
                        <a class="contacts-popup__item-link"
                           href="mailto:<?= $email ?>"><?= $email ?></a>
                    </li>
                    <?php
                } ?>

                <?php
                if ($workingHours) { ?>
                    <li class="contacts-popup__item">
                        <svg class="contacts-popup__item-icon" width="24" height="24">
                            <use xlink:href="<?= Icon::get('clock') ?>"></use>
                        </svg>
                        <span><?= $workingHours ?></span>
                    </li>
                    <?php
                } ?>

                <?php
                if ($address) { ?>
                    <li class="contacts-popup__item">
                        <svg class="contacts-popup__item-icon" width="24" height="24">
                            <use xlink:href="<?= Icon::get('location') ?>"></use>
                        </svg>
                        <span><?= $address ?></span>
                    </li>
                    <?php
                } ?>
            </ul>

            <button class="contacts-popup__button btn"
                    id="request-callback-form">
                <svg class="contacts-popup__item-icon" width="24" height="24">
                    <use xlink:href="<?= Icon::get('phone') ?>"></use>
                </svg>
                <span><?= Loc::getMessage('CONTACTS_BUTTON_TEXT') ?></span>
            </button>
        </div>
    </div>

    <script>
        BX.ready(function () {
            BX.message(<?= CUtil::PhpToJSObject(Loc::loadLanguageFile(__FILE__)) ?>);

            BX('request-callback-form').addEventListener('click', () => {
                BX.Sotbit.B2C.showForm('SOTBIT_REQUEST_A_CALL', {
                    MESSAGES: {
                        SUCCESS: '<?= Loc::getMessage('FORM_SUCCESS') ?>'
                    }
                });
            });

            BX.namespace('BX.Sotbit.B2C.classes');

            BX.Sotbit.B2C.classes.Contacts && (BX.Sotbit.B2C.layout.contacts = new BX.Sotbit.B2C.classes.Contacts());
        });
    </script>
    <?php
}
