<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Public\Icon;

Loc::loadMessages(__FILE__);
?>

<button class="catalog-btn btn btn-gradient" data-entity="header-menu-open-btn">
    <svg class="catalog-btn__icon--burger" width="24" height="24">
        <use xlink:href="<?= Icon::get('burger') ?>"></use>
    </svg>
    <svg class="catalog-btn__icon--close" width="24" height="24">
        <use xlink:href="<?= Icon::get('close') ?>"></use>
    </svg>
    <span class="catalog-btn__text">
        <?= Loc::getMessage('CATALOG') ?>
    </span>
</button>

<script>
    BX.ready(() => BX.message({'CATALOG': '<?= Loc::getMessage('CATALOG') ?>'}));
</script>
