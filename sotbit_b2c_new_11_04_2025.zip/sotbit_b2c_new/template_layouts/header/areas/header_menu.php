<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Helper\Config;

global $APPLICATION;

Loc::loadMessages(__FILE__);
?>

<div class="d-flex d-none header__menu catalog-menu" data-entity="header-menu-wrapper">
    <?php
    $APPLICATION->IncludeComponent(
        "bitrix:menu",
        "header_catalog_menu",
        array(
            "ROOT_MENU_TYPE" => "catalog",
            "MAX_LEVEL" => "4",
            "USE_EXT" => "Y",
            "COMPONENT_TEMPLATE" => "header_catalog_menu",
            "MENU_CACHE_TYPE" => "A",
            "MENU_CACHE_TIME" => "3600",
            "MENU_CACHE_USE_GROUPS" => "Y",
            "MENU_CACHE_GET_VARS" => array(),
            "CHILD_MENU_TYPE" => "left",
            "DELAY" => "N",
            "ALLOW_MULTI_SELECT" => "N",
            "COMPOSITE_FRAME_MODE" => "A",
            "COMPOSITE_FRAME_TYPE" => "AUTO",
            "SHOW_MENU_IMAGES" => Config::get('CATALOG_SHOW_MENU_IMAGES'),
        ),
        false
    ); ?>

    <ul class="catalog-menu__column">
        <?php //TODO: cards here ?>
    </ul>
</div>

<div class="header-mobile-menu custom-scrollbar d-none" data-entity="header-mobile-menu"></div>

<script>
    BX.message(<?= CUtil::PhpToJSObject(Loc::loadLanguageFile(__FILE__)) ?>);
</script>
