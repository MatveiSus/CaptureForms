<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Helper\{
    Config,
    Modules
};

global $APPLICATION;

Loc::loadMessages(__FILE__);

if (Modules::useSmartSearch()) {
    $APPLICATION->IncludeComponent(
        "sotbit:search.title",
        "header_search",
        array(
            "SHOW_INPUT" => "Y",
            "INPUT_ID" => "title-search-input",
            "CONTAINER_ID" => "title-search",
            "PATH_TO_BASKET" => SITE_DIR . "personal/cart/",
            "PRICE_CODE" => \SotbitB2C::GetComponentPrices(),
            "PRICE_VAT_INCLUDE" => "Y",
            "PREVIEW_TRUNCATE_LEN" => "150",
            "SHOW_PREVIEW" => "Y",
            "PREVIEW_WIDTH" => "64",
            "PREVIEW_HEIGHT" => "64",
            "CONVERT_CURRENCY" => "Y",
            "CURRENCY_ID" => "RUB",
            "PAGE" => SITE_DIR . "catalog/search.php",
            "NUM_CATEGORIES" => "2",
            "TOP_COUNT" => "7",
            "ORDER" => "rank",
            "USE_LANGUAGE_GUESS" => "Y",
            "CHECK_DATES" => "Y",
            "SHOW_OTHERS" => "N",
            "CATEGORY_OTHERS_TITLE" => "",
            "COMPONENT_TEMPLATE" => "header_search",
            "BASKET_LINK" => SITE_DIR . "personal/cart/",
            "CATEGORY_0_TITLE" => "",
            "CATEGORY_0" => array(
                0 => "no",
            ),
            "={\"CATEGORY_0_iblock_\".Config::get(\"CATALOG_IBLOCK_TYPE\", SITE_ID)}" => array(
                0 => "all",
            ),
            "CATEGORY_1_TITLE" => "",
            "CATEGORY_1" => array(
                0 => "no",
            ),
            "={\"CATEGORY_1_iblock_\".Config::get(\"BRANDS_IBLOCK_TYPE\", SITE_ID)}" => array(
                0 => Config::get("BRANDS_IBLOCK_TYPE"),
            ),
            "USE_SPEECH" => "Y"
        ),
        false
    );
} else {
    $APPLICATION->IncludeComponent(
        "bitrix:search.title",
        "header_search",
        array(
            "SHOW_INPUT" => "Y",
            "INPUT_ID" => "title-search-input",
            "CONTAINER_ID" => "title-search",
            "PRICE_CODE" => \SotbitB2C::GetComponentPrices(),
            "PRICE_VAT_INCLUDE" => "Y",
            "PREVIEW_TRUNCATE_LEN" => "150",
            "SHOW_PREVIEW" => "Y",
            "PREVIEW_WIDTH" => "64",
            "PREVIEW_HEIGHT" => "64",
            "CONVERT_CURRENCY" => "Y",
            "CURRENCY_ID" => "RUB",
            "PAGE" => SITE_DIR . "catalog/search.php",
            "NUM_CATEGORIES" => "2",
            "TOP_COUNT" => "7",
            "ORDER" => "rank",
            "USE_LANGUAGE_GUESS" => "Y",
            "CHECK_DATES" => "Y",
            "SHOW_OTHERS" => "N",
            "CATEGORY_OTHERS_TITLE" => "",
            "COMPONENT_TEMPLATE" => "header_search",
            "BASKET_LINK" => SITE_DIR . "personal/cart/",
            "CATEGORY_0_TITLE" => "",
            "CATEGORY_0" => array(
                0 => 'iblock_' . Config::get('CATALOG_IBLOCK_TYPE'),
            ),
            "CATEGORY_0_iblock_" . Config::get("CATALOG_IBLOCK_TYPE") => array(
                0 => "all",
            ),
            "CATEGORY_1_TITLE" => "",
            "CATEGORY_1" => array(
                0 => 'iblock_' . Config::get('BRANDS_IBLOCK_TYPE'),
            ),
            "CATEGORY_1_iblock_" . Config::get("BRANDS_IBLOCK_TYPE") => array(
                0 => Config::get("BRANDS_IBLOCK_TYPE"),
            ),
        ),
        false
    );
}
