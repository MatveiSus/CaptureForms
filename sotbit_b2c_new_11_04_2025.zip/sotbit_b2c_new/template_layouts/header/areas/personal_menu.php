<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Helper\Config;

Loc::loadMessages(__FILE__);
?>

<nav class="personal">
    <?php
    $APPLICATION->IncludeComponent(
        "bitrix:sale.basket.basket.line",
        ".default",
        array(
            "HIDE_ON_BASKET_PAGES" => "N",
            "PATH_TO_BASKET" => SITE_DIR . "personal/cart/",
            "PATH_TO_ORDER" => SITE_DIR . "personal/order/make/",
            "PATH_TO_ORDER_LIST" => SITE_DIR . "personal/orders/",
            "PATH_TO_FAVORITE" => SITE_DIR . "personal/favorite/",
            "PATH_TO_PERSONAL" => SITE_DIR . "personal/",
            "PATH_TO_PROFILE" => SITE_DIR . "personal/",
            "PATH_TO_REGISTER" => SITE_DIR . "login/",
            "PATH_TO_CATALOG" => SITE_DIR . "catalog/",
            "PATH_TO_COMPARE" => SITE_DIR . "catalog/compare/",
            "POSITION_FIXED" => "N",
            "POSITION_HORIZONTAL" => "right",
            "POSITION_VERTICAL" => "top",
            "SHOW_AUTHOR" => "Y",
            "SHOW_DELAY" => "Y",
            "SHOW_EMPTY_VALUES" => "N",
            "SHOW_IMAGE" => "Y",
            "SHOW_NOTAVAIL" => "Y",
            "SHOW_NUM_PRODUCTS" => "Y",
            "SHOW_PERSONAL_LINK" => "Y",
            "SHOW_PRICE" => "Y",
            "SHOW_PRODUCTS" => "Y",
            "SHOW_SUMMARY" => "Y",
            "SHOW_TOTAL_PRICE" => "Y",
            "COMPONENT_TEMPLATE" => ".default",
            "PATH_TO_AUTHORIZE" => "",
            "SHOW_REGISTRATION" => "N",
            "MAX_IMAGE_SIZE" => 80,
            "COMPOSITE_FRAME_MODE" => "A",
            "COMPOSITE_FRAME_TYPE" => "AUTO",
            "USE_COMPARE" => Config::get('CATALOG_USE_COMPARE'),
        ),
        false
    ); ?>
</nav>
