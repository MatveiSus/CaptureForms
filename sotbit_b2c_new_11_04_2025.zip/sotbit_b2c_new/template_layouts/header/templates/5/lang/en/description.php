<?php

$MESS['HEADER_5_TITLE'] = 'Header 5';
