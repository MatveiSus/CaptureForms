<?php

$MESS['HEADER_5_TITLE'] = 'Шапка 5';
