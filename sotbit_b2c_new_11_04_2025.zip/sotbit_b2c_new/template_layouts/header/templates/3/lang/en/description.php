<?php

$MESS['HEADER_3_TITLE'] = 'Header 3';
