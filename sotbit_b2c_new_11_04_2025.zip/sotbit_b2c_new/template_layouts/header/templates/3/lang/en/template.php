<?php

$MESS['HEADER_3_TITLE_SEARCH'] = 'Search';
