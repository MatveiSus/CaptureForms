BX.ready(() => {
    const fixedHeaderSearch = document.querySelector('[data-entity="header-search-fixed"]');
    let isFixedHeaderOpen = false;
    let fixedHeaderOverlay = null;

    const changeHeaderSearchState = (setOpen) => {
        if (setOpen) {
            if (!isFixedHeaderOpen) {
                BX.Sotbit.B2C.fixBodyScroll();

                fixedHeaderOverlay = BX.Sotbit.B2C.showOverlay('header');

                fixedHeaderOverlay.element.addEventListener('click', () => changeHeaderSearchState(false));

                fixedHeaderSearch.style.transform = `translateY(${
                    BX.Sotbit.B2C.getTotalChildrenHeight(BX.Sotbit.B2C.layout.header.container)
                    + (parseInt(BX.Sotbit.B2C.layout.header.container.style.top) || 0)
                }px)`
                BX.Sotbit.B2C.showElement(fixedHeaderSearch);
            }
        } else {
            if (isFixedHeaderOpen) {
                BX.Sotbit.B2C.unfixBodyScroll();
                BX.Sotbit.B2C.hideElement(fixedHeaderSearch);
                fixedHeaderOverlay.hide();
            }
        }

        isFixedHeaderOpen = setOpen;
    };

    const secondMenuWrapper = document.querySelector('.header__second-menu-wrapper');

    if (secondMenuWrapper) {
        BX.Sotbit.B2C.layout.header_second?.setMenuVisibility(!BX.Sotbit.B2C.layout.header.isFixed);
        secondMenuWrapper.classList[BX.Sotbit.B2C.layout.header.isFixed ? 'add' : 'remove']('hidden');

        BX.addCustomEvent('headerStateChange', (event) => {
            BX.Sotbit.B2C.layout.header_second?.setMenuVisibility(!event.data.fixed);
            BX.Sotbit.B2C.layout.header_second?.switchShowMoreSubmenuState(false);
            secondMenuWrapper.classList[event.data.fixed ? 'add' : 'remove']('hidden');
        });
    }

    document.querySelector('[data-entity="header-show-search-button"]')
        .addEventListener('click', () => changeHeaderSearchState(!isFixedHeaderOpen));
    window.addEventListener('resize', () => changeHeaderSearchState(false));
});
