BX.ready(() => {
    BX.addCustomEvent('getRegion', () => {
        BX.Sotbit.B2C.layout.header_top?.hideExtraMenuItems();
    });
});
