<?php

$MESS['HEADER_1_TITLE'] = 'Шапка 1';
