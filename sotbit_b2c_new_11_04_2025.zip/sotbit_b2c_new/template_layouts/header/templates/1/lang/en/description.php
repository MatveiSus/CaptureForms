<?php

$MESS['HEADER_1_TITLE'] = 'Header 1';
