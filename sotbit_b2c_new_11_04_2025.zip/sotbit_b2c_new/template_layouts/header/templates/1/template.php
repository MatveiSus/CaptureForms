<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Application, Config\Option, Loader, Page\Asset};
use Sotbit\B2C\{Helper\Marketplace, Helper\Modules, Helper\Config};

global $APPLICATION;

$useMinifiedAssets = Option::get('main', 'use_minified_assets', 'N') === 'Y';
$documentRoot = Application::getDocumentRoot();
$areasFolderPath = $documentRoot . SITE_TEMPLATE_PATH . '/template_layouts/header/areas';

Asset::getInstance()->addCss(
    SITE_TEMPLATE_PATH . '/template_layouts/header/templates/1/style' . ($useMinifiedAssets ? '.min' : '') . '.css'
);
Asset::getInstance()->addJs(
    SITE_TEMPLATE_PATH . '/template_layouts/header/templates/1/script' . ($useMinifiedAssets ? '.min' : '') . '.js'
);
?>

<header class="header header--1">
    <div class="header__top container">
        <div class="header__top-menu-wrapper">
            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:menu",
                "header_top_menu",
                array(
                    "ROOT_MENU_TYPE" => "header_top",
                    "COMPONENT_TEMPLATE" => "header_top_menu",
                    "MENU_CACHE_TYPE" => "A",
                    "MENU_CACHE_TIME" => "3600",
                    "MENU_CACHE_USE_GROUPS" => "Y",
                    "MENU_CACHE_GET_VARS" => array(),
                    "MAX_LEVEL" => "1",
                    "CHILD_MENU_TYPE" => "left",
                    "USE_EXT" => "Y",
                    "DELAY" => "N",
                    "ALLOW_MULTI_SELECT" => "N",
                    "COMPOSITE_FRAME_MODE" => "A",
                    "COMPOSITE_FRAME_TYPE" => "AUTO"
                ),
                false
            );
            /*$APPLICATION->IncludeComponent(
                "bitrix:menu",
                "header_multilevel_menu",
                array(
                    "ROOT_MENU_TYPE" => "header_top",
                    "COMPONENT_TEMPLATE" => "header_multilevel_menu",
                    "MENU_CACHE_TYPE" => "A",
                    "MENU_CACHE_TIME" => "3600",
                    "MENU_CACHE_USE_GROUPS" => "Y",
                    "MENU_CACHE_GET_VARS" => array(),
                    "MAX_LEVEL" => "1",
                    "CHILD_MENU_TYPE" => "left",
                    "USE_EXT" => "Y",
                    "DELAY" => "N",
                    "ALLOW_MULTI_SELECT" => "N",
                    "COMPOSITE_FRAME_MODE" => "A",
                    "COMPOSITE_FRAME_TYPE" => "AUTO"
                ),
                false
            );*/
            ?>
        </div>
        <div class="header__regions-wrapper">
            <?php if(SITE_ID == 's4'){?>
                <a href="https://yandex.ru/maps/213/moscow/house/altufyevskoye_shosse_31b/Z04YcwBoSUEBQFtvfXR0eHlqYQ==/?indoorLevel=1&ll=37.578046%2C55.859595&z=17">Индекс 127410 г. Москва,Алтуфьевское шоссе, д. 31Б</a>
                <?}

            if (Modules::useRegions()) {
                $APPLICATION->IncludeComponent(
                    "sotbit:regions.choose",
                    "b2c",
                    array(
                        "FROM_LOCATION" => "Y",
                        "COMPONENT_TEMPLATE" => "b2c"
                    ),
                    false
                );
            } ?>

            <div class="header__contacts-wrapper">
            <?php 
                include($areasFolderPath . '/header_contacts.php'); ?>
            </div>

            <?php
            include($areasFolderPath . '/header_notification.php'); ?>
        </div>
    </div>

    <div class="header__main container">
<?$headerLogoSrc2 = Config::getLogo('HEADER');
if($headerLogoSrc2){?>
        <div class="header__logo-wrapper">
            <?php
            include($areasFolderPath . '/header_logo.php') ?>
        </div>
<?}?>

        <div class="header__catalog-button-wrapper">
            <?php
            include($areasFolderPath . '/header_menu_button.php') ?>
        </div>

        <div class="header__search-wrapper">
            <?php
            include($areasFolderPath . '/header_search_title.php') ?>
        </div>
        <div class="header__personal-wrapper">
            <?php
            include($areasFolderPath . '/personal_menu.php') ?>
        </div>

        <?php
        include($areasFolderPath . '/header_menu.php') ?>
    </div>
</header>
