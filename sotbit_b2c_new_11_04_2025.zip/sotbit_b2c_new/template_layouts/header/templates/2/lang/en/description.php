<?php

$MESS['HEADER_2_TITLE'] = 'Header 2';
