<?php

$MESS['HEADER_2_TITLE'] = 'Шапка 2';
