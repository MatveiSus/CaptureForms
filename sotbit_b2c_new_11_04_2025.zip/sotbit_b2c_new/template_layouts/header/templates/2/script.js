BX.ready(() => {
    const secondMenuWrapper = document.querySelector('.header__second-menu-wrapper');

    if (secondMenuWrapper) {
        BX.Sotbit.B2C.layout.header_second?.setMenuVisibility(!BX.Sotbit.B2C.layout.header.isFixed);
        secondMenuWrapper.classList[BX.Sotbit.B2C.layout.header.isFixed ? 'add' : 'remove']('hidden');

        BX.addCustomEvent('headerStateChange', (event) => {
            BX.Sotbit.B2C.layout.header_second?.setMenuVisibility(!event.data.fixed);
            BX.Sotbit.B2C.layout.header_second?.switchShowMoreSubmenuState(false);
            secondMenuWrapper.classList[event.data.fixed ? 'add' : 'remove']('hidden');
        });
    }

    BX.addCustomEvent('getRegion', () => {
        BX.Sotbit.B2C.layout.header_top?.hideExtraMenuItems();
    });
});
