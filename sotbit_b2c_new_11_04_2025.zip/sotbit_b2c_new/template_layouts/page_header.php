<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

global $APPLICATION;

if (!function_exists('showPageTitle')) {
    function showPageTitle()
    {
        global $APPLICATION;

        return $APPLICATION->GetProperty('SHOW_TITLE') === 'Y' ? '<h1>' . $APPLICATION->GetTitle() . '</h1>' : '';
    }
}

if ($APPLICATION->GetProperty('SHOW_SIDEBAR') === 'Y') { ?>
<div class="d-flex flex-lg-column gap-5 gap-lg-4">
    <?php
    $APPLICATION->IncludeComponent(
        "bitrix:menu",
        "sidebar",
        array(
            "ROOT_MENU_TYPE" => "sidebar",
            "CHILD_MENU_TYPE" => "left",
            "MAX_LEVEL" => 2
        )
    ); ?>
    <section class="sidebar-section w-100">
        <?php
        }

if ($APPLICATION->GetCurPage() !== SITE_DIR) { ?>
    <div class="title-container"><?php
        if ($APPLICATION->GetProperty('SHOW_BREADCRUMBS') === 'Y') {
            $APPLICATION->IncludeComponent("bitrix:breadcrumb", "");
        }

        $APPLICATION->AddBufferContent('showPageTitle');
        ?></div>
<?php }
