<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

global $APPLICATION;

if (!function_exists('showPageFooter')) {
    function showPageFooter()
    {
        global $APPLICATION;

        return $APPLICATION->GetProperty('SHOW_SIDEBAR') === 'Y' ? '</section></div></main>' : '</main>';
    }
}

$APPLICATION->AddBufferContent('showPageFooter');
?>

<div class="personal personal__placeholder d-none d-lg-block w-100"></div>
