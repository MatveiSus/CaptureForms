<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{
    IO\Path,
    Localization\Loc
};
use Sotbit\B2C\Helper\Config;

Loc::loadMessages(__FILE__);
Loc::loadMessages(Path::combine(__DIR__, 'description.php'));

global $APPLICATION, $labelsTopFilter, $isCompareComponentIncluded;

$labelProperties = Config::get('CATALOG_LABEL_PROPERTIES');
$labelsTopFilter = [["LOGIC" => "OR"]];

foreach ($labelProperties as $property) {
    $labelsTopFilter[0]["!PROPERTY_{$property}_VALUE"] = false;
}

$APPLICATION->IncludeComponent(
	"bitrix:catalog.top", 
	".default", 
	array(
		"ACTION_VARIABLE" => "action",
		"ADD_PICT_PROP" => "MORE_PHOTO",
		"ADD_PROPERTIES_TO_BASKET" => "N",
		"ADD_TO_BASKET_ACTION" => "ADD",
		"BASKET_URL" => SITE_DIR."personal/cart/",
		"BRAND_PROPERTY" => "BRAND_REF",
		"CACHE_FILTER" => "N",
		"CACHE_GROUPS" => "Y",
		"CACHE_TIME" => "36000",
		"CACHE_TYPE" => "A",
		"COMPARE_NAME" => "CATALOG_COMPARE_LIST",
		"COMPARE_PATH" => "",
		"COMPARE_URL" => SITE_DIR."catalog/compare/",
		"COMPATIBLE_MODE" => "N",
		"CONVERT_CURRENCY" => "Y",
		"CURRENCY_ID" => "RUB",
		"CUSTOM_FILTER" => "",
		"DATA_LAYER_NAME" => "dataLayer",
		"DETAIL_URL" => "",
		"DISCOUNT_PERCENT_POSITION" => "bottom-right",
		"DISPLAY_COMPARE" => "N",
		"ELEMENT_COUNT" => "18",
		"ELEMENT_SORT_FIELD" => "name",
		"ELEMENT_SORT_FIELD2" => "sort",
		"ELEMENT_SORT_ORDER" => "asc",
		"ELEMENT_SORT_ORDER2" => "asc",
		"ENLARGE_PRODUCT" => "STRICT",
		"FILTER_NAME" => "",
		"FILL_ITEM_ALL_PRICES" => "Y",
		"HIDE_NOT_AVAILABLE" => "L",
		"HIDE_NOT_AVAILABLE_OFFERS" => "L",
		"IBLOCK_ID" => Config::get("CATALOG_IBLOCK_ID"),
		"IBLOCK_TYPE" => "news",
		"LABEL_PROP" => Config::get("CATALOG_LABEL_PROPERTIES"),
		"LABEL_PROP_MOBILE" => Config::get("CATALOG_LABEL_PROPERTIES"),
		"LABEL_PROP_POSITION" => "bottom-left",
		"LINE_ELEMENT_COUNT" => "",
		"MESS_BTN_ADD_TO_BASKET" => Loc::getMessage("MESS_BTN_ADD_TO_BASKET"),
		"MESS_BTN_BUY" => Loc::getMessage("MESS_BTN_BUY"),
		"MESS_BTN_COMPARE" => Loc::getMessage("MESS_BTN_COMPARE"),
		"MESS_BTN_DETAIL" => Loc::getMessage("MESS_BTN_DETAIL"),
		"MESS_NOT_AVAILABLE" => Loc::getMessage("MESS_NOT_AVAILABLE"),
		"MESS_NOT_AVAILABLE_SERVICE" => Loc::getMessage("MESS_NOT_AVAILABLE_SERVICE"),
		"MESS_RELATIVE_QUANTITY_FEW" => Loc::getMessage("MESS_RELATIVE_QUANTITY_FEW"),
		"MESS_RELATIVE_QUANTITY_MANY" => Loc::getMessage("MESS_RELATIVE_QUANTITY_MANY"),
		"MESS_SHOW_MAX_QUANTITY" => Loc::getMessage("MESS_SHOW_MAX_QUANTITY"),
		"OFFERS_CART_PROPERTIES" => "",
		"OFFERS_FIELD_CODE" => array(
			0 => "NAME",
			1 => "",
		),
		"OFFERS_LIMIT" => "5",
		"OFFERS_PROPERTY_CODE" => Config::get("CATALOG_OFFERS_DISPLAY_PROPERTIES_LIST"),
		"OFFERS_SORT_FIELD" => "sort",
		"OFFERS_SORT_FIELD2" => "id",
		"OFFERS_SORT_ORDER" => "asc",
		"OFFERS_SORT_ORDER2" => "desc",
		"OFFER_ADD_PICT_PROP" => "MORE_PHOTO",
		"OFFER_TREE_PROPS" => Config::get("CATALOG_OFFER_PROPERTIES"),
		"PARTIAL_PRODUCT_PROPERTIES" => "Y",
		"PRICE_CODE" => array(
		),
		"PRICE_VAT_INCLUDE" => "Y",
		"PRODUCT_BLOCKS_ORDER" => "price,name,sku,props,reviews,quantityLimit,buttons",
		"PRODUCT_DISPLAY_MODE" => "Y",
		"PRODUCT_ID_VARIABLE" => "id",
		"PRODUCT_PROPERTIES" => "",
		"PRODUCT_PROPS_VARIABLE" => "prop",
		"PRODUCT_QUANTITY_VARIABLE" => "",
		"PRODUCT_ROW_VARIANTS" => "[{'VARIANT':'2','BIG_DATA':false},{'VARIANT':'2','BIG_DATA':false},{'VARIANT':'2','BIG_DATA':false}]",
		"PRODUCT_SUBSCRIPTION" => "Y",
		"PROPERTY_CODE" => Config::get("CATALOG_DISPLAY_PROPERTIES_LIST"),
		"PROPERTY_CODE_MOBILE" => "",
		"RELATIVE_QUANTITY_FACTOR" => "5",
		"ROTATE_TIMER" => "30",
		"SECTION_URL" => "",
		"SEF_MODE" => "N",
		"SEF_RULE" => "",
		"SHOW_CLOSE_POPUP" => "N",
		"SHOW_DISCOUNT_PERCENT" => "Y",
		"SHOW_MAX_QUANTITY" => "M",
		"SHOW_OLD_PRICE" => "Y",
		"SHOW_PAGINATION" => "Y",
		"SHOW_PRICE_COUNT" => "1",
		"SHOW_SLIDER" => "Y",
		"SLIDER_INTERVAL" => "3000",
		"SLIDER_PROGRESS" => "N",
		"TEMPLATE_THEME" => "",
		"USE_ENHANCED_ECOMMERCE" => "Y",
		"USE_PRICE_COUNT" => "N",
		"USE_PRODUCT_QUANTITY" => "Y",
		"VIEW_MODE" => "SECTION",
		"SECTION_TITLE" => Loc::getMessage("CATALOG_SECTION_LABELS_BLOCK_TITLE"),
		"COMPONENT_TEMPLATE" => ".default",
		"FAVORITE_URL" => SITE_DIR."personal/favorite/",
		"USE_SKU_TITLE" => Config::get("CATALOG_SEO_USE_SKU_TITLE_LIST")?:"",
		"USE_SKU_URL" => Config::get("CATALOG_SEO_USE_DISTINCT_URL")?:"",
		"USE_SKU_SEO" => Config::get("CATALOG_SEO_USE_SKU_SEO")?:"",
		"SKU_VISUAL_VARIANT" => Config::get("CATALOG_LIST_SKU_VARIANT"),
		"ITEM_HOVER_ANIMATION" => Config::get("CATALOG_ITEM_HOVER_ANIMATION"),
		"ITEM_SCROLL_ON_HOVER" => Config::get("CATALOG_ITEM_SCROLL_ON_HOVER")
	),
	false
);

if (!$isCompareComponentIncluded) {
    if (Config::get('CATALOG_USE_COMPARE') === "Y") {
        $APPLICATION->IncludeComponent(
            "bitrix:catalog.compare.list",
            "b2c",
            array(
                "IBLOCK_TYPE" => Config::get("CATALOG_IBLOCK_TYPE"),
                "IBLOCK_ID" => Config::get("CATALOG_IBLOCK_ID"),
                "COMPARE_URL" => SITE_DIR . "catalog/compare/",
                "POSITION_FIXED" => "Y",
                "POSITION" => ["bottom", "right"]
            ),
            false,
            array("HIDE_ICONS" => "Y")
        );
    }

    $isCompareComponentIncluded = true;
}
