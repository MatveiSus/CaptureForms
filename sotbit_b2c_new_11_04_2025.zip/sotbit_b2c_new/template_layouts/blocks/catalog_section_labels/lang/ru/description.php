<?php

$MESS['CATALOG_SECTION_LABELS_BLOCK_TITLE'] = 'Рекомендуемые покупки';
$MESS['MESS_BTN_ADD_TO_BASKET'] = "В корзину";
$MESS['MESS_BTN_BUY'] = "Купить";
$MESS['MESS_BTN_COMPARE'] = "Сравнить";
$MESS['MESS_BTN_DETAIL'] = "Подробнее";
$MESS['MESS_NOT_AVAILABLE'] = "Нет в наличии";
$MESS['MESS_NOT_AVAILABLE_SERVICE'] = "Недоступно";
$MESS['MESS_RELATIVE_QUANTITY_FEW'] = "мало";
$MESS['MESS_RELATIVE_QUANTITY_MANY'] = "много";
$MESS['MESS_SHOW_MAX_QUANTITY'] = "Наличие";
