<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Config\Option;
use Sotbit\B2C\Helper\Config;

Loc::loadMessages(__FILE__);

global $APPLICATION;

$formController = new \Sotbit\B2C\Controller\Form();
$formId = $formController->getFormIdBySid('SOTBIT_HAVE_QUESTIONS');

if (!$formId && $formController->getErrors()) {
    ShowError(current($formController->getErrors()));
    return;
}

$useMinifiedAssets = Option::get('main', 'use_minified_assets', 'N') === 'Y';
Asset::getInstance()->addCss(
    SITE_TEMPLATE_PATH . '/template_layouts/blocks/webform/style'
    . ($useMinifiedAssets ? '.min' : '')
    . '.css'
);

$currentUser = \Bitrix\Main\Engine\CurrentUser::get();
if ($currentUser) {
    $userPhoneResult = \Bitrix\Main\UserPhoneAuthTable::query()
        ->addSelect('PHONE_NUMBER')
        ->where('USER_ID', $currentUser->getId())
        ->setLimit(1)
        ->fetch();

    $defaultValues = [
        'NAME' => $currentUser->getFirstName(),
        'EMAIL' => $currentUser->getEmail(),
        'PHONE' => $userPhoneResult ? $userPhoneResult['PHONE_NUMBER'] : '',
    ];
}
?>

<div class="mainpage-webform">
    <?php $APPLICATION->IncludeComponent(
        "bitrix:form.result.new",
        "popup",
        [
            "WEB_FORM_ID" => $formId,
            "COMPONENT_TEMPLATE" => "popup",
            "IGNORE_CUSTOM_TEMPLATE" => "N",
            "USE_EXTENDED_ERRORS" => "N",
            "SEF_MODE" => "N",
            "CACHE_TYPE" => "A",
            "CACHE_TIME" => "3600",
            "SHOW_USER_CONSENT" => "Y",
            "USER_CONSENT_ID" => Config::get("USER_DATA_AGREEMENT_FORM"),
            "LIST_URL" => "result_list.php",
            "EDIT_URL" => "result_edit.php",
            "SUCCESS_URL" => "",
            "CHAIN_ITEM_TEXT" => "",
            "CHAIN_ITEM_LINK" => "",
            "VARIABLE_ALIASES" => array(
                "WEB_FORM_ID" => "WEB_FORM_ID",
                "RESULT_ID" => "RESULT_ID",
            ),
            "DEFAULT_VALUES" => $defaultValues ?? []
        ],
        false
    ); ?>
</div>
