<?php

$MESS['WEBFORM_BLOCK_TITLE'] = 'Форма захвата';
