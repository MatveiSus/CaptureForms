<?php

$MESS['WEBFORM_BLOCK_TITLE'] = 'Webform';
