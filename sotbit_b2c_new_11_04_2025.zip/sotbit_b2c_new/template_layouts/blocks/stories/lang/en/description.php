<?php

$MESS['STORIES_BLOCK_TITLE'] = 'Stories';
