<?php

$MESS['STORIES_BLOCK_TITLE'] = 'Истории';
