<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Helper\Config;
use Sotbit\B2C\Public\Image;

Loc::loadMessages(__FILE__);

global $APPLICATION;

$APPLICATION->IncludeComponent(
	"sotbit:b2c.stories", 
	".default", 
	array(
		"COMPONENT_TEMPLATE" => ".default",
		"CACHE_TYPE" => "A",
		"CACHE_TIME" => "36000000"
	),
	false
);
