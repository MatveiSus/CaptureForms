<?php

$MESS['VIDEO_BLOCK_TITLE'] = 'Video';
