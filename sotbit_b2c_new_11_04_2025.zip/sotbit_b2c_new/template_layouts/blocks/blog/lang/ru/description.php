<?php

$MESS['BLOG_BLOCK_TITLE'] = 'Блог';
