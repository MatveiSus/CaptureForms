<?php

$MESS['BLOG'] = 'Блог';
$MESS['BLOG_TITLE'] = 'Все статьи';
