<?php

$MESS['BLOG_BLOCK_TITLE'] = 'Blog';
