<?php

$MESS['BLOG'] = 'Blog';
$MESS['BLOG'] = 'All articles';
