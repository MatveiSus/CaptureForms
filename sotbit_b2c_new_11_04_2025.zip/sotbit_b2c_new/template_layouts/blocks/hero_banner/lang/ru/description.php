<?php

$MESS['HERO_BANNER_BLOCK_TITLE'] = 'Главный баннер';
