<?php

$MESS['HERO_BANNER_BLOCK_TITLE'] = 'Main banner';
