<?php

$MESS['ADVANTAGES_BLOCK_TITLE'] = 'Блок преимуществ';
