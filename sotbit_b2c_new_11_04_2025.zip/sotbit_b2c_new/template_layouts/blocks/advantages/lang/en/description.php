<?php

$MESS['ADVANTAGES_BLOCK_TITLE'] = 'Block of advantages';
