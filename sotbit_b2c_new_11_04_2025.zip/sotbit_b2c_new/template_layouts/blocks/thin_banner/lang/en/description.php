<?php

$MESS['THIN_BANNER_BLOCK_TITLE'] = 'Narrow banner';
