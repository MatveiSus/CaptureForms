<?php

$MESS['CATALOG_SECTIONS_BLOCK_TITLE'] = 'Список разделов каталога';
