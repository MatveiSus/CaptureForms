<?php

$MESS['CATALOG_SECTIONS_BLOCK_TITLE'] = 'List of catalog sections';
