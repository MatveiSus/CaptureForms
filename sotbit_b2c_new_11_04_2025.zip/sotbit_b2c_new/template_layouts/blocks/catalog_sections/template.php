<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Config\Option, Localization\Loc, Page\Asset};
use Sotbit\B2C\Helper\Config;

Loc::loadMessages(__FILE__);

global $APPLICATION, $sectionsFilter;

$useMinifiedAssets = Option::get('main', 'use_minified_assets', 'N') === 'Y';

Asset::getInstance()->addCss(
    SITE_TEMPLATE_PATH . '/template_layouts/blocks/catalog_sections/style'
    . ($useMinifiedAssets ? '.min' : '')
    . '.css'
);

$configFilter = Config::get('CATALOG_MAIN_PAGE_SECTIONS');
$showSections = !in_array("NOT_REF", $configFilter);

if ($showSections) {
    $sectionsFilter = ['ID' => $configFilter];
}
?>

<div class="main-page-catalog-sections">
    <?php
    $APPLICATION->IncludeComponent(
        "bitrix:catalog.section.list",
        "pills",
        array(
            "IBLOCK_TYPE" => Config::get("CATALOG_IBLOCK_TYPE"),
            "IBLOCK_ID" => Config::get("CATALOG_IBLOCK_ID"),
            "COMPONENT_TEMPLATE" => "pills",
            "SECTION_ID" => "",
            "SECTION_CODE" => "",
            "COUNT_ELEMENTS_FILTER" => "CNT_ALL",
            "ADDITIONAL_COUNT_ELEMENTS_FILTER" => "additionalCountFilter",
            "HIDE_SECTIONS_WITH_ZERO_COUNT_ELEMENTS" => "N",
            "TOP_DEPTH" => "4",
            "FILTER_NAME" => "sectionsFilter",
            "SECTION_URL" => "",
            "CACHE_TYPE" => "A",
            "CACHE_TIME" => "36000000",
            "CACHE_GROUPS" => "Y",
            "CACHE_FILTER" => "Y",
            "ADD_SECTIONS_CHAIN" => "Y"
        ),
        false,
        ['ACTIVE_COMPONENT' => $showSections ? "Y" : "N"]
    );
    ?>
</div>
