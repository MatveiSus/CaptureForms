<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Helper\Config;
use Sotbit\B2C\Iblock\Promo;

Loc::loadMessages(__FILE__);

global $APPLICATION;

$promoIblockType = Config::get("PROMO_IBLOCK_TYPE");
$promoIblockId = Config::get("PROMO_IBLOCK_ID");

if ($promoIblockType && $promoIblockId) {
    global $promoFilter;

    $promoFilter = [
        '!PROPERTY_' . Promo::PROMO_SHOW_ON_MAIN_PAGE_PROPERTY_CODE => false,
    ];

    $APPLICATION->IncludeComponent("bitrix:news.list", "promo", array(
	"SET_TITLE" => "N",
		"IBLOCK_TYPE" => $promoIblockType,
		"IBLOCK_ID" => $promoIblockId,
		"DISPLAY_PICTURE" => "Y",
		"DISPLAY_PREVIEW_TEXT" => "Y",
		"USE_FILTER" => "Y",
		"FILTER_NAME" => "promoFilter",
		"PROPERTY_CODE" => array(
			0 => Promo::PROMO_SHOW_TIMER_PROPERTY_CODE,
		),
		"COMPONENT_TEMPLATE" => "promo",
		"NEWS_COUNT" => "250",
		"SORT_BY1" => "ACTIVE_FROM",
		"SORT_ORDER1" => "DESC",
		"SORT_BY2" => "SORT",
		"SORT_ORDER2" => "ASC",
		"FIELD_CODE" => array(
			0 => "ACTIVE_TO",
		),
		"CHECK_DATES" => "Y",
		"DETAIL_URL" => "",
		"AJAX_MODE" => "N",
		"AJAX_OPTION_JUMP" => "N",
		"AJAX_OPTION_STYLE" => "Y",
		"AJAX_OPTION_HISTORY" => "N",
		"AJAX_OPTION_ADDITIONAL" => "",
		"CACHE_TYPE" => "A",
		"CACHE_TIME" => "36000000",
		"CACHE_FILTER" => "Y",
		"CACHE_GROUPS" => "Y",
		"PREVIEW_TRUNCATE_LEN" => "",
		"ACTIVE_DATE_FORMAT" => "d.m.Y",
		"SET_BROWSER_TITLE" => "N",
		"SET_META_KEYWORDS" => "N",
		"SET_META_DESCRIPTION" => "N",
		"SET_LAST_MODIFIED" => "N",
		"INCLUDE_IBLOCK_INTO_CHAIN" => "N",
		"ADD_SECTIONS_CHAIN" => "N",
		"HIDE_LINK_WHEN_NO_DETAIL" => "N",
		"PARENT_SECTION" => "",
		"PARENT_SECTION_CODE" => "",
		"INCLUDE_SUBSECTIONS" => "Y",
		"STRICT_SECTION_CHECK" => "N",
		"PAGER_TEMPLATE" => ".default",
		"DISPLAY_TOP_PAGER" => "N",
		"DISPLAY_BOTTOM_PAGER" => "N",
		"PAGER_TITLE" => "",
		"PAGER_SHOW_ALWAYS" => "N",
		"PAGER_DESC_NUMBERING" => "N",
		"PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
		"PAGER_SHOW_ALL" => "N",
		"PAGER_BASE_LINK_ENABLE" => "N",
		"SET_STATUS_404" => "Y",
		"SHOW_404" => "Y",
		"MESSAGE_404" => "",
		"COMPOSITE_FRAME_MODE" => "A",
		"COMPOSITE_FRAME_TYPE" => "AUTO",
		"HOVER_EFFECT" => Config::get("PROMO_ITEM_HOVER_ANIMATION"),
		"PROMO_URL" => SITE_DIR."promo/"
	),
	false,
	array(
	"ACTIVE_COMPONENT" => "Y"
	)
);
}
