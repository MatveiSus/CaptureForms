<?php

$MESS['PROMO_BLOCK_TITLE'] = 'Promotions';
