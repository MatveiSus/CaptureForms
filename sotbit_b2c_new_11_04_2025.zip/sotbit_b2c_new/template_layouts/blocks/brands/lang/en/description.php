<?php

$MESS['BRANDS_BLOCK_TITLE'] = 'Brands';
