<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\{Localization\Loc};

Loc::loadMessages(__FILE__);

global $APPLICATION;

$APPLICATION->IncludeComponent(
    "sotbit:b2c.video",
    ".default",
    array(
        "PROVIDER" => "Rutube",
        "COMPONENT_TEMPLATE" => ".default",
        "VIDEOS_COUNT" => "10",
        "THUMBNAIL_SIZE" => "medium",
        "BLOCK_TITLE" => Loc::getMessage('VIDEO_RUTUBE_BLOCK_TITLE'),
    ),
    false
);
