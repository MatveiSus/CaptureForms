<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Config\Option, Localization\Loc, Page\Asset};

Loc::loadMessages(__FILE__);

global $APPLICATION;

$useMinifiedAssets = Option::get('main', 'use_minified_assets', 'N') === 'Y';

Asset::getInstance()->addCss(
    SITE_TEMPLATE_PATH . '/template_layouts/blocks/about/style'
    . ($useMinifiedAssets ? '.min' : '')
    . '.css'
);

$APPLICATION->IncludeComponent(
    "bitrix:main.include",
    "mainpage_blocks",
    array(
        "AREA_FILE_SHOW" => "file",
        "PATH" => SITE_TEMPLATE_PATH . "/include/main/about_" . SITE_ID . ".php",
        "AREA_FILE_RECURSIVE" => "N",
        "EDIT_MODE" => "html",
        "CONTAINER_CLASS" => 'mainpage-about'
    ),
    false,
);
