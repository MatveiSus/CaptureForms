<?php

$MESS['ABOUT_BLOCK_TITLE'] = 'О нас';
