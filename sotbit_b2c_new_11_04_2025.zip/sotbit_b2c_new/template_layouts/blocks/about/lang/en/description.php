<?php

$MESS['ABOUT_BLOCK_TITLE'] = 'About us';
