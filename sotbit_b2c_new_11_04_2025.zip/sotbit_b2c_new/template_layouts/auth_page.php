<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

Bitrix\Main\Page\Asset::getInstance()->addCss(SITE_TEMPLATE_PATH . '/assets/css/common/auth-page.min.css');

?>

<div class="auth-page">
    <?php
    include($_SERVER['DOCUMENT_ROOT'] . SITE_TEMPLATE_PATH . '/template_layouts/header/areas/personal_menu.php');

    $APPLICATION->AuthForm('');
    ?>
</div>
