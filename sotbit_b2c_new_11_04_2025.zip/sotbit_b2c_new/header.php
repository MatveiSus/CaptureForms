<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{
    Application,
    Engine\CurrentUser,
    Loader,
    Localization\Loc,
};
use Sotbit\B2C\{Helper\Config};

global $APPLICATION, $USER;

Loader::includeModule('sotbit.b2c');

$documentRoot = Application::getDocumentRoot();
$request = Application::getInstance()->getContext()->getRequest();
?><!DOCTYPE html>
<html lang="<?= LANGUAGE_ID ?>">
<head>

		<?php $APPLICATION->IncludeFile(
                SITE_TEMPLATE_PATH . '/include/metrics/metric_code_'.SITE_ID.'.php',
                [],
                [
                    'MODE' => 'php'
                ]
            ) ?>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=<?= LANG_CHARSET ?>">
    <title><?php
        $APPLICATION->ShowTitle() ?></title>
    <?= Config::getFaviconLinkTag() ?>
    <?php
    $APPLICATION->ShowMeta("robots", false, false);
    $APPLICATION->ShowMeta("keywords", false, false);
    $APPLICATION->ShowMeta("description", false, false);
    $APPLICATION->ShowLink("canonical", null, false);

     if(SITE_ID == 's4'){?>
    		<?$APPLICATION->ShowMeta("robots")?>
    		<?$APPLICATION->ShowCSS()?>
    		<?$APPLICATION->ShowHeadStrings()?>
    		<?$APPLICATION->ShowHeadScripts()?>
    		<?$APPLICATION->ShowMeta("description");?>
    		<link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96" />
    		<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    		<link rel="shortcut icon" href="/favicon.ico" />
    		<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
    		<meta name="apple-mobile-web-app-title" content="ГидроТехПромСнаб" />
    		<link rel="manifest" href="/site.webmanifest" />
     		<script src="/bitrix/templates/sotbit_b2c_new/assets/custom/jquerymin.js" type="text/javascript"></script>
    		<link rel="stylesheet" type="text/css" href="/bitrix/templates/sotbit_b2c_new/assets/custom/slick/slick.css"/>
    		<link rel="stylesheet" type="text/css" href="/bitrix/templates/sotbit_b2c_new/assets/custom/slick/slick-theme.css"/>
    		<script type="text/javascript" src="/bitrix/templates/sotbit_b2c_new/assets/custom/slick/slick.min.js"></script>
    		<script src="/bitrix/templates/sotbit_b2c_new/assets/custom/jquery.cookie.js"></script>
    		<script src="/bitrix/templates/sotbit_b2c_new/assets/custom/jquery.cookie.min.js"></script>
        <?} else {
            $APPLICATION->ShowHead();
	}

    include($documentRoot . SITE_TEMPLATE_PATH . '/include/page/demosite.php');
    include($documentRoot . SITE_TEMPLATE_PATH . '/include/metrics/head.php');
    include($documentRoot . SITE_TEMPLATE_PATH . '/assets/include.php'); ?>
</head>
<body>

<?php
include($documentRoot . SITE_TEMPLATE_PATH . '/include/metrics/body.php');

if ($request->getCookieRaw('IS_MOBILE_APP') !== 'true') {
    $APPLICATION->ShowPanel();
}

if (Config::isDemoSite()) {
    $APPLICATION->ShowViewContent('sotbit_b2c_demo_settings');
}

if ($request->getCookieRaw('IS_MOBILE_APP') !== 'true') {
    $APPLICATION->IncludeComponent(
        "bitrix:main.userconsent.request",
        "cookies",
        array(
            "AUTO_SAVE" => "Y",
            "COMPOSITE_FRAME_MODE" => "A",
            "COMPOSITE_FRAME_TYPE" => "AUTO",
            "ID" => Config::get('COOKIES_AGREEMENT'),
            "IS_CHECKED" => "Y",
            "IS_LOADED" => "Y",
            "REPLACE" => [
                'fields' => [
                    Loc::getMessage('COOKIES'),
                    Loc::getMessage('IP_ADDRESS'),
                ]
            ]
        ),
        false,
        ['ACTIVE_COMPONENT' => Config::get('SHOW_COOKIES_FORM')]
    );
}

if (defined("NEED_AUTH") && NEED_AUTH === true && !CurrentUser::get()->getId()) {
    return include($documentRoot . SITE_TEMPLATE_PATH . '/template_layouts/auth_page.php');
}

include($documentRoot . SITE_TEMPLATE_PATH . '/template_layouts/header/templates/' . Config::get(
        'HEADER_VARIANT'
    ) . '/template.php');
?>

<main class="container">
<?php
include($documentRoot . SITE_TEMPLATE_PATH . '/template_layouts/page_header.php');
