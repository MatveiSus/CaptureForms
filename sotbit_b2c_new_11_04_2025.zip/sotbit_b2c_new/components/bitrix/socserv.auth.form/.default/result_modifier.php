<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var array $arParams
 */

if ($arParams['AUTH_SERVICES']['apple']) {
    $arParams['AUTH_SERVICES']['apple']['ONCLICK'] =
        str_replace('top.location.href = ', 'BX.util.popup(', $arParams['AUTH_SERVICES']['apple']['ONCLICK']) . ', 660, 425)';
}
