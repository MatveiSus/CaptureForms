<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var array $arParams
 * @var string $templateFolder
 */

?>

<div class="socserv-auth">
    <?php
    foreach ($arParams['AUTH_SERVICES'] as $service) { ?>
        <button class="socserv-auth__item" title="<?= $service['NAME'] ?>" onclick="<?= $service['ONCLICK'] ?>" type="button">
            <svg width="48" height="48">
                <use xlink:href="<?= "$templateFolder/images/sprite.svg#{$service['ICON']}" ?>"></use>
            </svg>
        </button>
    <?php
    } ?>
</div>
