<?php if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

use Bitrix\Main\{
    Localization\Loc,
    UI\Extension
};
use Sotbit\B2C\Public\Icon;

$this->setFrameMode(true);

$INPUT_ID = CUtil::JSEscape(trim($arParams["~INPUT_ID"])) ?: "title-search-input";
$CONTAINER_ID = CUtil::JSEscape(trim($arParams["~CONTAINER_ID"])) ?: "title-search";

if ($arParams["SHOW_INPUT"] !== "N") { ?>
    <form id="<?= $CONTAINER_ID ?>" class="header__search search" action="<?= $arResult["FORM_ACTION"] ?>">
        <button name="s" value="<?= Loc::getMessage("CT_BST_SEARCH_BUTTON"); ?>" class="search-btn" title="<?= Loc::getMessage("CT_BST_SEARCH_BUTTON"); ?>">
            <svg viewBox="0 0 32 32" width="32">
                <use xlink:href="<?= Icon::get('search'); ?>"></use>
            </svg>
        </button>

        <label class="search-label">
            <input id="<?= $INPUT_ID ?>"
                   type="text"
                   name="q"
                   class="search-input"
                   placeholder="<?= Loc::getMessage('SEARCH_PLACEHOLDER'); ?>"
                   autocomplete="off"
            >
        </label>
        <div>
            <button id="header-search-clear"
                    class="header__search-icon header__search-clear text-secondary-500 d-none"
                    type="button"
                    title="<?= Loc::getMessage('CT_BST_CLEAR_BUTTON') ?>"
            >
                <svg width="24" height="24">
                    <use xlink:href="<?= Icon::get('close'); ?>"></use>
                </svg>
            </button>

            <?if ($arParams['USE_SPEECH'] === 'Y'):?>
                <button id="header-search-speech"
                        class="header__search-icon header__search-speech text-secondary-500 d-none"
                        type="button"
                        title="<?= Loc::getMessage('CT_BST_USE_SPEECH') ?>"
                >
                    <svg width="24" height="24">
                        <use xlink:href="<?= Icon::get('microphone'); ?>"></use>
                    </svg>
                </button>
            <?endif;?>
        </div>

        <div id="header-search-result" class="search-dropdown d-none"></div>
    </form>
<?php } ?>

<script>
	BX.ready(function() {
		new SearchTitle({
			'AJAX_PAGE' : '<?= CUtil::JSEscape(POST_FORM_ACTION_URI) ?>',
			'CONTAINER_ID': '<?= $CONTAINER_ID ?>',
			'INPUT_ID': '<?= $INPUT_ID ?>',
			'MIN_QUERY_LEN': 2,
            'USE_SPEECH': Boolean('<?=$arParams['USE_SPEECH'] === 'Y'?>'),
		});
	});
</script>
