<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/** @var string $templateFolder */

use Bitrix\Catalog;
use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Public\Image;

?>

<ul class="search-dropdown-list custom-scrollbar">
    <?php
    if (empty($arResult["CATEGORIES"])) { ?>
        <li class="search-dropdown-item">
            <?= Loc::getMessage('NOTHING_FOUND') ?>
        </li>
        <?php
    } ?>

    <?php
    foreach ($arResult['CATEGORIES'] as $categoryIndex => $category) { ?>
        <?php
        foreach ($category["ITEMS"] as $itemIndex => $item) { ?>
            <?php
            if ($categoryIndex === 'all') { ?>
                <li class="search-dropdown-item text-center fw-medium">
                    <a href="<?= $item["URL"] ?>">
                        <?= $item["NAME"] ?>
                    </a>
                </li>
                <?php
            } elseif (isset($arResult["ELEMENTS"][$item["ITEM_ID"]])) {
                $element = $arResult["ELEMENTS"][$item["ITEM_ID"]];
                ?>
                <li class="search-dropdown-item <?= (int)$element["CATALOG_TYPE"] === Catalog\ProductTable::TYPE_SKU ? 'type-sku' : '' ?>">
                    <a class="text-dark d-flex" href="<?= $item['URL'] ?>">
                        <?php
                        if (is_array($element["PICTURE"])) { ?>
                            <div class="me-4 border-radius-sm flex-shrink-0" style="width: 64px; height: 64px;">
                                <?= Image::loadLazy(
                                    $element["PICTURE"]["src"],
                                    strip_tags($item['NAME']),
                                    [
                                        'IMAGE' =>
                                            [
                                                'class' => 'img-contain',
                                                'width' => $element["PICTURE"]['WIDTH'],
                                                'height' => $element["PICTURE"]['HEIGHT']
                                            ]
                                    ]
                                ) ?>
                            </div>
                            <?php
                        } else { ?>
                            <div class="me-4 border-radius-sm flex-shrink-0" style="width: 64px; height: 64px;">

                                <img src="<?= $templateFolder . '/images/no_photo.svg' ?>"
                                     alt="<?= strip_tags($item['NAME']) ?>">
                            </div>
                            <?php
                        } ?>

                        <div class="d-flex flex-column">
                            <span>
                                <?= $item['NAME'] ?>
                            </span>

                            <?php
                            if ($element["PRICES"]) { ?>
                                <div class="d-flex mt-2">
                                    <?php
                                    foreach ($element["PRICES"] as $code => $price) {
                                        if ($price["MIN_PRICE"] != "Y") {
                                            continue;
                                        }

                                        if ($price["CAN_ACCESS"]) {
                                            if ($price["DISCOUNT_VALUE"] < $price["VALUE"]) { ?>
                                                <div class="d-flex flex-wrap gap-3">
                                                    <span class="fs-3 fw-bold text-dark"><?= $price["PRINT_DISCOUNT_VALUE"] ?></span>
                                                    <span class="fs-3 fw-medium text-secondary-500 text-line-through"><?= $price["PRINT_VALUE"] ?></span>
                                                </div>
                                                <?php
                                            } else { ?>
                                                <div class="d-flex gap-2">
                                                    <span class="fs-3 fw-bold text-dark"><span
                                                                class="price-from"><?= Loc::getMessage(
                                                                'PRICE_FROM'
                                                            ); ?></span> <?= $price["PRINT_VALUE"] ?></span>
                                                </div>
                                                <?php
                                            }
                                        }

                                        if ($price["MIN_PRICE"] == "Y") {
                                            break;
                                        }
                                    } ?>
                                </div>
                                <?php
                            } ?>
                        </div>
                    </a>
                </li>
                <?php
            } else {
                if ($item['TYPE'] === 'all') {
                    continue;
                }
                $section = $arResult['SECTIONS'][mb_substr($item["ITEM_ID"], 1)];
                ?>
                <li class="search-dropdown-item">
                    <a class="text-dark d-flex" href="<?= $item["URL"] ?>">
                        <?php
                        if (is_array($section["PICTURE"])) { ?>
                            <div class="me-4 border-radius-sm flex-shrink-0" style="width: 64px; height: 64px;">
                                <?= Image::loadLazy(
                                    $section["PICTURE"]["src"],
                                    strip_tags($item['NAME']),
                                    [
                                        'IMAGE' => [
                                            'class' => 'img-contain',
                                            'width' => $section["PICTURE"]['WIDTH'],
                                            'height' => $section["PICTURE"]['HEIGHT'],
                                        ]
                                    ]
                                ) ?>
                            </div>
                            <?php
                        } else { ?>
                            <div class="me-4 border-radius-sm flex-shrink-0" style="width: 64px; height: 64px;">
                                <img src="<?= $templateFolder . '/images/no_photo.svg' ?>"
                                     alt="<?= strip_tags($item['NAME']) ?>">
                            </div>
                            <?php
                        } ?>

                        <div class="d-flex flex-column">
                            <span><?= $item["NAME"] ?></span>

                            <?php
                            if ($section && count($section['PATH']) > 1) { ?>
                                <span class="text-secondary-500"><?= implode(' / ', $section['PATH']) ?></span>
                                <?php
                            } ?>
                        </div>
                    </a>
                </li>
                <?php
            } ?>
            <?php
        } ?>
        <?php
    } ?>
</ul>
