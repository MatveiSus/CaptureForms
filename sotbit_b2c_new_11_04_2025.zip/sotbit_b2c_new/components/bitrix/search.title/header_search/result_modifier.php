<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$PREVIEW_WIDTH = intval($arParams["PREVIEW_WIDTH"]);

if ($PREVIEW_WIDTH <= 0) {
    $PREVIEW_WIDTH = 64;
}

$PREVIEW_HEIGHT = intval($arParams["PREVIEW_HEIGHT"]);

if ($PREVIEW_HEIGHT <= 0) {
    $PREVIEW_HEIGHT = 64;
}

$arParams["PRICE_VAT_INCLUDE"] = $arParams["PRICE_VAT_INCLUDE"] !== "N";

$arCatalogs = false;

$arResult["ELEMENTS"] = array();
$arResult["SEARCH"] = array();

foreach ($arResult["CATEGORIES"] as $category_id => $arCategory) {
    foreach ($arCategory["ITEMS"] as $i => $arItem) {
        if (isset($arItem["ITEM_ID"])) {
            $arResult["SEARCH"][] = &$arResult["CATEGORIES"][$category_id]["ITEMS"][$i];

            if ( // item is iblock element
                $arItem["MODULE_ID"] == "iblock"
                && mb_substr($arItem["ITEM_ID"], 0, 1) !== "S"
            ) {
                $arResult["ELEMENTS"][$arItem["ITEM_ID"]] = $arItem["ITEM_ID"];
            } elseif ( // item is iblock section
                $arItem["MODULE_ID"] == "iblock"
                && mb_substr($arItem["ITEM_ID"], 0, 1) === "S"
            ) {
                $sectionId = mb_substr($arItem["ITEM_ID"], 1);
                $arResult["SECTIONS"][$sectionId] = $arItem["PARAM2"];
            }
        }
    }
}

if (!empty($arResult["ELEMENTS"]) && CModule::IncludeModule("iblock")) {
    $arConvertParams = array();
    if ('Y' == $arParams['CONVERT_CURRENCY']) {
        if (!CModule::IncludeModule('currency')) {
            $arParams['CONVERT_CURRENCY'] = 'N';
            $arParams['CURRENCY_ID'] = '';
        } else {
            $arCurrencyInfo = CCurrency::GetByID($arParams['CURRENCY_ID']);
            if (!(is_array($arCurrencyInfo) && !empty($arCurrencyInfo))) {
                $arParams['CONVERT_CURRENCY'] = 'N';
                $arParams['CURRENCY_ID'] = '';
            } else {
                $arParams['CURRENCY_ID'] = $arCurrencyInfo['CURRENCY'];
                $arConvertParams['CURRENCY_ID'] = $arCurrencyInfo['CURRENCY'];
            }
        }
    }

    $obParser = new CTextParser;

    if (is_array($arParams["PRICE_CODE"])) {
        $arResult["PRICES"] = CIBlockPriceTools::GetCatalogPrices(0, $arParams["PRICE_CODE"]);
    } else {
        $arResult["PRICES"] = array();
    }

    $arSelect = array(
        "ID",
        "IBLOCK_ID",
        "PREVIEW_TEXT",
        "PREVIEW_PICTURE",
        "DETAIL_PICTURE",
        "TYPE",
        "PROPERTY_CML2_LINK"
    );
    $arFilter = array(
        "IBLOCK_LID" => SITE_ID,
        "IBLOCK_ACTIVE" => "Y",
        "ACTIVE_DATE" => "Y",
        "ACTIVE" => "Y",
        "CHECK_PERMISSIONS" => "Y",
        "MIN_PERMISSION" => "R",
    );

    foreach ($arResult["PRICES"] as $value) {
        $arSelect[] = $value["SELECT"];
        $arFilter["CATALOG_SHOP_QUANTITY_" . $value["ID"]] = 1;
    }

    $arFilter["=ID"] = $arResult["ELEMENTS"];
    $arResult["ELEMENTS"] = array();

    $rsElements = CIBlockElement::GetList(
        array(),
        $arFilter,
        false,
        false,
        $arSelect
    );

    while ($arElement = $rsElements->Fetch()) {
        $arElement["PRICES"] = CIBlockPriceTools::GetItemPrices(
            $arElement["IBLOCK_ID"],
            $arResult["PRICES"],
            $arElement,
            $arParams['PRICE_VAT_INCLUDE'],
            $arConvertParams
        );

        if ($arParams["PREVIEW_TRUNCATE_LEN"] > 0) {
            $arElement["PREVIEW_TEXT"] = $obParser->html_cut($arElement["PREVIEW_TEXT"], $arParams["PREVIEW_TRUNCATE_LEN"]);
        }

        $arResult["ELEMENTS"][$arElement["ID"]] = $arElement;
    }
}

if (!empty($arResult["SECTIONS"]) && CModule::IncludeModule("iblock")) {
    $resSectionsPictures = CIBlockSection::GetList(
        [],
        [
            'ID' => array_keys($arResult["SECTIONS"])
        ],
        false,
        [
            'ID',
            'PICTURE',
            'DETAIL_PICTURE'
        ]
    );

    $arSectionPictures = [];

    while ($arSectionPicture = $resSectionsPictures->Fetch()) {
        $arSectionPictures[$arSectionPicture['ID']] = [
            'PICTURE' => $arSectionPicture['PICTURE'],
            'DETAIL_PICTURE' => $arSectionPicture['DETAIL_PICTURE'],
        ];
    }

    foreach ($arResult["SECTIONS"] as $sectionId => $iblockId) {
        $arSectionPath = CIBlockSection::GetNavChain($iblockId, $sectionId, [], true);
        $arResult["SECTIONS"][$sectionId] = array_merge([], $arSectionPictures[$sectionId]);
        $arResult["SECTIONS"][$sectionId]['PATH'] = array_map(fn($section) => $section['NAME'], $arSectionPath);
    }
}

$resizeImg = function ($id) use ($PREVIEW_WIDTH, $PREVIEW_HEIGHT) {
    return CFile::ResizeImageGet(
        $id,
        array(
            "width" => $PREVIEW_WIDTH,
            "height" => $PREVIEW_HEIGHT
        ),
        BX_RESIZE_IMAGE_PROPORTIONAL, true
    );
};

$getPictureFromMain = function ($productId) use ($resizeImg) {
    $arElement = \Bitrix\Iblock\ElementTable::query()
        ->setSelect(['DETAIL_PICTURE', 'PREVIEW_PICTURE'])
        ->where('ID', $productId)
        ->fetch();

    $idImg = $arElement['PREVIEW_PICTURE'] ?: $arElement['DETAIL_PICTURE'] ?: null;
    return !is_null($idImg) ? $resizeImg($idImg) : null;
};


foreach ($arResult["SEARCH"] as $i => &$arItem) {
    switch ($arItem["MODULE_ID"]) {
        case "iblock":
            if (array_key_exists($arItem["ITEM_ID"], $arResult["ELEMENTS"])) {
                $arElement = &$arResult["ELEMENTS"][$arItem["ITEM_ID"]];

                if ($arParams["SHOW_PREVIEW"] == "Y") {
                    if ($arElement["PREVIEW_PICTURE"] > 0) {
                        $arElement["PICTURE"] = $resizeImg($arElement["PREVIEW_PICTURE"]);
                    } elseif ($arElement["DETAIL_PICTURE"] > 0) {
                        $arElement["PICTURE"] = $resizeImg($arElement["DETAIL_PICTURE"]);
                    } elseif ((int)$arElement["TYPE"] === \Bitrix\Catalog\ProductTable::TYPE_OFFER) {
                        $arElement["PICTURE"] = $getPictureFromMain($arElement['PROPERTY_CML2_LINK_VALUE']);
                    }
                }

                /*if ((int)$arElement["TYPE"] === \Bitrix\Catalog\ProductTable::TYPE_OFFER && \Sotbit\B2C\Helper\Config::get('CATALOG_SEO_USE_DISTINCT_URL') === 'Y') {
                    $arItem['URL'] = $arItem['URL'] . "{$arElement['ID']}/";
                }*/
            } elseif ($arResult["SECTIONS"] && array_key_exists(mb_substr($arItem["ITEM_ID"], 1), $arResult["SECTIONS"])) {
                $arSection = &$arResult["SECTIONS"][mb_substr($arItem["ITEM_ID"], 1)];

                if ($arParams["SHOW_PREVIEW"] == "Y") {
                    if ($arSection["PICTURE"] > 0) {
                        $arSection["PICTURE"] = $resizeImg($arSection["PICTURE"]);
                    } elseif ($arSection["DETAIL_PICTURE"] > 0) {
                        $arSection["PICTURE"] = $resizeImg($arSection["DETAIL_PICTURE"]);
                    }
                }
            }
            break;
    }

    $arResult["SEARCH"][$i]["ICON"] = true;
}
