<?php
$MESS['NOTHING_FOUND'] = 'Ничего не найдено';
$MESS['PRICE_FROM'] = 'от';
