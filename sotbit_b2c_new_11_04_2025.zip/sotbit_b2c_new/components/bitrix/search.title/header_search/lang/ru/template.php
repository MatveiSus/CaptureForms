<?php

$MESS['CT_BST_SEARCH_BUTTON'] = 'Поиск';
$MESS['SEARCH_PLACEHOLDER'] = 'Поиск товаров';
$MESS["CT_BST_CLEAR_BUTTON"] = "Очистить поисковую строку";
$MESS["CT_BST_USE_SPEECH"] = "Использовать голосовой поиск";
