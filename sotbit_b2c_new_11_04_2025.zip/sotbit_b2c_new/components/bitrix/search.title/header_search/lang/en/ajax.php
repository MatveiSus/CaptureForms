<?php
$MESS["NOTHING_FOUND"] = "Nothing found";
$MESS["PRICE_FROM"] = "from";
