<?php
$MESS["CT_BST_SEARCH_BUTTON"] = "Search";
$MESS["SEARCH_PLACEHOLDER"] = "Search for products";
$MESS["CT_BST_CLEAR_BUTTON"] = "Clear search bar";
$MESS["CT_BST_USE_SPEECH"] = "Use voice search";
