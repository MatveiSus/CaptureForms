class SearchTitle {
    constructor(params) {
        this.params = params;
        this.ajaxPage = params.AJAX_PAGE;
        this.container = document.getElementById(params.CONTAINER_ID);
        this.input = this.container.querySelector(`#${params.INPUT_ID}`);
        this.clearButton = this.container.querySelector('#header-search-clear');
        this.resultContainer = this.container.querySelector('#header-search-result');
        this.minQueryLength = parseInt(params.MIN_QUERY_LEN) || 1;
        this.isOpen = false;
        this.useSpeech = params.USE_SPEECH;

        this.addEventListeners();
    }

    showDropdown() {
        if (this.isOpen) {
            return;
        }

        BX.Sotbit.B2C.showElement(this.resultContainer, {
            duration: 100,
            callback: () => {
                this.isOpen = true;

                document.addEventListener('click', (event) => {
                    if (!event.composedPath().includes(this.resultContainer)) {
                        this.hideDropdown();
                    }
                }, {once: true})
            }
        });
    }

    hideDropdown() {
        if (!this.isOpen) {
            return;
        }

        BX.Sotbit.B2C.hideElement(this.resultContainer, {
            duration: 100,
            callback: () => this.isOpen = false
        });
    }

    clearInput() {
        this.input.value = '';
        BX.Sotbit.B2C.hideElement(this.clearButton, {duration: 100});
        this.hideDropdown();
        this.setResult('');
    }

    setResult(html) {
        this.resultContainer.innerHTML = html;
    }

    sendRequest(query) {
        return BX.ajax.promise({
            url: this.ajaxPage,
            method: 'POST',
            data: {
                'ajax_call': 'y',
                'INPUT_ID': this.params.INPUT_ID,
                'q': query,
                'l': this.minQueryLength
            },
            dataType: 'html',
        });
    }

    handleInput() {
        const query = this.input.value;

        if (query) {
            BX.Sotbit.B2C.showElement(this.clearButton, {duration: 100});
        } else {
            BX.Sotbit.B2C.hideElement(this.clearButton, {duration: 100});
        }

        this.sendRequest(query)
            .then(response => {
                this.setResult(response);
                response ? this.showDropdown() : this.hideDropdown();
            });
    }

    handleInputDebounced = BX.debounce(this.handleInput, 300).bind(this);

    addEventListeners() {
        this.input.addEventListener('input', this.handleInputDebounced.bind(this));
        this.input.addEventListener('click', this.showDropdown.bind(this));
        this.clearButton.addEventListener('click', this.clearInput.bind(this));

        if (this.useSpeech) {
            this.speech = this.container.querySelector(`#header-search-speech`);

            if (!window.webkitSpeechRecognition && !window.SpeechRecognition) {
                console.warn("Your browser does not support the SpeechRecognition API");
                this.speech.remove();
                return;
            }

            this.transcriptionInProgress = null;
            this.speech.classList.remove('d-none');
            this.speech.addEventListener('click', this.speechEvent.bind(this));
        }
    }

    speechEvent() {
        if (this.transcriptionInProgress) {
            this.transcriptionInProgress.stop();
        } else {
            this.transcriptionInProgress = window.webkitSpeechRecognition ? new webkitSpeechRecognition() : new SpeechRecognition();
            this.transcriptionInProgress.lang = navigator.language || 'ru-RU';
            this.transcriptionInProgress.interimResults = true;
            this.transcriptionInProgress.addEventListener("result", (e) => {
                this.input.value = e.results[0][0].transcript;
                this.handleInput();
            });

            this.transcriptionInProgress.addEventListener("end", () => {
                this.transcriptionInProgress = null;
                this.speech.classList.toggle('speech');
            });

            this.transcriptionInProgress.addEventListener("start", () => {
                this.speech.classList.toggle('speech');
            });

            this.transcriptionInProgress.addEventListener("error", (e) => {
                console.warn('sotbit.smartsearch: ' + (e.error === 'not-allowed' ? 'no permission to use microphone' : e.error));
                this.speech.classList.toggle('speech');
            });

            this.transcriptionInProgress.start();
        }
    }
}
