<?php

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var array $arParams
 * @var array $arResult
 */

use Bitrix\Main\Application;

include(
    Application::getDocumentRoot()
    . SITE_TEMPLATE_PATH
    . '/components/bitrix/catalog.section/'
    . $this->getName()
    . '/result_modifier.php'
);
