<?php

use Bitrix\Main\Application;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @global CMain $APPLICATION
 * @var array $arParams
 * @var array $arResult
 * @var CatalogTopComponent $component
 * @var CBitrixComponentTemplate $this
 * @var string $templateName
 * @var string $componentPath
 * @var string $templateFolder
 */

$this->setFrameMode(true);

$componentId = $this->randString();

if (!empty($arResult['ITEMS'])) {
    $elementEdit = CIBlock::GetArrayByID($arParams['IBLOCK_ID'], 'ELEMENT_EDIT');
    $elementDelete = CIBlock::GetArrayByID($arParams['IBLOCK_ID'], 'ELEMENT_DELETE');
    $elementDeleteParams = array('CONFIRM' => GetMessage('CT_BCT_ELEMENT_DELETE_CONFIRM'));

    $fullPath = Application::getDocumentRoot() . $templateFolder;
    $templateLibrary = array();
    $currencyList = '';

    if (!empty($arResult['CURRENCIES'])) {
        $currencyList = CUtil::PhpToJSObject($arResult['CURRENCIES'], false, true, true);
    }

    $templateData = array(
        'TEMPLATE_THEME' => $arParams['TEMPLATE_THEME'],
        'TEMPLATE_CLASS' => 'bx_' . $arParams['TEMPLATE_THEME'],
        'TEMPLATE_LIBRARY' => $templateLibrary,
        'CURRENCIES' => $currencyList
    );
    unset($currencyList, $templateLibrary);

    include($fullPath . '/section/template.php');

    ?>
    <script type='text/javascript'>
        BX.message({
            BTN_MESSAGE_BASKET_REDIRECT: '<?=GetMessageJS('CT_BCT_CATALOG_BTN_MESSAGE_BASKET_REDIRECT')?>',
            BASKET_URL: '<?=$arParams['BASKET_URL']?>',
            ADD_TO_BASKET_OK: '<?=GetMessageJS('ADD_TO_BASKET_OK')?>',
            TITLE_ERROR: '<?=GetMessageJS('CT_BCT_CATALOG_TITLE_ERROR')?>',
            TITLE_BASKET_PROPS: '<?=GetMessageJS('CT_BCT_CATALOG_TITLE_BASKET_PROPS')?>',
            TITLE_SUCCESSFUL: '<?=GetMessageJS('ADD_TO_BASKET_OK', ["#BASKET_LINK#" => $arParams['BASKET_URL']])?>',
            TITLE_SUCCESSFUL_REMOVE: '<?=GetMessageJS('REMOVE_FROM_BASKET_OK', ["#BASKET_LINK#" => $arParams['BASKET_URL']])?>',
            BASKET_UNKNOWN_ERROR: '<?=GetMessageJS('CT_BCT_CATALOG_BASKET_UNKNOWN_ERROR')?>',
            BTN_MESSAGE_SEND_PROPS: '<?=GetMessageJS('CT_BCT_CATALOG_BTN_MESSAGE_SEND_PROPS')?>',
            BTN_MESSAGE_CLOSE: '<?=GetMessageJS('CT_BCT_CATALOG_BTN_MESSAGE_CLOSE')?>',
            BTN_MESSAGE_CLOSE_POPUP: '<?=GetMessageJS('CT_BCT_CATALOG_BTN_MESSAGE_CLOSE_POPUP')?>',
            COMPARE_MESSAGE_OK: '<?=GetMessageJS('CT_BCT_CATALOG_MESS_COMPARE_OK', ['#COMPARE_LINK#' => $arParams['COMPARE_URL'] ?? ""])?>',
            COMPARE_MESSAGE_DELETE: '<?=GetMessageJS('CT_BCT_CATALOG_MESS_COMPARE_DELETE')?>',
            COMPARE_UNKNOWN_ERROR: '<?=GetMessageJS('CT_BCT_CATALOG_MESS_COMPARE_UNKNOWN_ERROR')?>',
            COMPARE_TITLE: '<?=GetMessageJS('CT_BCT_CATALOG_MESS_COMPARE_TITLE')?>',
            PRICE_TOTAL_PREFIX: '<?=GetMessageJS('CT_BCT_CATALOG_PRICE_TOTAL_PREFIX')?>',
            BTN_MESSAGE_COMPARE_REDIRECT: '<?=GetMessageJS('CT_BCT_CATALOG_BTN_MESSAGE_COMPARE_REDIRECT')?>',
            PRICE_FROM: '<?= GetMessageJS('CT_BCT_TPL_MESS_PRICE_FROM') ?>',
            SITE_ID: '<?=CUtil::JSEscape($component->getSiteId())?>',
            TO_FAVORITE: '<?= GetMessageJS('CT_BC_CATALOG_TO_FAVORITE') ?>',
            IN_FAVORITE: '<?= GetMessageJS('CT_BC_CATALOG_IN_FAVORITE') ?>',
            TO_COMPARE: '<?= GetMessageJS('CT_BC_CATALOG_TO_COMPARE') ?>',
            IN_COMPARE: '<?= GetMessageJS('CT_BC_CATALOG_IN_COMPARE') ?>',
        });
    </script>
    <?php
}
