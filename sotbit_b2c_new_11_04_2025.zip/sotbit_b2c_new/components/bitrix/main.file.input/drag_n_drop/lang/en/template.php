<?
$MESS["BFDND_FILE_LOADING"] = "Loading";
$MESS["BFDND_FILE_EXISTS"] = "A file with this name already exists. You can select the current folder, in which case the old version of the file will be saved in the document history.";
$MESS["BFDND_UPLOAD_ERROR"] = "An error occurred while saving the file.";
$MESS["BFDND_FILES"] = "Files:";
$MESS["BFDND_DROPHERE"] = "Drag one or more files to this area or";
$MESS["BFDND_DROPHERE_SINGLE"] = "Drag a file to this area or";
$MESS["BFDND_SELECT_EXIST"] = "Select a file on your device";
$MESS["BFDND_SELECT_LOCAL"] = "Upload files";
$MESS["BFDND_ACCESS_DENIED"] = "Access denied";
$MESS["BFDND_UPLOAD_IMAGES"] = "Upload images";
$MESS["BFDND_UPLOAD_FILES"] = "Upload files";
?>