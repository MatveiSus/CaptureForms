;(function () {
    NotificationPopup = function (params) {
        this.signedParams = params.signed_params;
        this.btnNotification = document.querySelector(params.btnNotification);
        this.btnClose = document.querySelector(params.btnClose);
        this.dropNotice = document.querySelector(params.dropNotice);
        this.fade = document.querySelector(params.fade);
        this.body = document.querySelector("body");
        this.oldNotice = document.querySelector("[data-notice='old']");
        this.oldNoticeTitle = document.querySelector(params.oldNoticeTitle);
        this.newNotice = document.querySelector("[data-notice='new']");
        this.newNoticeTitle = document.querySelector(params.newNoticeTitle);
        this.newNoticeOnline = document.querySelector(params.newNoticeOnline);
        this.defaultNotice = document.querySelector(params.defaultNotice);
        this.emptyNotification = document.querySelector(params.emptyNotification);
        this.divider = document.querySelector(params.divider);
        this.templateImg = params.templateImg;
        this.counter = params.counter;
        this.siteId = params.siteId;
        this.readable = [];
        this.readableID = [];
        this.debounceTime = null;
        this.observerObject = null;
        this.isInit = false;
        this.isHideNotice = params.isHideNotice;

        this.init();
    };

    NotificationPopup.prototype.init = function () {
        if (this.btnNotification) {
            BX.bind(this.btnNotification, 'click', BX.delegate(this.openPopup, this));
        }

        BX.addCustomEvent("onPullEvent-sotbit.notification", function (command, params, module_id) {
            if (command === 'noty' && params.SITE_ID.includes(this.siteId)) {
                if(!this.isHideNotice){
                    this.newOnlineNoty(params);
                }
                this.addNewNotice(params);
            }
        }.bind(this));
    };

    NotificationPopup.prototype.openPopup = function () {
        if (!event?.target || event.target.closest('.noty_close_button')) return;

        this.flag = false;
        if (this.dropNotice.classList.contains('sotbit-notification_show')) {
            if (!event?.target || event.target.closest('.noty_body')) return;
            this.closePopup();
        } else {
            this.dropNotice.classList.add('sotbit-notification_show');
            this.fade.classList.add('sotbit-notification_fade');
            BX.bind(this.btnClose, 'click', BX.proxy(this.closePopup, this));
            BX.bind(this.fade, 'click', BX.proxy(this.closePopup, this));
            BX.Sotbit.B2C.fixBodyScroll();
            if (this.isInit) {
                return;
            }
            this.observer();
            this.isInit = true;
        }
    };

    NotificationPopup.prototype.closePopup = function () {
        this.flag = true;
        this.dropNotice.classList.remove('sotbit-notification_show');
        this.fade.classList.remove('sotbit-notification_fade');
        if (this.readableID.length !== 0) {
            this.getReadableNotice();
        }
        // this.unobserver();
        BX.unbind(this.btnClose, 'click', BX.proxy(this.closePopup, this));
        BX.unbind(this.fade, 'click', BX.proxy(this.closePopup, this));
        BX.Sotbit.B2C.unfixBodyScroll();
    };

    NotificationPopup.prototype.callbackObserver = function (entries, observer) {
        entries.forEach(entry => {
            const id = entry.target.dataset.id;
            if (entry.isIntersecting) {
                observer.unobserve(entry.target);
                this.readable.push(id);
            }
        });
        if (this.readable.length !== 0) {
            this.sendRequest();
        }
    };

    NotificationPopup.prototype.observer = function () {
        const options = {
            threshold: 1.0
        };

        this.observerObject = new IntersectionObserver(this.callbackObserver.bind(this), options);
        document.querySelectorAll('[data-read="N"]').forEach((i) => {
            if (i) {
                this.observerObject.observe(i)
            }
        });
    };

    NotificationPopup.prototype.unobserver = function () {
        if (this.observerObject !== null) {
            this.observerObject.disconnect();
        }
    };

    NotificationPopup.prototype.sendRequest = function () {
        clearTimeout(this.debounceTime);
        this.debounceTime = setTimeout(() => {
            const read = BX.ajax.runComponentAction('sotbit:notification.notice', 'read', {
                mode: 'class',
                data: {
                    readable: this.readable,
                },
                signedParameters: this.signedParams
            }).then(response => {
                const data = response.data;
                if (response.data.length !== 0) {
                    this.changeCounter(this.counter, data.length);
                    this.readableID = this.readableID.concat(data);
                    if (this.flag) {
                        this.getReadableNotice();
                    }
                }
            }, error => {
                console.error(error);
            });
            this.readable = [];
        }, 1000);

    };

    NotificationPopup.prototype.getReadableNotice = function () {
        setTimeout(() => {
            if (this.oldNoticeTitle.style.display === 'none') {
                this.oldNoticeTitle.style.display = 'block';
            }

            this.readableID.forEach(data => {
                let item = document.querySelector('.sotbit-notification_notice_content[data-id="' + data + '"]');
                let itemClone = item.cloneNode(true);
                itemClone.dataset.read = 'Y';
                this.oldNotice.prepend(itemClone);
                item.remove();
            });

            if (this.newNotice.innerHTML.trim() === '') {
                this.newNoticeTitle.style.display = 'none';
                this.divider.classList.remove('show');
            }
            this.readableID = [];
        }, 100);
    };

    NotificationPopup.prototype.newOnlineNoty = function (params) {
        const wrapper = document.querySelector('.sotbit-notification_new_notice');

        new Noty({
            text: wrapper.innerHTML,
            type: 'info',
            timeout: 5000,
            closeWith: ['click', 'button'],
            progressBar: false,
            callbacks: {
                onClose: this.openPopup.bind(this)
            },
            newId: params.ID,
        }).on('onShow', function () {
            const newNotClose = document.querySelector('[data-newid="' + this.options.newId + '"] + .noty_close_button');

            newNotClose.innerHTML = '<svg width="9" height="9" viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg">\n' +
                '                <path d="M1 1L9 9" stroke="#999999" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>\n' +
                '                <path d="M1 9L9 1" stroke="#999999" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>\n' +
                '            </svg>';
        }).on('onTemplate', function () {
            this.barDom.innerHTML = '<div class="noty_body" data-newid="' + this.options.newId + '">' + this.options.text + '<div>';
        }).show();
    };

    NotificationPopup.prototype.addNewNotice = function (params) {
        if(this.newNotice.querySelector('[data-id="' + params.ID + '"]')){
            return;
        }

        const noticeClone = this.defaultNotice.cloneNode(true);
        const noticeMessage = noticeClone.querySelector('.sotbit-notification_notice_text .sotbit-notification_notice_message');
        const noticeFullDate = noticeClone.querySelector('.sotbit-notification_notice_calendar span');
        const noticeShortDate = noticeClone.querySelector('.sotbit-notification_notice_clock span');
        const newCount = document.querySelector('.sotbit-notification_counter');

        this.changeCounter(Number(newCount.innerText), 1, "+");

        noticeClone.classList.remove('sotbit-notification_notice_default');
        noticeClone.classList.add('sotbit-notification_notice_content');
        noticeClone.dataset.read = 'N';
        noticeClone.dataset.id = params.ID;

        let input = document.createElement('div');
        (params.NOTICE_MESSAGE.match(/&.+;/ig) || []).forEach(entity => {
            // Insert the HTML entity as HTML in an HTML element:
            input.innerHTML = entity;
            // Retrieve the HTML elements innerText to get the parsed entity (the actual character):
            params.NOTICE_MESSAGE = params.NOTICE_MESSAGE.replace(entity, input.innerText);
        });

        noticeMessage.innerHTML = params.NOTICE_MESSAGE;
        noticeFullDate.innerText = params.FULL_DATE;
        noticeShortDate.innerText = params.SHORT_DATE;

        if(this.emptyNotification){
            this.emptyNotification.remove();
            this.emptyNotification = null;
        }

        this.prependNewNotice(noticeClone);
        this.addItemObserver(noticeClone);
    };

    NotificationPopup.prototype.addItemObserver = function (item) {
        if(this.observerObject !== null){
            this.observerObject.observe(item);
        }
    }

    NotificationPopup.prototype.changeCounter = function (counter, count, calcView = "-") {
        const newCount = document.querySelector('.sotbit-notification_counter');
        if(calcView === "+"){
            this.counter = newCount.innerText = counter + count;
        }else{
            this.counter = newCount.innerText = counter - count;
        }
    };

    NotificationPopup.prototype.getImage = function () {
        return this.templateImg;
    };

    NotificationPopup.prototype.prependNewNotice = function (noticeClone) {
        this.newNotice.prepend(noticeClone);
        if (this.newNotice.innerHTML.trim() !== '') {
            this.newNoticeTitle.style.display = 'block';
            this.divider?.classList.add('show');
        }
    };
})();
