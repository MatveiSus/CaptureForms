<?php
$MESS['SOTBIT_NOTIFICATION_MAIN_TITLE'] = 'Уведомления';
$MESS['SOTBIT_NOTIFICATION_NEW_NOTICE'] = 'Новые уведомления';
$MESS['SOTBIT_NOTIFICATION_OLD_NOTICE'] = 'Старые уведомления';
$MESS['SOTBIT_NOTIFICATION_NEW_NOTICE_ONLINE'] = 'У вас новое уведомление!';
$MESS['SOTBIT_NOTIFICATION_EMPTY_NOTY'] = 'Новых уведомлений пока нет';