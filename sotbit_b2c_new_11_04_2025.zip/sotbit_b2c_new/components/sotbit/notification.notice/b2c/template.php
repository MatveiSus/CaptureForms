<?php

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Page\Asset;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();


Asset::getInstance()->addJs($templateFolder . "/notify.min.js");
Asset::getInstance()->AddCSS($templateFolder . "/notify.min.css");

$templatePathSvg = Bitrix\Main\Application::getInstance()->getDocumentRoot() . $templateFolder . '/img/';
$tempImgFolder = $templateFolder . '/img/';

function renderNotice ($el, $isRead): string
{
    return <<<HTML
    <div class="sotbit-notification_notice_content" data-id="{$el['ID']}" data-read="{$isRead}">
        <div class="sotbit-notification_notice_text">
            <div class="sotbit-notification_notice_message">
                {$el['NOTICE_MESSAGE']}
            </div>
            <div class="sotbit-notification_notice_date">
                <span class="sotbit-notification_notice_date-item">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 2C14.4183 2 18 5.58172 18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10C2 5.58172 5.58172 2 10 2ZM10 3C6.13401 3 3 6.13401 3 10C3 13.866 6.13401 17 10 17C13.866 17 17 13.866 17 10C17 6.13401 13.866 3 10 3ZM9.5 5C9.74546 5 9.94961 5.17688 9.99194 5.41012L10 5.5V10H12.5C12.7761 10 13 10.2239 13 10.5C13 10.7455 12.8231 10.9496 12.5899 10.9919L12.5 11H9.5C9.25454 11 9.05039 10.8231 9.00806 10.5899L9 10.5V5.5C9 5.22386 9.22386 5 9.5 5Z" fill="currentColor"/>
                    </svg>
                    <span>
                        {$el['SHORT_DATE']}
                    </span>
                </span>
                <span class="sotbit-notification_notice_date-item">
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 8C4.55228 8 5 7.55229 5 7C5 6.44771 4.55228 6 4 6C3.44772 6 3 6.44771 3 7C3 7.55229 3.44772 8 4 8ZM5 10C5 10.5523 4.55228 11 4 11C3.44772 11 3 10.5523 3 10C3 9.44771 3.44772 9 4 9C4.55228 9 5 9.44771 5 10ZM7 8C7.55229 8 8 7.55229 8 7C8 6.44771 7.55229 6 7 6C6.44771 6 6 6.44771 6 7C6 7.55229 6.44771 8 7 8ZM8 10C8 10.5523 7.55229 11 7 11C6.44771 11 6 10.5523 6 10C6 9.44771 6.44771 9 7 9C7.55229 9 8 9.44771 8 10ZM10 8C10.5523 8 11 7.55229 11 7C11 6.44771 10.5523 6 10 6C9.44771 6 9 6.44771 9 7C9 7.55229 9.44771 8 10 8ZM14 2.5C14 1.11929 12.8807 0 11.5 0H2.5C1.11929 0 0 1.11929 0 2.5V11.5C0 12.8807 1.11929 14 2.5 14H11.5C12.8807 14 14 12.8807 14 11.5V2.5ZM1 4H13V11.5C13 12.3284 12.3284 13 11.5 13H2.5C1.67157 13 1 12.3284 1 11.5V4ZM2.5 1H11.5C12.3284 1 13 1.67157 13 2.5V3H1V2.5C1 1.67157 1.67157 1 2.5 1Z" fill="currentColor"/>
                    </svg>
                    <span>
                        {$el['FULL_DATE']}
                    </span>
                </span>
            </div>
        </div>
    </div>
HTML;
}
?>
<div class="sotbit-notification">
    <div class="sotbit-notification_bell">
        <svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.9353 1.1107C11.7878 0.403096 10.4351 -0.00378418 8.98764 -0.00378418C4.8341 -0.00378418 1.47805 3.34043 1.47746 7.49409V11.591L0.103945 14.748C-0.171468 15.3811 0.119275 16.1171 0.753337 16.3921C0.910705 16.4603 1.08044 16.4955 1.25202 16.4955L5.98312 16.4948L5.98867 16.6733C6.08004 18.2477 7.38779 19.4962 8.98764 19.4962C10.6467 19.4962 11.9917 18.1535 11.9917 16.497L16.7329 16.4955C17.4241 16.4955 17.9846 15.9361 17.9846 15.2459C17.9846 15.0736 17.9489 14.9031 17.8797 14.7452L16.4978 11.5901V7.4942L16.4936 7.24332C16.4892 7.11504 16.4816 6.98762 16.4709 6.86113C16.1616 6.95032 15.8347 6.99812 15.4966 6.99812C15.3185 6.99812 15.1435 6.98485 14.9725 6.95926C14.9818 7.066 14.9884 7.17357 14.9921 7.28191L14.9959 7.50705L14.9958 11.9036L16.3502 14.996H1.63369L2.97949 11.9026V7.4942C2.97997 4.16935 5.66297 1.49582 8.98764 1.49582C10.1554 1.49582 11.2457 1.82629 12.1682 2.39997C12.329 1.91443 12.5934 1.47597 12.9353 1.1107ZM7.48561 16.497L10.4892 16.4948L10.4828 16.6415C10.41 17.4019 9.7684 17.9966 8.98764 17.9966C8.15809 17.9966 7.48561 17.3252 7.48561 16.497Z" fill="currentColor"/>
            <path d="M13.033 3.05278C13.1282 2.52565 13.3889 2.05596 13.7595 1.69933C14.2097 1.26614 14.822 0.999729 15.4966 0.999729C16.8792 0.999729 18 2.11872 18 3.49906C18 4.59195 17.2974 5.521 16.3185 5.86055C16.0611 5.94986 15.7845 5.99839 15.4966 5.99839C15.2482 5.99839 15.0083 5.96227 14.7818 5.89501C13.7475 5.58789 12.9932 4.63141 12.9932 3.49906C12.9932 3.34674 13.0069 3.19759 13.033 3.05278Z" fill="currentColor"/>
        </svg>
        <div class="sotbit-notification_counter">
            <?= $arResult['COUNTER'] ?>
        </div>
    </div>
</div>
<div class="sotbit-notification_wrapper">
    <div class="sotbit-notification_main_title">
        <div class="sotbit-notification_main_header">
            <h5><?= Loc::getMessage("SOTBIT_NOTIFICATION_MAIN_TITLE") ?></h5>
        </div>
        <button class="sotbit-notification_button_close">
            <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 1.6L14.4 0L8 6.4L1.6 0L0 1.6L6.4 8L0 14.4L1.6 16L8 9.6L14.4 16L16 14.4L9.6 8L16 1.6Z"/>
            </svg>
        </button>
    </div>
    <?php
        if(!$arResult['UNREAD'] && !$arResult['READ']){
    ?>
        <div class="sotbit-notification_empty">
            <div class="sotbit-notification_empty_title">
                <span> <?= Loc::getMessage("SOTBIT_NOTIFICATION_EMPTY_NOTY") ?>  </span>
            </div>
            <div class="sotbit-notification_empty_img">
                <img src="<?= $tempImgFolder . 'empty_noty.svg'?>" alt="Empty notification">
            </div>
        </div>
            <?php
        }
    ?>
    <div class="sotbit-notification_list-notices">
    <div class="sotbit-notification_notice_new">
        <div class="sotbit-notification_notice_title sotbit-notification_title_new" <?= !$arResult['UNREAD'] ? 'style="display: none"' : '' ?>>
            <?= Loc::getMessage("SOTBIT_NOTIFICATION_NEW_NOTICE") ?>
        </div>
        <div class="sotbit-notification_notice" data-notice="new">
            <?php foreach ($arResult['UNREAD'] as $unread) {
                echo renderNotice($unread, 'N');
            } ?>
        </div>
    </div>
        <hr class="sotbit-notification_notice-divider <?php echo $arResult['UNREAD'] && $arResult['READ'] ? 'show' : ''?>" />
    <div class="sotbit-notification_notice_old">
        <div class="sotbit-notification_notice_title sotbit-notification_title_old" <?= !$arResult['READ'] ? 'style="display: none"' : '' ?>>
            <?= Loc::getMessage("SOTBIT_NOTIFICATION_OLD_NOTICE") ?>
        </div>
        <div class="sotbit-sotbit-notification_notice" data-notice="old">
            <?php foreach ($arResult['READ'] as $read) {
                echo renderNotice($read, 'Y');
            } ?>
        </div>
    </div>
    </div>
</div>
<div class="sotbit-notification_new_notice_wrapper">
    <div class="sotbit-notification_new_notice">
        <svg width="19" height="20" viewBox="0 0 21 22" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.9046 12.4057C16.111 10.4701 15.7141 8.43016 15.7141 6.28576C15.7141 4.93535 15.3215 3.86328 14.536 3.06928C13.75 2.27534 12.6696 1.7964 11.2945 1.63279C11.3599 1.48556 11.3925 1.33416 11.3925 1.17863C11.3925 0.851224 11.278 0.572715 11.0489 0.343741C10.8198 0.114509 10.5416 0 10.2141 0C9.88691 0 9.60857 0.114509 9.37934 0.343741C9.15015 0.572887 9.03564 0.851224 9.03564 1.17863C9.03564 1.33416 9.06832 1.48543 9.13389 1.63279C7.75889 1.79658 6.67847 2.27529 5.89278 3.06928C5.10713 3.86323 4.71433 4.9353 4.71433 6.28576C4.71433 8.43016 4.31748 10.4701 3.52349 12.4057C2.72954 14.3413 1.55513 15.9681 0 17.2858C0 17.7114 0.15553 18.0797 0.466548 18.3906C0.777523 18.7016 1.14577 18.8573 1.57151 18.8573H7.07149C7.07149 19.7249 7.3783 20.4656 7.99216 21.0793C8.60607 21.693 9.34683 22 10.2143 22C11.0819 22 11.8227 21.693 12.4363 21.0793C13.0501 20.4656 13.357 19.7249 13.357 18.8573H18.857C19.2826 18.8573 19.6512 18.7019 19.9618 18.3906C20.2729 18.0797 20.4285 17.7114 20.4285 17.2858C18.8736 15.9681 17.6991 14.3413 16.9046 12.4057Z"/>
        </svg>
        <span><?= Loc::getMessage("SOTBIT_NOTIFICATION_NEW_NOTICE_ONLINE") ?></span>
        <div class="sotbit-notification_button_close_notice"></div>
    </div>
</div>
<div class="sotbit-notification_notice_default" data-id="" data-read="N">
    <div class="sotbit-notification_notice_text">
        <div class="sotbit-notification_notice_message"></div>
        <div class="sotbit-notification_notice_date">
            <span class="sotbit-notification_notice_date-item sotbit-notification_notice_clock sotbit-notification_span">
               <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10 2C14.4183 2 18 5.58172 18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10C2 5.58172 5.58172 2 10 2ZM10 3C6.13401 3 3 6.13401 3 10C3 13.866 6.13401 17 10 17C13.866 17 17 13.866 17 10C17 6.13401 13.866 3 10 3ZM9.5 5C9.74546 5 9.94961 5.17688 9.99194 5.41012L10 5.5V10H12.5C12.7761 10 13 10.2239 13 10.5C13 10.7455 12.8231 10.9496 12.5899 10.9919L12.5 11H9.5C9.25454 11 9.05039 10.8231 9.00806 10.5899L9 10.5V5.5C9 5.22386 9.22386 5 9.5 5Z" fill="currentColor"/>
                    </svg>
                <span></span>
            </span>
            <span class=" sotbit-notification_notice_date-item sotbit-notification_notice_calendar sotbit-notification_span">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 8C4.55228 8 5 7.55229 5 7C5 6.44771 4.55228 6 4 6C3.44772 6 3 6.44771 3 7C3 7.55229 3.44772 8 4 8ZM5 10C5 10.5523 4.55228 11 4 11C3.44772 11 3 10.5523 3 10C3 9.44771 3.44772 9 4 9C4.55228 9 5 9.44771 5 10ZM7 8C7.55229 8 8 7.55229 8 7C8 6.44771 7.55229 6 7 6C6.44771 6 6 6.44771 6 7C6 7.55229 6.44771 8 7 8ZM8 10C8 10.5523 7.55229 11 7 11C6.44771 11 6 10.5523 6 10C6 9.44771 6.44771 9 7 9C7.55229 9 8 9.44771 8 10ZM10 8C10.5523 8 11 7.55229 11 7C11 6.44771 10.5523 6 10 6C9.44771 6 9 6.44771 9 7C9 7.55229 9.44771 8 10 8ZM14 2.5C14 1.11929 12.8807 0 11.5 0H2.5C1.11929 0 0 1.11929 0 2.5V11.5C0 12.8807 1.11929 14 2.5 14H11.5C12.8807 14 14 12.8807 14 11.5V2.5ZM1 4H13V11.5C13 12.3284 12.3284 13 11.5 13H2.5C1.67157 13 1 12.3284 1 11.5V4ZM2.5 1H11.5C12.3284 1 13 1.67157 13 2.5V3H1V2.5C1 1.67157 1.67157 1 2.5 1Z" fill="currentColor"/>
                    </svg>
                <span></span>
            </span>
        </div>
    </div>
</div>
<div class="sotbit-notification_backdrop"></div>

<script>
    new NotificationPopup({
        btnNotification: ".sotbit-notification",
        btnClose: ".sotbit-notification_button_close",
        dropNotice: ".sotbit-notification_wrapper",
        fade: ".sotbit-notification_backdrop",
        newNoticeTitle: ".sotbit-notification_title_new",
        oldNoticeTitle: ".sotbit-notification_title_old",
        newNoticeOnline: ".sotbit-notification_new_notice",
        defaultNotice: ".sotbit-notification_notice_default",
        emptyNotification: ".sotbit-notification_empty",
        divider: ".sotbit-notification_notice-divider",
        counter: "<?= $arResult['COUNTER'] ?>",
        templateImg: "<?= $tempImgFolder ?>",
        siteId: "<?= SITE_ID ?>",
        signed_params: '<?= $this->getComponent()->getSignedParameters() ?>',
        isHideNotice: true
    });
</script>
