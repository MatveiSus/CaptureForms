<?php
$MESS["SA_REVIEW_TITLE_COUNT_REVIEW_1"] = "review";
$MESS["SA_REVIEW_TITLE_COUNT_REVIEW_2"] = "review";
$MESS["SA_REVIEW_TITLE_COUNT_REVIEW_3"] = "reviews";
$MESS['SA_REVIEW_USER_CONSENT_VIEW_LABEL_TEXT'] = 'When submitting a review, please read <a>the publication rules</a>';
