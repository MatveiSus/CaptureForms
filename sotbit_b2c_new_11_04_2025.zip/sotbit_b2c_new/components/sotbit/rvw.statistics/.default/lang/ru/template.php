<?php
$MESS['SA_REVIEW_TITLE_COUNT_REVIEW_1'] = 'отзыв';
$MESS['SA_REVIEW_TITLE_COUNT_REVIEW_2'] = 'отзыва';
$MESS['SA_REVIEW_TITLE_COUNT_REVIEW_3'] = 'отзывов';
$MESS['SA_REVIEW_USER_CONSENT_VIEW_LABEL_TEXT'] = 'Отправляя отзыв, пожалуйста, ознакомьтесь с <a>правилами публикации</a>';
