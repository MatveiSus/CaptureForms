<?php
$MESS['B2C_SEO_META_TAGS_DISPLAY_VARIANT'] = 'Отображать кастомное облако тегов';
$MESS['B2C_SEO_META_TAGS_DISPLAY_VARIANT_TOP'] = 'Сверху';
$MESS['B2C_SEO_META_TAGS_DISPLAY_VARIANT_BOTTOM'] = 'Снизу';