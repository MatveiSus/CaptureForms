<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;

$this->setFrameMode(true);

if (!$arResult['ITEMS']) {
    return;
}

$HIDE_COUNT = 15;

$this->SetViewTarget($arResult['VIEW_TARGET_NAME']);
?>

<div class="mb-6">
    <?if ($arResult['ITEMS_DEFAULT']):?>
        <div id="seometa-customtags" class="tags-pills__wrapper d-flex flex-row gap-4 flex-wrap shave mb-6">
            <?foreach ($arResult['ITEMS_DEFAULT'] as $k => $item):
                $count = $arParams['PRODUCT_COUNT'] === 'Y' ? ' (' . $item['PRODUCT_COUNT'] . ')' : '';
                ?>
                <a href="<?= $item['URL'] ?>" class="pill <?= $k > $HIDE_COUNT ? 'hide' : '' ?>"
                   title="<?= $item['TITLE'] . $count ?>">
                    <?= $item['TITLE'] . $count ?>
                </a>
            <?endforeach;?>
            <a href="javascript: void(0)" data-type="shave" class="fw-medium <?= $k <= $HIDE_COUNT ? 'd-none' : '' ?>"><?=Loc::getMessage('B2C_META_TAGS_BTN_SHOW');?></a>
        </div>

        <script>
            BX.ready(() => {
                new B2CMetaCustomTags({
                    wrap: 'seometa-customtags',
                    message: {
                        btn: ['<?=Loc::getMessage('B2C_META_TAGS_BTN_HIDE')?>', '<?=Loc::getMessage('B2C_META_TAGS_BTN_SHOW')?>']
                    }
                })
            });
        </script>
    <?endif;?>

    <?if ($arResult['ITEMS_IMAGE']):?>
        <div class="custom-tags__wrap d-flex flex-row gap-5 flex-wrap">
            <?foreach ($arResult['ITEMS_IMAGE'] as $item):
                $count = $arParams['PRODUCT_COUNT'] === 'Y' ? ' (' . $item['PRODUCT_COUNT'] . ')' : '';
                ?>
                <a href="<?= $item['URL'] ?>" class="custom-tags__item-img d-flex flex-column flex-wrap gap-3"
                   title="<?= $item['TITLE'] . $count ?>">
                    <img src="<?=$item['IMAGE']['SRC']?>" alt="<?= $item['TITLE'] ?>">
                    <span class="fs-2 fw-medium text-center"><?= $item['TITLE'] . $count ?></span>
                </a>
            <?endforeach;?>
        </div>
    <?endif;?>
</div>

<?php
$this->EndViewTarget();
?>
