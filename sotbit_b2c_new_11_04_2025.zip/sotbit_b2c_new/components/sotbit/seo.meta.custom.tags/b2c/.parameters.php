<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;


$arTemplateParameters['DISPLAY_VARIANT'] = array(
    'NAME' => Loc::getMessage('B2C_SEO_META_TAGS_DISPLAY_VARIANT'),
    'TYPE' => 'LIST',
    'MULTIPLE' => 'N',
    'ADDITIONAL_VALUES' => 'N',
    'VALUES' => array(
        'TOP' => Loc::getMessage('B2C_SEO_META_TAGS_DISPLAY_VARIANT_TOP'),
        'BOTTOM' => Loc::getMessage('B2C_SEO_META_TAGS_DISPLAY_VARIANT_BOTTOM'),
    )
);
