<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

if (!$arResult['ITEMS']) {
    return;
}

$viewTarget = 'sotbit_b2c_seo_custom_tags_';
$arResult['VIEW_TARGET_NAME'] = $arParams['DISPLAY_VARIANT'] === 'TOP' ? $viewTarget . 'top' :  $viewTarget . 'bottom';
$arResult['ITEMS_IMAGE'] = array_values(array_filter($arResult['ITEMS'], fn($item) => isset($item['IMAGE'])));
$arResult['ITEMS_DEFAULT'] = array_values(array_filter($arResult['ITEMS'], fn($item) => !isset($item['IMAGE'])));