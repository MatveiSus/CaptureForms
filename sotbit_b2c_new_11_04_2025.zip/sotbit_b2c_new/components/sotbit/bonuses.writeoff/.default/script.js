class SotbitBonusesWriteOff {
    constructor(params = {}) {
        this.initParams = params;
        this.component = params.component || {};
        this.errorClass = params.errorClass || '';
        this.delayApply = 800;
        this.callbackApply = params.callbackApply || null;
        this.callbackReload = params.callbackReload || null;
        this.orderStopEvent = false;
        this.init(params);
        this.initEvents();
    }

    async reloadData() {
        try {
            const {data} = await BX.ajax.runComponentAction('sotbit:bonuses.writeoff', 'reloadComponent', {
                mode: 'class',
                data: {
                    templateName: this.component?.templateName
                },
                signedParameters: this.component?.signedParameters
            });

            data.html && (this.componentWrap.outerHTML = data.html);
            this.init(this.initParams);
        } catch (reject) {
            console.error(reject.errors.map(error => error.message).join('\n'))
        }
    }

    init(params = {}) {
        if (!params.componentWrap) {
            console.error('Component wrap id not specified');
            return;
        }

        this.componentWrap = document.getElementById(params.componentWrap);
        if (!this.componentWrap) {
            console.error('Component wrap not found on page');
            return;
        }

        this.appliedBlock = params.appliedBlock ? document.getElementById(params.appliedBlock) : null;
        if (this.appliedBlock && params.appliedQnt) {
            this.appliedQnt = this.appliedBlock.querySelector(params.appliedQnt);
        }

        if (params.resetBtn) {
            this.resetBtn = document.getElementById(params.resetBtn);
        }

        this.input = this.componentWrap.getElementsByTagName('input')[0];
        this.error = null;

        this.input && this.input.addEventListener('input', BX.debounce(() => this.applyBonuses(this.input.value), this.delayApply, this));
        this.input && this.input.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
            }
        });
        this.resetBtn && this.resetBtn.addEventListener('click', () => this.resetBonuses());
    }

    initEvents() {
        BX.Event.EventEmitter.subscribe('onAjaxSuccess', (event) => {
            if (this.orderStopEvent) {
                this.orderStopEvent = false;
                return;
            }

            const [rawData] = event.getCompatData();
            if (rawData?.hasOwnProperty('order')) {
                this.reloadData().then(() => {
                    if (typeof (this.callbackReload) === 'function') {
                        this.callbackReload(this);
                    }
                });
            }
        });
    }

    async applyBonuses(quantity) {
        try {
            const {data} = await BX.ajax.runComponentAction('sotbit:bonuses.writeoff', 'applyBonuses', {
                mode: 'class',
                data: {
                    'quantity': quantity || 0,
                },
                signedParameters: this.component?.signedParameters
            });

            this.renderApplied(parseInt(data));

            if (typeof (this.callbackApply) === 'function') {
                this.callbackApply(data, this);
            }

            this.reloadOrder();
        } catch (reject) {
            this.createError(reject.errors.map(error => error.message).join('\n'));
        }
    }

    resetBonuses() {
        this.applyBonuses(0).then(() => {
            this.input.value = '';
        });
    }

    renderApplied(quantity = 0) {
        this.resetError();

        if (!this.appliedBlock) {
            return;
        }

        this.appliedQnt && (this.appliedQnt.innerText = quantity);
        this.appliedBlock.classList[quantity > 0 ? 'remove' : 'add']('d-none');

        if (this.appliedQnt.nextElementSibling) {
            this.appliedQnt.nextElementSibling.innerText = BX.Loc.getMessagePlural('BONUSES_WRITEOFF_APPLIED_TEXT', quantity);
        }
    }

    reloadOrder() {
        this.orderStopEvent = true;
        BX.Sale.OrderAjaxComponent && BX.Sale.OrderAjaxComponent.sendRequest();
    }

    createError(message) {
        if (this.error) {
            this.error.innerText = message;
            BX.Sotbit.B2C.showElement(this.error, {duration: 100});
            return;
        }

        this.error = BX.create('div', {
            props: {
                className: this.errorClass,
            },
            text: message
        });

        this.componentWrap.querySelector('[data-type="title"]').insertAdjacentElement('afterend', this.error);
    }

    resetError() {
        this.error && BX.Sotbit.B2C.hideElement(this.error, {duration: 100});
    }
}
