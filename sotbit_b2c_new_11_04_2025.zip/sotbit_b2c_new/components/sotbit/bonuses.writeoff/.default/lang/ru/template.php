<?php
$MESS['BONUSES_WRITEOFF_TITLE'] = 'Бонусы';
$MESS['BONUSES_WRITEOFF_AVAILABLE'] = 'Доступно к списанию: ';
$MESS['BONUSES_WRITEOFF_RATE'] = '(1 бонус = #RATE#)';
$MESS['BONUSES_WRITEOFF_NOT_AVAILABLE'] = 'Нет доступных к списанию';
$MESS['BONUSES_WRITEOFF_INPUT_PLACEHOLDER'] = 'Введите сумму списания';
$MESS['BONUSES_WRITEOFF_APPLIED_TEXT_PLURAL_0'] = ' - бонус применен';
$MESS['BONUSES_WRITEOFF_APPLIED_TEXT_PLURAL_1'] = ' - бонуса применено';
$MESS['BONUSES_WRITEOFF_APPLIED_TEXT_PLURAL_2'] = ' - бонусов применено';
$MESS['BONUSES_WRITEOFF_RESET_BTN'] = 'Отменить';
