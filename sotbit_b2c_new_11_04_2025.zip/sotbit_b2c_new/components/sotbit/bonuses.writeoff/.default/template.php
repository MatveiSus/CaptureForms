<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;

$isEnable = $arResult['BONUSES']['MAX_AVAILABLE_QUANTITY'] > 0;
?>

<div id="bonuses_writeoff" class="bonuses_writeoff__wrapper">
    <p class="fs-4 fw-medium mb-4" data-type="title"><?= Loc::getMessage('BONUSES_WRITEOFF_TITLE') ?></p>

    <div class="d-flex flex-column">
        <?php
        if (!empty($arResult['BONUSES']['WARNINGS'])): ?>
            <div class="text-warning">
                <?= implode('<br>', $arResult['BONUSES']['WARNINGS']) ?>
            </div>
        <?php
        endif; ?>

        <div class="d-flex flex-column flex-grow-1 gap-2">
            <label class="fs-1 fw-medium" for="ui-input-1">
                <?php
                if ($isEnable): ?>
                    <?= Loc::getMessage('BONUSES_WRITEOFF_AVAILABLE') ?>
                    <?= $arResult['BONUSES']['MAX_AVAILABLE_QUANTITY'] ?>
                    <span class="text-secondary-500">
                <?= Loc::getMessage('BONUSES_WRITEOFF_RATE', ['#RATE#' => $arResult['BONUSES']['RATE_FORMATTED']]) ?>
            </span>
                <?php
                else: ?>
                    <?= Loc::getMessage('BONUSES_WRITEOFF_NOT_AVAILABLE') ?>
                <?php
                endif; ?>
            </label>
            <input class="input-text"
                   type="text"
                   placeholder="<?= Loc::getMessage('BONUSES_WRITEOFF_INPUT_PLACEHOLDER') ?>"
                   value="<?= $arResult['BONUSES']['APPLIED'] ?: '' ?>"
                   name="quantity"
                <?= !$isEnable ? 'disabled' : '' ?>
            >
        </div>

        <div id="bonuses_applied"
             class="d-flex flex-row flex-nowrap align-items-center justify-content-between g-3 mt-3 <?= $arResult['BONUSES']['APPLIED'] === 0 ? 'd-none' : '' ?>">
            <div>
                <b data-type="value"><?= $arResult['BONUSES']['APPLIED'] ?></b>
                <span><?= Loc::getMessagePlural('BONUSES_WRITEOFF_APPLIED_TEXT', $arResult['BONUSES']['APPLIED']) ?></span>
            </div>
            <div>
                <button id="bonuses_reset" type="button" class="btn btn-secondary btn-small"
                        name="reset"><?= Loc::getMessage('BONUSES_WRITEOFF_RESET_BTN') ?></button>
            </div>
        </div>
    </div>
</div>


<script>
    BX.message(<?= \Bitrix\Main\Web\Json::encode(Loc::loadLanguageFile(__FILE__)) ?>);
    document.addEventListener('DOMContentLoaded', () => {
        window.SotbitBonusesWriteOff = new SotbitBonusesWriteOff({
            'componentWrap': 'bonuses_writeoff',
            'appliedBlock': 'bonuses_applied',
            'resetBtn': 'bonuses_reset',
            'appliedQnt': '[data-type="value"]',
            'errorClass': 'text-error mb-3',
            'component': {
                'signedParameters': '<?=$this->getComponent()->getSignedParameters()?>',
                'templateName': '<?=$this->getComponent()->getTemplateName()?>'
            }
        });
    })
</script>
