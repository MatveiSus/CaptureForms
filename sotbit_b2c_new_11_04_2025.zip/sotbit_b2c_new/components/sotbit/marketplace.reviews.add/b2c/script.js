(function () {
    SM_ReviewsAdd = {
        init: function (params) {
            this.mainModal = document.querySelector('[data-entity="review-add-modal"]');
            this.form = this.mainModal.querySelector('form');

            if (!this.form) {
                return;
            }

            this.showModalButton = document.querySelector('[data-entity="review-add-show-form-button"]');
            this.ratingButtons = this.mainModal.querySelectorAll('[data-entity="review-add-star"]');
            this.ratingDescription = this.mainModal.querySelector('[data-entity="review-add-rating-text"]');
            this.ratingInput = this.form.querySelector('input[name="RATING"]');
            this.hiddenInputs = [];
            this.fileUploadUrl = params.fileUploadUrl;
            this.maxFileSize = params.maxFileSize;
            this.maxFiles = params.maxFiles;
            this.imagesFolder = params.imagesFolder;
            this.defaultRating = params.defaultRating;
            this.useAgreement = params.useAgreement;
            this.agreementTitle = params.agreementTitle;
            this.agreementText = params.agreementText;
            this.mainModalOverlay = null;

            this.addEventListeners();
        },

        initStarRatingEvents: function () {
            this.ratingButtons.forEach(button => button.addEventListener('click', () => {
                const rating = button.dataset.rating;
                this.setRatingValue(rating);
                this.showRating(rating);
            }));

            this.ratingButtons.forEach(button => button.addEventListener('mouseover', () => this.showRating(button.dataset.rating)));
            this.ratingButtons.forEach(button => button.addEventListener('mouseout', () => this.showRating(this.ratingInput.value)));
        },

        setRatingValue: function (rating) {
            this.ratingInput.value = rating;
        },

        showRating: function (rating) {
            this.ratingButtons.forEach(button => {
                button.classList.remove('active');

                if (button.dataset.rating <= rating) {
                    button.classList.add('active');
                }
            });

            this.ratingDescription.textContent = BX.message(`review_add_rating_${rating}`);
        },

        dropzoneInit: async function () {
            if (!window.Dropzone) {
                await BX.loadExt('sotbit.b2c.dropzone');
            }

            Dropzone.autoDiscover = false;

            this.dropzone = new Dropzone(this.mainModal.querySelector('[data-entity="review-add-dropzone"]'), {
                previewTemplate: `
                    <div class="dz-file-preview dz-preview">
                        <div class="dz-image">
                            <img data-dz-thumbnail="">
                        </div>
                        <div class="dz-details">
                            <div class="dz-filename">
                                <span data-dz-name=""></span>
                            </div>
                        </div>
                        <div class="dz-progress">
                            <span class="dz-upload" data-dz-uploadprogress=""></span>
                        </div>
                        <div class="dz-error-message">
                            <span data-dz-errormessage=""></span>
                        </div>
                        <div class="dz-success-mark">
                            <svg width="54" height="54" fill="#fff">
                                <path d="m10.207 29.793 4.086-4.086a1 1 0 0 1 1.414 0l5.586 5.586a1 1 0 0 0 1.414 0l15.586-15.586a1 1 0 0 1 1.414 0l4.086 4.086a1 1 0 0 1 0 1.414L22.707 42.293a1 1 0 0 1-1.414 0L10.207 31.207a1 1 0 0 1 0-1.414Z"/>
                            </svg>
                        </div>
                        <div class="dz-error-mark">
                            <svg width="54" height="54" fill="#fff">
                                <path d="m26.293 20.293-7.086-7.086a1 1 0 0 0-1.414 0l-4.586 4.586a1 1 0 0 0 0 1.414l7.086 7.086a1 1 0 0 1 0 1.414l-7.086 7.086a1 1 0 0 0 0 1.414l4.586 4.586a1 1 0 0 0 1.414 0l7.086-7.086a1 1 0 0 1 1.414 0l7.086 7.086a1 1 0 0 0 1.414 0l4.586-4.586a1 1 0 0 0 0-1.414l-7.086-7.086a1 1 0 0 1 0-1.414l7.086-7.086a1 1 0 0 0 0-1.414l-4.586-4.586a1 1 0 0 0-1.414 0l-7.086 7.086a1 1 0 0 1-1.414 0Z"/>
                            </svg>
                        </div>
                    </div>
                `,
                url: this.fileUploadUrl,
                parallelUploads: 100,
                maxFiles: this.maxFiles,
                maxFilesize: Number(this.maxFileSize) || 500,
                paramName: 'FILES_MEDIA',
                acceptedFiles: 'image/*, video/*',
                dictDefaultMessage: BX.message('dropzone_message'),
                dictRemoveFile: BX.message('dropzone_delete'),
                addRemoveLinks: true,
                dictMaxFilesExceeded: BX.message('dropzone_error_max_files'),
                dictCancelUpload: BX.message('dropzone_delete'),
                dictUploadCanceled: BX.message('dropzone_cancel'),
                dictFileTooBig: BX.message('dropzone_file_too_big'),
                thumbnailWidth: 120,
                thumbnailHeight: 160
            });

            this.dropzone.on("maxfilesexceeded", () => {
                return BX.Sotbit.B2C.showMessage(BX.message('dropzone_error_max_files'), {icon: 'error'});
            });

            this.dropzone.on("addedfile", () => {
                this.dropzone.previewsContainer.querySelectorAll('.dz-placeholder').forEach(element => element.remove());

                this.dropzone.previewsContainer.prepend(BX.create('button', {
                    props: {
                        className: 'dz-placeholder',
                        type: 'button'
                    },
                    html: `
                        <svg viewBox="0 0 24 24" width="24">
                            <use xlink:href="${this.imagesFolder}/camera.svg#icon"></use>
                        </svg>
                    `
                }));

                for (let i = 0; i < this.dropzone.options.maxFiles - this.dropzone.files.length; i++) {
                    this.dropzone.previewsContainer.appendChild(BX.create('div', {
                        props: {
                            className: 'dz-placeholder'
                        }
                    }));
                }
            });

            this.dropzone.on("success", (file, response) => {
                const result = JSON.parse(response);
                file.id = result.file.id;
                this.form.appendChild(
                    this.hiddenInputs[result.file.id] = BX.create('input', {
                        attrs: {
                            'type': 'hidden',
                            'name': 'MEDIA[]',
                            'value': result.file.id
                        }
                    })
                );
            });

            this.dropzone.on("removedfile", file => {
                BX.remove(this.hiddenInputs[file.id]);

                BX.ajax.post(
                    this.fileUploadUrl,
                    {
                        action: 'removedfile',
                        fileId: file.id
                    }
                );

                if (!this.dropzone.files.length) {
                    this.dropzone.previewsContainer.querySelectorAll('.dz-placeholder').forEach((e) => e.remove());
                }
            });
        },

        sendReview: function (event) {
            event.preventDefault();

            this.mainModalOverlay.hide();
            BX.Sotbit.B2C.hideElement(this.mainModal);
            BX.showWait();

            BX.ajax.runComponentAction('sotbit:marketplace.reviews.add', 'addReview', {
                mode: 'class',
                data: new FormData(this.form),
            }).then(
                () => {
                    BX.Sotbit.B2C.showPopup({
                        title: BX.message('success_title'),
                        iconHtml: `<svg xmlns="http://www.w3.org/2000/svg" width="73" height="72" viewBox="0 0 73 72" fill="none">
                                       <g clip-path="url(#clip0_5968_10686)">
                                           <path d="M36.5 72C56.3823 72 72.5 55.8823 72.5 36C72.5 16.1177 56.3823 0 36.5 0C16.6177 0 0.5 16.1177 0.5 36C0.5 55.8823 16.6177 72 36.5 72Z" fill="#32B76C"/>
                                           <path d="M31.0437 54.6734L14.45 38.0797C14.225 37.8547 14.225 37.5172 14.45 37.2922L19.2313 32.5109C19.4563 32.2859 19.7938 32.2859 20.0188 32.5109L31.4375 43.9297L52.925 22.4422C53.15 22.2172 53.4875 22.2172 53.7125 22.4422L58.4937 27.2234C58.7188 27.4484 58.7188 27.7859 58.4937 28.0109L31.8313 54.6734C31.6063 54.8984 31.2687 54.8984 31.0437 54.6734Z" fill="white"/>
                                       </g>
                                       <defs>
                                           <clipPath id="clip0_5968_10686">
                                               <rect width="72" height="72" fill="white" transform="translate(0.5)"/>
                                           </clipPath>
                                       </defs>
                                   </svg>`,
                        showConfirmButton: false,
                        centerTitle: true,
                    });

                    this.form.reset();
                    this.setRatingValue(this.defaultRating);
                    this.showRating(this.defaultRating);
                },
                (error) => {
                    BX.Sotbit.B2C.showPopup({
                        title: error.errors.map(item => item.message).join('\n'),
                        iconHtml: `<svg width="73" height="72" viewBox="0 0 73 72" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <g clip-path="url(#clip0_6093_11246)">
                                           <path d="M36.5 72C56.3823 72 72.5 55.8823 72.5 36C72.5 16.1177 56.3823 0 36.5 0C16.6177 0 0.5 16.1177 0.5 36C0.5 55.8823 16.6177 72 36.5 72Z" fill="#E31C1C"/>
                                           <g clip-path="url(#clip1_6093_11246)">
                                               <path d="M56 20L52 16L36 32L20 16L16 20L32 36L16 52L20 56L36 40L52 56L56 52L40 36L56 20Z" fill="white"/>
                                           </g>
                                       </g>
                                       <defs>
                                           <clipPath id="clip0_6093_11246">
                                               <rect width="72" height="72" fill="white" transform="translate(0.5)"/>
                                           </clipPath>
                                           <clipPath id="clip1_6093_11246">
                                               <rect width="40" height="40" fill="white" transform="translate(16 16)"/>
                                           </clipPath>
                                       </defs>
                                   </svg>`,
                        showConfirmButton: false,
                        centerTitle: true,
                    });
                }
            );
        },

        showAgreementModal: function () {
            BX.Sotbit.B2C.showPopup({
                width: '800px',
                title: this.agreementTitle,
                html: this.agreementText,
                showConfirmButton: false,
                showDenyButton: false,
                showCancelButton: false,
                fixBodyScroll: false
            })
        },

        addEventListeners: function () {
            this.showModalButton.addEventListener('click', async () => {
                if (!this.dropzone) {
                    BX.showWait();
                    await this.dropzoneInit();
                    BX.closeWait();
                }

                this.mainModalOverlay = BX.Sotbit.B2C.showOverlay();

                this.mainModalOverlay.element.addEventListener('click', () => {
                    this.mainModalOverlay.hide();
                    BX.Sotbit.B2C.hideElement(this.mainModal, {
                        callback: () => BX.Sotbit.B2C.unfixBodyScroll()
                    });
                });

                BX.Sotbit.B2C.fixBodyScroll();
                BX.Sotbit.B2C.showElement(this.mainModal);
            });

            this.mainModal.querySelector('[data-entity="review-add-close-form-button"]').addEventListener('click', () => {
                this.mainModalOverlay?.hide();
                BX.Sotbit.B2C.hideElement(this.mainModal, {
                    callback: () => BX.Sotbit.B2C.unfixBodyScroll()
                });
            });

            if (this.useAgreement) {
                this.mainModal.querySelector('[data-entity="review-add-show-agreement-button"]')
                    .addEventListener('click', () => this.showAgreementModal());
            }

            this.form.addEventListener('submit', (event) => this.sendReview(event));

            this.initStarRatingEvents();
        }
    }
})();
