<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var array $arParams
 * @var array $arResult
 * @var string $templateFolder
 */

use Bitrix\Main\{
    Localization\Loc,
    UI\Extension
};
use Sotbit\B2C\Public\Icon;
use Sotbit\B2C\Public\Image;

?>

<button type="button" class="btn btn-secondary" data-entity="review-add-show-form-button">
    <?= Loc::getMessage('SM_REVIEW_ADD_BUTTON_TITLE'); ?>
</button>

<div class="review-add d-none" data-entity="review-add-modal">
    <div class="review-add__header">
        <div class="review-add__top">
            <h2 class="review-add__title">
                <?= Loc::getMessage('SM_REVIEW_ADD_FORM_TITLE'); ?>
            </h2>
            <button class="review-add__close" data-entity="review-add-close-form-button">
                <svg width="24" height="24">
                    <use xlink:href="<?= Icon::get('close') ?>"></use>
                </svg>
            </button>
        </div>
        <div class="review-add__product">
            <div class="review-add__product-image">
                <img class="img-contain"
                     src="<?= $arResult['PRODUCT']['IMG']['src'] ?: $templateFolder . '/images/no_photo.png' ?>"
                     alt="<?= $arResult['PRODUCT']['NAME'] ?>"
                >
            </div>
            <span class="review-add__product-name"><?= $arResult['PRODUCT']['NAME'] ?></span>
        </div>
        <div class="review-add__rating">
            <div class="review-add__stars">
                <?php
                for ($i = 1; $i <= 5; $i++) { ?>
                    <button class="review-add__star<?= $i <= (int)$arParams['DEFAULT_RATING'] ? ' active' : '' ?>"
                            data-entity="review-add-star"
                            data-rating="<?= $i ?>"
                    ></button>
                    <?php
                } ?>
            </div>
            <span class="review-add__rating-text"
                  data-entity="review-add-rating-text"
            ><?= Loc::getMessage('SM_REVIEW_ADD_RATING_' . $arParams['DEFAULT_RATING']) ?></span>
        </div>
    </div>
    <div class="review-add__body custom-scrollbar">
        <div class="review-add__form-container">
            <form class="review-add__form custom-scrollbar" id="review-add-form" action="/">
                <input type="hidden" name="RATING" value="<?= $arParams['DEFAULT_RATING'] ?>">
                <input type="hidden" name="PRODUCT_ID" value="<?= $arResult['PRODUCT']['ID'] ?>">
                <label class="review-add__field">
                    <span class="review-add__field-name"><?= Loc::getMessage('SM_REVIEW_ADD_DIGNITY') ?></span>
                    <input class="input-text"
                           type="text"
                           name="DIGNITY"
                           placeholder="<?= Loc::getMessage('SM_REVIEW_ADD_PLACEHOLDER') ?>"
                    >
                </label>
                <label class="review-add__field">
                    <span class="review-add__field-name"><?= Loc::getMessage('SM_REVIEW_ADD_FLAWS') ?></span>
                    <input class="input-text"
                           type="text"
                           name="FLAWS"
                           placeholder="<?= Loc::getMessage('SM_REVIEW_ADD_PLACEHOLDER') ?>"
                    >
                </label>
                <label class="review-add__field">
                    <span class="review-add__field-name"><?= Loc::getMessage('SM_REVIEW_ADD_COMMENT') ?></span>
                    <textarea class="review-add__field-textarea input-text"
                              name="COMMENT"
                              placeholder="<?= Loc::getMessage('SM_REVIEW_ADD_PLACEHOLDER') ?>"
                              required
                    ></textarea>
                </label>
                <div class="review-add__dropzone-wrapper custom-scrollbar">
                    <div class="review-add__dropzone dropzone" data-entity="review-add-dropzone"></div>
                </div>
            </form>
        </div>
        <div class="review-add__footer">
            <div class="review-add__author">
                <span class="review-add__author-text"><?= Loc::getMessage('SM_REVIEW_ADD_USER_NAME') ?></span>
                <span class="review-add__author-name"><?= $arResult['USER']['FORMAT_NAME'] ?></span>
            </div>
            <div class="review-add__checkbox-container">
                <div class="review-add__checkbox-wrapper">
                    <input id="privacy"
                           class="review-add__checkbox input-checkbox"
                           name="ANONYMOUS"
                           value="Y"
                           type="checkbox"
                           form="review-add-form"
                    >
                    <label class="review-add__checkbox-label" for="privacy"><?= Loc::getMessage(
                            'SM_REVIEW_ADD_ANONYMOUS'
                        ) ?></label>
                </div>
            </div>
            <?php
            if ($arResult['AGREEMENT']) { ?>
                <div class="review-add__privacy">
                    <?= Loc::getMessage('SM_REVIEW_AGREEMENT_1') ?>
                    <button class="text-primary" data-entity="review-add-show-agreement-button">
                        <?= Loc::getMessage('SM_REVIEW_AGREEMENT_2') ?>
                    </button>
                </div>
                <?php
            } ?>
        </div>
    </div>
    <div class="review-add__button-container">
        <button class="review-add__button btn"
                form="review-add-form"
                type="submit"
        >
            <?= Loc::getMessage('SM_REVIEW_ADD_BUTTON_TITLE') ?>
        </button>
    </div>
</div>

<script>
    BX.message({
        'dropzone_message': '<?= Loc::getMessage('SM_REVIEW_DROPZONE_MESSAGE') ?>',
        'dropzone_delete': '<?= Loc::getMessage('SM_REVIEW_DROPZONE_DEL') ?>',
        'dropzone_error_max_files': '<?= Loc::getMessage('SM_REVIEW_DROPZONE_MAX_FILES') ?>',
        'dropzone_cancel': '<?= Loc::getMessage('SM_REVIEW_DROPZONE_CANCEL') ?>',
        'dropzone_file_too_big': '<?= Loc::getMessage('SM_REVIEW_DROPZONE_FILE_TOO_BIG') ?>',
        'success_title': '<?= Loc::getMessage('SM_REVIEW_SUCCESS_TITLE') ?>',
        'review_add_rating_1': '<?= Loc::getMessage('SM_REVIEW_ADD_RATING_1') ?>',
        'review_add_rating_2': '<?= Loc::getMessage('SM_REVIEW_ADD_RATING_2') ?>',
        'review_add_rating_3': '<?= Loc::getMessage('SM_REVIEW_ADD_RATING_3') ?>',
        'review_add_rating_4': '<?= Loc::getMessage('SM_REVIEW_ADD_RATING_4') ?>',
        'review_add_rating_5': '<?= Loc::getMessage('SM_REVIEW_ADD_RATING_5') ?>',
    });
    document.addEventListener('DOMContentLoaded', () => {
        SM_ReviewsAdd.init({
            imagesFolder: '<?= $templateFolder . '/images/' ?>',
            fileUploadUrl: '<?= $templateFolder . '/result_modifier.php' ?>',
            maxFiles: '<?= $arParams['MAX_FILES'] ?>',
            maxFileSize: '<?= $arParams['MAX_FILE_SIZE'] ?>',
            defaultRating: <?= $arParams['DEFAULT_RATING'] ?>,
            useAgreement: Boolean(<?= !empty($arResult['AGREEMENT']) ?>),
            agreementTitle: '<?= $arResult['AGREEMENT']['NAME'] ?>',
            agreementText: `<?= $arResult['AGREEMENT']['TEXT'] ?>`,
        });
    });
</script>
