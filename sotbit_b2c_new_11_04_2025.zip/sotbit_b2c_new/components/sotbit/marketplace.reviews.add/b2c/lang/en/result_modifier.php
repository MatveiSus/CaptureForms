<?php

$MESS['SM_REVIEW_ADD_CONSENT_FIELDS'] = '- Cookie files;<br>- IP-address.';
