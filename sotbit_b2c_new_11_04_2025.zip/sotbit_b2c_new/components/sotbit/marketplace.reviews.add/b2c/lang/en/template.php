<?php

$MESS["SM_REVIEW_ADD_BUTTON_TITLE"] = "Leave feedback";
$MESS["SM_REVIEW_ADD_FORM_TITLE"] = "Product review";
$MESS["SM_REVIEW_ADD_RATING_1"] = "Terrible";
$MESS["SM_REVIEW_ADD_RATING_2"] = "Badly";
$MESS["SM_REVIEW_ADD_RATING_3"] = "Fine";
$MESS["SM_REVIEW_ADD_RATING_4"] = "Fine";
$MESS["SM_REVIEW_ADD_RATING_5"] = "Great";
$MESS["SM_REVIEW_ADD_DIGNITY"] = "Advantages";
$MESS["SM_REVIEW_ADD_FLAWS"] = "Flaws";
$MESS["SM_REVIEW_ADD_COMMENT"] = "Comment about the product";
$MESS["SM_REVIEW_ADD_PLACEHOLDER"] = "Enter text";
$MESS["SM_REVIEW_ADD_USER_NAME"] = "You leave a review as:";
$MESS["SM_REVIEW_ADD_ANONYMOUS"] = "Post anonymously";
$MESS["SM_REVIEW_AGREEMENT_1"] = "When submitting a review, please read ";
$MESS["SM_REVIEW_AGREEMENT_2"] = "publication rules";
$MESS["SM_REVIEW_DROPZONE_MESSAGE"] = "Drag files here or<br> <span class=\"review_add__link\">select on device</span>";
$MESS["SM_REVIEW_DROPZONE_DEL"] = "<svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1 1L8 8M15 15L8 8M8 8L15 1.00004M8 8L1 15\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>";
$MESS["SM_REVIEW_DROPZONE_MAX_FILES"] = "Maximum number of files exceeded";
$MESS["SM_REVIEW_DROPZONE_FILE_TOO_BIG"] = "The file is too large ({{filesize}}MB). Maximum size: {{maxFilesize}}MB.";
$MESS["SM_REVIEW_DROPZONE_CANCEL"] = "Canceled";
$MESS["SM_REVIEW_SUCCESS_TITLE"] = "Thanks for your feedback!";
$MESS["SM_REVIEW_ADD_BUTTON_TITLE_DISABLED"] = "Rate it from 1 to 5";
