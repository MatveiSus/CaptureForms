<?php

$MESS['DEFAULT_RATING'] = 'Default Rating';
$MESS['DEFAULT_RATING_1'] = 'Terrible';
$MESS['DEFAULT_RATING_2'] = 'Bad';
$MESS['DEFAULT_RATING_3'] = 'Okay';
$MESS['DEFAULT_RATING_4'] = 'Good';
$MESS['DEFAULT_RATING_5'] = 'Excellent';
