<?php

$MESS['SM_REVIEW_ADD_BUTTON_TITLE'] = 'Оставить отзыв';
$MESS['SM_REVIEW_ADD_FORM_TITLE'] = 'Отзыв о товаре';
$MESS['SM_REVIEW_ADD_RATING_1'] = 'Ужасно';
$MESS['SM_REVIEW_ADD_RATING_2'] = 'Плохо';
$MESS['SM_REVIEW_ADD_RATING_3'] = 'Нормально';
$MESS['SM_REVIEW_ADD_RATING_4'] = 'Хорошо';
$MESS['SM_REVIEW_ADD_RATING_5'] = 'Отлично';
$MESS['SM_REVIEW_ADD_DIGNITY'] = 'Достоинства';
$MESS['SM_REVIEW_ADD_FLAWS'] = 'Недостатки';
$MESS['SM_REVIEW_ADD_COMMENT'] = 'Комментарий о товаре';
$MESS['SM_REVIEW_ADD_PLACEHOLDER'] = 'Введите текст';
$MESS['SM_REVIEW_ADD_USER_NAME'] = 'Вы оставляете отзыв как:';
$MESS['SM_REVIEW_ADD_ANONYMOUS'] = 'Опубликовать анонимно';
$MESS['SM_REVIEW_AGREEMENT_1'] = 'Отправляя отзыв, пожалуйста, ознакомьтесь с ';
$MESS['SM_REVIEW_AGREEMENT_2'] = 'правилами публикации';
$MESS['SM_REVIEW_DROPZONE_MESSAGE'] = 'Перетащите сюда файлы или <br><span class="review-add__dropzone-link">выберите на устройстве</span>';
$MESS['SM_REVIEW_DROPZONE_DEL'] = '<svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1 1L8 8M15 15L8 8M8 8L15 1.00004M8 8L1 15\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>';
$MESS['SM_REVIEW_DROPZONE_MAX_FILES'] = 'Превышено максимальное количество файлов';
$MESS['SM_REVIEW_DROPZONE_FILE_TOO_BIG'] = 'Файл слишком большой ({{filesize}}MB). Максимальный размер: {{maxFilesize}}MB.';
$MESS['SM_REVIEW_DROPZONE_CANCEL'] = 'Отменено';
$MESS['SM_REVIEW_SUCCESS_TITLE'] = 'Спасибо за отзыв!';
$MESS['SM_REVIEW_ADD_BUTTON_TITLE_DISABLED'] = 'Поставьте оценку от 1 до 5';