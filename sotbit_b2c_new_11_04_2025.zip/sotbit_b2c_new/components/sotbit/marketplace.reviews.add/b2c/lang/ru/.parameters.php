<?php

$MESS['DEFAULT_RATING'] = 'Оценка по-умолчанию';
$MESS['DEFAULT_RATING_1'] = 'Ужасно';
$MESS['DEFAULT_RATING_2'] = 'Плохо';
$MESS['DEFAULT_RATING_3'] = 'Нормально';
$MESS['DEFAULT_RATING_4'] = 'Хорошо';
$MESS['DEFAULT_RATING_5'] = 'Отлично';