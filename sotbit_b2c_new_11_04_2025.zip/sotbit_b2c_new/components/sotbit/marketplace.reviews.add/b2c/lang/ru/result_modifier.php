<?php

$MESS['SM_REVIEW_ADD_CONSENT_FIELDS'] = '- Файлы cookie;<br>- IP-адрес.';
