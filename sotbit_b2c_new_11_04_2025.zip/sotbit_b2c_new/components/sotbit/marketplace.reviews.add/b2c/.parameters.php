<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

$arTemplateParameters = [
    "DEFAULT_RATING" => [
        "PARENT" => "BASE",
        "NAME" => Loc::getMessage("DEFAULT_RATING"),
        "TYPE" => "LIST",
        "VALUES" => [
            1 => Loc::getMessage("DEFAULT_RATING_1"),
            2 => Loc::getMessage("DEFAULT_RATING_2"),
            3 => Loc::getMessage("DEFAULT_RATING_3"),
            4 => Loc::getMessage("DEFAULT_RATING_4"),
            5 => Loc::getMessage("DEFAULT_RATING_5"),
        ],
        "DEFAULT" => 3,
    ]
];
