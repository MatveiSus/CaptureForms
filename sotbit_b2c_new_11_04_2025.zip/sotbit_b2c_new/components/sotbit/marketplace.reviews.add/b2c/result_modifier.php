<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php');
}

use Bitrix\Main\{Application, Localization\Loc, Web\Json};

$request = Application::getInstance()->getContext()->getRequest();

if ($request->isPost() && $request->get('action') === 'removedfile' && $request->get('fileId')) {
    return CFile::Delete($request->get('fileId'));
}

$arFiles = $request->getFileList()->getValues();

if ($arFiles && $request->isPost()) {
    $fieldCode = array_key_first($arFiles);
    $fileID = CFile::SaveFile(
        array_merge($arFiles[$fieldCode], ['MODULE_ID' => 'sotbit.marketplace']),
        "sotbit.marketplace"
    );

    echo Json::encode(['file' => ['id' => $fileID]]);
    die();
}

$arParams['DEFAULT_RATING'] ??= 3;

$arResult['AGREEMENT']['TEXT'] = str_replace(
    '%fields%',
    Loc::getMessage('SM_REVIEW_ADD_CONSENT_FIELDS'),
    $arResult['AGREEMENT']['TEXT']
);
