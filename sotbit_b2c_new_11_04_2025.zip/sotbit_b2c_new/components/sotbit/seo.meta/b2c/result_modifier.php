<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

global $sotbitSeoMetaDisplayDscrVariant;
global $sotbitSeoMetaDisplayDscr;

$sotbitSeoMetaDisplayDscrVariant = $arParams['DISPLAY_DESCRIPTION'] ?? 'REPLACE';
$sotbitSeoMetaDisplayDscr = function ($dscr, $seoDscr) use ($sotbitSeoMetaDisplayDscrVariant) {
    switch ($sotbitSeoMetaDisplayDscrVariant) {
        case 'REPLACE':
        {
            return $seoDscr;
        }
        case 'ADD':
        {
            return $dscr . '<br>' .$seoDscr;
        }
        case 'HIDE':
        {
            return '';
        }
    }
};