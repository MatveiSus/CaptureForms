<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;


$arTemplateParameters['DISPLAY_DESCRIPTION'] = array(
    'NAME' => Loc::getMessage('B2C_SEO_META_DESCRIPTION_VARIANT'),
    'TYPE' => 'LIST',
    'MULTIPLE' => 'N',
    'ADDITIONAL_VALUES' => 'N',
    'VALUES' => array(
        'REPLACE' => Loc::getMessage('B2C_SEO_META_DESCRIPTION_VARIANT_REPLACE'),
        'ADD' => Loc::getMessage('B2C_SEO_META_DESCRIPTION_VARIANT_ADD'),
        'HIDE' => Loc::getMessage('B2C_SEO_META_DESCRIPTION_VARIANT_HIDE')
    )
);