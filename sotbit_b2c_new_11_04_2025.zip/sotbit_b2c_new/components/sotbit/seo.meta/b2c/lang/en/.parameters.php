<?php
$MESS["B2C_SEO_META_DESCRIPTION_VARIANT"] = "Section description display option";
$MESS["B2C_SEO_META_DESCRIPTION_VARIANT_REPLACE"] = "Replace main description";
$MESS["B2C_SEO_META_DESCRIPTION_VARIANT_ADD"] = "Add to the main description";
$MESS["B2C_SEO_META_DESCRIPTION_VARIANT_HIDE"] = "Hide description";
