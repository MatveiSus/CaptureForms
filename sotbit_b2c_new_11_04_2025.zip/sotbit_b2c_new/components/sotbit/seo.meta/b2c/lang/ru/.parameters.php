<?php
$MESS['B2C_SEO_META_DESCRIPTION_VARIANT'] = 'Вариант отображения описания раздела';
$MESS['B2C_SEO_META_DESCRIPTION_VARIANT_REPLACE'] = 'Заменять основное описание';
$MESS['B2C_SEO_META_DESCRIPTION_VARIANT_ADD'] = 'Дополнять основное описание';
$MESS['B2C_SEO_META_DESCRIPTION_VARIANT_HIDE'] = 'Скрывать описание';