<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
?>
<div class="reviews" id="reviews">
    <div class="reviews__wrapper">
        <div class="reviews__control d-flex-reviews j-content-between-reviews r-p-4">
        <?php

       $res =  $APPLICATION->IncludeComponent(
            "sotbit:rvw.reviews.filter",
            "",
            array(
                'MAX_RATING' => $arParams['MAX_RATING'],
                'ID_ELEMENT' => $arParams['ID_ELEMENT'],
            ),
            $component
        );
        ?>
            <div class="control-add">
                <input type="button" data-action="show-modal" data-target="review_add__modal"
                       class="btn-reviews btn-reviews--main" value="<?= Loc::getMessage('SA_REVIEWS_BTN_ADD') ?>">
            </div>
        </div>
        <?php
        $APPLICATION->IncludeComponent(
            "sotbit:rvw.reviews.list",
            "",
            array(
                'MAX_RATING' => $arParams['MAX_RATING'],
                'COUNT_PAGE' => $arParams['COUNT_PAGE'],
                'ID_ELEMENT' => $arParams['ID_ELEMENT'],
                'DATE_FORMAT' => $arParams['DATE_FORMAT'],
            ),
            $component
        );
        ?>
    </div>
    <?php
    $APPLICATION->IncludeComponent(
        "sotbit:rvw.statistics",
        "",
        array(
            'MAX_RATING' => $arParams['MAX_RATING'],
            'ID_ELEMENT' => $arParams['ID_ELEMENT'],
        ),
        $component
    );
    ?>
</div>
<script>
    SA_Reviews.init({
        signedParameters: '<?= $this->getComponent()->getSignedParameters() ?>'
    });
</script>