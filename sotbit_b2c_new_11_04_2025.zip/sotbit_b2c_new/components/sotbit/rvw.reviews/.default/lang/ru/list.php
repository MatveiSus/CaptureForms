<?php
$MESS['SA_REVIEWS_BTN_ADD'] = 'Написать отзыв';