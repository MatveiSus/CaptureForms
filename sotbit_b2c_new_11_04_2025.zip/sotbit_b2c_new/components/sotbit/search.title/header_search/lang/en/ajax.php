<?php
$MESS["NOTHING_FOUND"] = "Nothing found";
$MESS["PRICE_FROM"] = "from";
$MESS["BTN_ADD_TO_BASKET_TITLE"] = "Add to Basket";
$MESS["BTN_IN_BASKET_TITLE"] = "item in cart";
$MESS["SUCCESS_ADD_TO_BASKET"] = "Product added <a class=\"text-primary\" href=\"#BASKET_LINK#\">to cart</a>";
