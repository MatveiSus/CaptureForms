<?php
$MESS["TP_BST_SHOW_INPUT"] = "Show search query entry form";
$MESS["TP_BST_INPUT_ID"] = "Search query input line ID";
$MESS["TP_BST_CONTAINER_ID"] = "ID of the container based on the width of which results will be displayed";
$MESS["TP_BST_PRICE_CODE"] = "Price type";
$MESS["TP_BST_SHOW_PREVIEW"] = "Show picture";
$MESS["TP_BST_PREVIEW_WIDTH"] = "Image width";
$MESS["TP_BST_PREVIEW_HEIGHT"] = "Picture height";
$MESS["TP_BST_PREVIEW_TRUNCATE_LEN"] = "Maximum length of announcement for output";
$MESS["TP_BST_CONVERT_CURRENCY"] = "Show prices in one currency";
$MESS["TP_BST_CURRENCY_ID"] = "Currency into which prices will be converted";
$MESS["TP_BST_PRICE_VAT_INCLUDE"] = "Include VAT in the price";
$MESS["TP_BST_PATH_TO_BASKET"] = "Path to basket";