<?php
$MESS['CT_BST_SEARCH_BUTTON'] = 'Search';
$MESS['SEARCH_PLACEHOLDER'] = 'Search for products';
$MESS["SBB_ADDED_TO_BASKET"] = "Product added <a href='#PATH#'>to cart</a>";
$MESS["CT_BST_DELETE_HISTORY_ITEM"] = "Delete";
$MESS["CT_BST_DELETE_HISTORY_TITLE"] = "You viewed";
$MESS["CT_BST_SEARCH_IMAGE_TITLE"] = "Search by images";
$MESS["CT_BST_SEARCH_IMAGE_LINK"] = "Insert image link";
$MESS["CT_BST_SEARCH_IMAGE_SUBMIT"] = "Find";