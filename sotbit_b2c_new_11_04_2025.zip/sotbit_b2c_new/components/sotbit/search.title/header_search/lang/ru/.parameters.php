<?php

$MESS["TP_BST_SHOW_INPUT"] = "Показывать форму ввода поискового запроса";
$MESS["TP_BST_INPUT_ID"] = "ID строки ввода поискового запроса";
$MESS["TP_BST_CONTAINER_ID"] = "ID контейнера, по ширине которого будут выводиться результаты";
$MESS["TP_BST_PRICE_CODE"] = "Тип цены";
$MESS["TP_BST_SHOW_PREVIEW"] = "Показать картинку";
$MESS["TP_BST_PREVIEW_WIDTH"] = "Ширина картинки";
$MESS["TP_BST_PREVIEW_HEIGHT"] = "Высота картинки";
$MESS["TP_BST_PREVIEW_TRUNCATE_LEN"] = "Максимальная длина анонса для вывода";
$MESS["TP_BST_CONVERT_CURRENCY"] = "Показывать цены в одной валюте";
$MESS["TP_BST_CURRENCY_ID"] = "Валюта, в которую будут сконвертированы цены";
$MESS["TP_BST_PRICE_VAT_INCLUDE"] = "Включать НДС в цену";
$MESS["TP_BST_PATH_TO_BASKET"] = "Ссылка на корзину";
