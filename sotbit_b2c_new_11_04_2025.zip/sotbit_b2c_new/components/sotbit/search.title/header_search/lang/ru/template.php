<?php
$MESS['CT_BST_SEARCH_BUTTON'] = 'Поиск';
$MESS['SEARCH_PLACEHOLDER'] = 'Поиск товаров';
$MESS["SBB_ADDED_TO_BASKET"] = "Товар добавлен <a href='#PATH#'>в корзину</a>";
$MESS["CT_BST_DELETE_HISTORY_ITEM"] = "Удалить";
$MESS["CT_BST_DELETE_HISTORY_TITLE"] = "Вы смотрели";
$MESS["CT_BST_SEARCH_IMAGE_TITLE"] = "Поиск по изображениям";
$MESS["CT_BST_SEARCH_IMAGE_LINK"] = "Вставьте ссылку на изображение";
$MESS["CT_BST_SEARCH_IMAGE_SUBMIT"] = "Найти";