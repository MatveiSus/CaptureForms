<?php
$MESS['NOTHING_FOUND'] = 'Ничего не найдено';
$MESS['PRICE_FROM'] = 'от';
$MESS['BTN_ADD_TO_BASKET_TITLE'] = 'добавить в корзину';
$MESS['BTN_IN_BASKET_TITLE'] = 'товар в корзине';
$MESS['SUCCESS_ADD_TO_BASKET'] = 'Товар добавлен <a class="text-primary" href="#BASKET_LINK#">в корзину</a>';
