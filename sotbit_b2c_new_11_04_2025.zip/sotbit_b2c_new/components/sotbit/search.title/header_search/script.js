class SearchTitle {
    constructor(params) {
        this.params = params;
        this.ajaxPage = params.AJAX_PAGE;
        this.container = document.getElementById(params.CONTAINER_ID);
        this.input = this.container.querySelector(`#${params.INPUT_ID}`);
        this.clearButton = this.container.querySelector('#header-search-clear');
        this.resultContainer = this.container.querySelector('#header-search-result');
        this.minQueryLength = parseInt(params.MIN_QUERY_LEN) || 1;
        this.isOpen = false;
        this.useSpeech = params.USE_SPEECH;

        this.addEventListeners();
        this.initSearchImg();
        this.initRequestHistory();
    }

    showDropdown() {
        if (this.isOpen) {
            return;
        }

        BX.Sotbit.B2C.showElement(this.resultContainer, {
            duration: 100,
            callback: () => {
                this.isOpen = true;

                document.addEventListener('click', (event) => {
                    if (!event.composedPath().includes(this.resultContainer)) {
                        this.hideDropdown();
                    }
                }, {once: true})
            }
        });
    }

    hideDropdown() {
        if (!this.isOpen) {
            return;
        }

        BX.Sotbit.B2C.hideElement(this.resultContainer, {
            duration: 100,
            callback: () => this.isOpen = false
        });
    }

    clearInput() {
        this.input.value = '';
        BX.Sotbit.B2C.hideElement(this.clearButton, {duration: 100});
        this.hideDropdown();
        this.setResult('');
    }

    setResult(html) {
        this.resultContainer.innerHTML = html;
    }

    sendRequest(query) {
        return BX.ajax.promise({
            url: this.ajaxPage,
            method: 'POST',
            data: {
                'ajax_call': 'y',
                'INPUT_ID': this.params.INPUT_ID,
                'q': query,
                'l': this.minQueryLength
            },
            dataType: 'html',
        });
    }

    handleInput() {
        const query = this.input.value;

        if (query) {
            BX.Sotbit.B2C.showElement(this.clearButton, {duration: 100});
        } else {
            BX.Sotbit.B2C.hideElement(this.clearButton, {duration: 100});
        }

        this.sendRequest(query)
            .then(response => {
                this.setResult(response);
                if (response) {
                    this.showDropdown();
                    this.showHint();
                } else {
                    this.hideDropdown();
                }
            });
    }

    handleInputDebounced = BX.debounce(this.handleInput, 300).bind(this);

    addEventListeners() {
        this.input.addEventListener('input', this.handleInputDebounced.bind(this));
        this.input.addEventListener('click', this.showDropdown.bind(this));
        this.clearButton.addEventListener('click', this.clearInput.bind(this));

        if (this.useSpeech) {
            this.speech = this.container.querySelector(`#header-search-speech`);

            if (!window.webkitSpeechRecognition && !window.SpeechRecognition) {
                console.warn("Your browser does not support the SpeechRecognition API");
                this.speech.remove();
                return;
            }

            this.transcriptionInProgress = null;
            this.speech.classList.remove('d-none');
            this.speech.addEventListener('click', this.speechEvent.bind(this));
        }
    }

    speechEvent() {
        if (this.transcriptionInProgress) {
            this.transcriptionInProgress.stop();
        } else {
            this.transcriptionInProgress = window.webkitSpeechRecognition ? new webkitSpeechRecognition() : new SpeechRecognition();
            this.transcriptionInProgress.lang = navigator.language || 'ru-RU';
            this.transcriptionInProgress.interimResults = true;
            this.transcriptionInProgress.addEventListener("result", (e) => {
                this.input.value = e.results[0][0].transcript;
                this.handleInput();
            });

            this.transcriptionInProgress.addEventListener("end", () => {
                this.transcriptionInProgress = null;
                this.speech.classList.toggle('speech');
            });

            this.transcriptionInProgress.addEventListener("start", () => {
                this.speech.classList.toggle('speech');
            });

            this.transcriptionInProgress.addEventListener("error", (e) => {
                console.warn('sotbit.smartsearch: ' + (e.error === 'not-allowed' ? 'no permission to use microphone' : e.error));
                this.speech.classList.toggle('speech');
            });

            this.transcriptionInProgress.start();
        }
    }

    showHint() {
        if (!this.params.USE_HINT) {
            return;
        }

        const currentText = this.input.value.split(/\s+/).pop();
        const firstItemText = this.resultContainer.querySelector(this.params.FIRST_ITEM_SELECTOR)?.innerText;
        if (currentText === '' || !firstItemText) {
            return;
        }

        const matchList = firstItemText.split(/\s+/).filter(word => word.toLowerCase().startsWith(currentText.toLowerCase()));
        if (matchList.length === 0) {
            return;
        }

        const match = matchList[0];
        const cursorPosition = this.input.selectionStart;
        this.input.value += match.substring(currentText.length, match.length);
        this.input.setSelectionRange(cursorPosition, this.input.value.length);
    }

    initRequestHistory() {
        if (!this.params.USE_REQUEST_HISTORY) {
            return;
        }

        this.isHistoryOpen = false;
        this.historyItemsCount = 0;
        this.historyWrap = document.querySelector(`#${this.params.HISTORY.WRAP_ID}`);
        this.historyWrap.querySelectorAll('.delete-item').forEach(element => {
            element.addEventListener('click', () => this.deleteRequestHistoryItem(element));
            this.historyItemsCount++;
        });

        this.input.addEventListener('click', () => this.input.value.length === 0 && this.showRequestHistory());
        this.input.addEventListener('input', () => this.input.value.length > 0 ? this.hideRequestHistory() : this.showRequestHistory());
    }

    deleteRequestHistoryItem(element) {
        const item = element.closest(this.params.HISTORY.ITEM_SELECTOR);
        BX.ajax.runComponentAction('sotbit:search.title', 'deleteRequestHistory', {
            mode: 'class',
            data: {
                id: item.dataset.id,
            }
        });

        item.remove();
        if ((--this.historyItemsCount) === 0) {
            this.historyWrap.remove();
        }
    }

    showRequestHistory(reinit = false) {
        if (this.isHistoryOpen && !reinit) {
            return;
        }

        !this.isHistoryOpen && BX.Sotbit.B2C.showElement(this.historyWrap, {duration: 100});
        this.isHistoryOpen = true;
        setTimeout(() => document.addEventListener('click', (event) => {
            if (!event.composedPath().includes(this.historyWrap)) {
                this.hideRequestHistory();
                return;
            }

            this.showRequestHistory(true);
        }, {once: true}), 0);
    }

    hideRequestHistory() {
        BX.Sotbit.B2C.hideElement(this.historyWrap, {duration: 100});
        this.isHistoryOpen = false;
    }

    initSearchImg() {
        if (!this.params.SEARCH_IMG) {
            return;
        }

        if (this.params.SEARCH_IMG.CURRENT_IMG_CONTAINER) {
            const currentWrap = document.getElementById(this.params.SEARCH_IMG.CURRENT_IMG_CONTAINER);
            currentWrap?.querySelector('[data-type="clear-img"]')?.addEventListener('click', () => currentWrap.classList.add('d-none'));
        }

        if (this.params.SEARCH_IMG.FORM_CONTAINER_ID) {
            this.searchImgForm = document.getElementById(this.params.SEARCH_IMG.FORM_CONTAINER_ID);
        }

        if (this.params.SEARCH_IMG.SHOW_FORM_BTN) {
            document.getElementById(this.params.SEARCH_IMG.SHOW_FORM_BTN)?.addEventListener('click', () => this.showSearchImg());
        }
    }

    showSearchImg() {
        this.searchImgForm.style.display = 'block';
        setTimeout(() => document.addEventListener('click', (event) => {
            if (!event.composedPath().includes(this.searchImgForm) || event.target.closest('[data-type="close-form"]')) {
                this.hideSearchImg();
                return;
            }

            this.showSearchImg();
        }, {once: true}), 0);
    }

    hideSearchImg() {
        this.searchImgForm.style.display = 'none';
    }
}


class SearchTitleResult {
    constructor(params = {}) {
        this.btnAddToBasket = document.querySelectorAll('[data-type="add_to_basket"]');
        this.classInCart = 'in-cart';

        if (this.btnAddToBasket.length > 0) {
            this.initAddToBasket();
        }
    }

    initAddToBasket() {
        for (let btn of this.btnAddToBasket) {
            btn.addEventListener('click',  (event) => {
                event.preventDefault();
                event.stopPropagation();

                const item = btn.closest('[data-product-id]');
                if (item.classList.contains(this.classInCart)) {
                    return;
                }

                BX.ajax.runAction('sotbit:b2c.basket.add', {
                    data: {
                        productData: {
                            'PRODUCT_ID': item.getAttribute('data-product-id'),
                        },
                        siteId: BX.message('SITE_ID')
                    },
                }).then(
                    response => {
                        item.classList.add(this.classInCart);
                        BX.onCustomEvent('OnBasketChange');
                        BX.Sotbit.B2C.showMessage(BX.message('SBB_ADDED_TO_BASKET'), {subMessage: response.data.subMessage});
                    },
                    reject => {
                        BX.Sotbit.B2C.showMessage(reject.errors.map(error => error.message).join('\n'), {icon: 'error'});
                    },
                )
            });
        }
    }
}