<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Public\Icon;

$this->setFrameMode(true);

$INPUT_ID = CUtil::JSEscape(trim($arParams["~INPUT_ID"])) ?: "title-search-input";
$CONTAINER_ID = CUtil::JSEscape(trim($arParams["~CONTAINER_ID"])) ?: "title-search";
/**
 * user request history
 */
$HISTORY_COUNT = 5;

if ($arParams["SHOW_INPUT"] !== "N") { ?>
    <div itemscope itemtype="https://schema.org/WebSite">
        <meta itemprop="url" content="/">
        <form id="<?= $CONTAINER_ID ?>" class="header__search search" itemprop="potentialAction" itemscope="" itemtype="https://schema.org/SearchAction" action="<?= $arResult["FORM_ACTION"] ?>">
            <meta itemprop="target" content="/catalog/search.php?q={q}">
            <button name="s" value="<?= Loc::getMessage("CT_BST_SEARCH_BUTTON"); ?>" class="search-btn" title="">
                <svg width="32" height="32">
                    <use xlink:href="<?= Icon::get('search') ?>"></use>
                </svg>
            </button>

            <label class="search-label">
                <input id="<?= $INPUT_ID ?>"
                    itemprop="query-input"
                    type="text"
                    name="q"
                    class="search-input"
                    placeholder="<?= Loc::getMessage('SEARCH_PLACEHOLDER'); ?>"
                    autocomplete="off"
                >
                <div class="header__search_icon_wrap">
                    <button id="header-search-clear"
                            class="header__search-icon text-secondary-500 d-none"
                            type="button"
                    >
                        <svg width="24" height="24">
                            <use xlink:href="<?= Icon::get('close') ?>"></use>
                        </svg>
                    </button>

                    <?php
                    if ($arParams['USE_SPEECH'] === 'Y'):?>
                        <button id="header-search-speech"
                                class="header__search-icon header__search-speech text-secondary-500 d-none"
                                type="button"
                        >
                            <svg width="24" height="24">
                                <use xlink:href="<?= Icon::get('microphone') ?>"></use>
                            </svg>
                        </button>
                    <?php
                    endif; ?>

                    <?php
                    if ($arParams['USE_SEARCH_IMAGE'] === 'Y'): ?>
                        <button id="smartsearch-title-search-img"
                                class="header__search-icon text-secondary-500"
                                type="button"
                        >
                            <svg width="24" height="24">
                                <use xlink:href="<?= Icon::get('camera_single') ?>"></use>
                            </svg>
                        </button>
                    <?php
                    endif; ?>
                </div>
            </label>

            <div id="header-search-result" class="search-dropdown d-none"></div>

            <?php
            if ($arParams['USE_REQUEST_HISTORY'] === 'Y' && !empty($arResult['REQUEST_HISTORY'])): ?>
                <div id="smartsearch-title__req_history" class="header__search__req_history search-dropdown d-none">
                    <div class="header__search__req_history_wrapper custom-scrollbar">
                        <div class="text-secondary-600 mb-3"><?= Loc::getMessage('CT_BST_DELETE_HISTORY_TITLE') ?></div>
                        <ul class="p-0">
                            <?php
                            foreach ($arResult['REQUEST_HISTORY'] as $history): ?>
                                <li class="item d-flex flex-column" data-id="<?= $history['ID'] ?>">
                                <span class="d-flex gap-3">
                                    <span class="icon icon-history text-secondary-500">
                                        <svg width="24" height="24">
                                            <use xlink:href="<?= Icon::get('history') ?>"></use>
                                        </svg>
                                    </span>
                                    <a href="<?= $history['HREF'] ?>" class="item-name"><?= $history['PHRASE'] ?></a>
                                    <button type="button" class=" icon delete-item"
                                            title="<?= Loc::getMessage('CT_BST_DELETE_HISTORY_ITEM') ?>">
                                        <svg width="24" height="24">
                                            <use xlink:href="<?= Icon::get('close') ?>"></use>
                                        </svg>
                                    </button>
                                </span>
                                </li>
                            <?php
                            endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php
            endif; ?>

            <?
            if ($arResult['SEARCH_IMG']): ?>
                <div id="current_search_img" class="smartsearch-title__current_searchimg_wrap d-block">
                    <div class="smartsearch-title__current_searchimg">
                        <img src="<?= $arResult['SEARCH_IMG']['SRC'] ?>" alt="" width="24" height="24">
                        <span class="filename"><?= $arResult['SEARCH_IMG']['ORIGINAL_NAME'] ?></span>
                        <button type="button" class="text-secondary-500 ms-auto" data-type="clear-img">
                            <svg width="24" height="24">
                                <use xlink:href="<?= Icon::get('close') ?>"></use>
                            </svg>
                        </button>
                    </div>
                </div>
            <?
            endif; ?>
        </form>
    </div>

    <?
    if ($arParams['USE_SEARCH_IMAGE'] === 'Y'): ?>
        <div id="search_img_form" class="smartsearch-title__searchimg_form_wrap">
            <form action="<?= $arResult['SEARCH_IMG_FORM_ACTION'] ?>" method="post" enctype="multipart/form-data">
                <div class="d-flex flex-column">
                    <div class="d-flex justify-content-between mb-4">
                        <span><?= Loc::getMessage('CT_BST_SEARCH_IMAGE_TITLE') ?></span>
                        <button type="button" class="text-secondary-500" data-type="close-form">
                            <svg width="24" height="24">
                                <use xlink:href="<?= Icon::get('close') ?>"></use>
                            </svg>
                        </button>
                    </div>
                    <div class="error"></div>
                    <?php
                    $APPLICATION->IncludeComponent(
                        'bitrix:main.file.input',
                        'drag_n_drop',
                        [
                            'MODULE_ID' => 'sotbit.smartsearch',
                            'MAX_FILE_SIZE' => '',
                            'MULTIPLE' => 'N',
                            'ALLOW_UPLOAD' => 'F',
                            'ALLOW_UPLOAD_EXT' => 'jpg, jpeg, png, gif, bmp, webp, ico',
                            'CONTROL_ID' => 'SEARCH_IMG_CONTROL',
                            'INPUT_NAME' => 'SEARCH_IMG',
                            'INPUT_NAME_UNSAVED' => 'SEARCH_IMG' . '_tmp',
                            'INPUT_VALUE' => 0,
                            'ACCEPT' => '.jpg, .jpeg, .png, .gif, .bmp, .webp, .ico'
                        ],
                        $component
                    );
                    ?>
                    <div class="d-flex gap-4 flex-sm-column">
                        <input class="input-text w-100" name="SEARCH_IMG_PATH" type="text"
                               placeholder="<?= Loc::getMessage('CT_BST_SEARCH_IMAGE_LINK') ?>">
                        <input type="submit" value="<?= Loc::getMessage('CT_BST_SEARCH_IMAGE_SUBMIT') ?>" class="btn">
                    </div>
                </div>
            </form>
        </div>

    <?
    endif; ?>
<?php
} ?>

<style>
    .smartsearch-title__req_history .item:nth-child(-n+<?=$HISTORY_COUNT?>) {
        display: list-item;
    }
</style>

<script>
    BX.message({
        'SBB_ADDED_TO_BASKET': '<?=GetMessageJS('SBB_ADDED_TO_BASKET', ['#PATH#' => $arParams['PATH_TO_BASKET']])?>'
    });
    BX.ready(function () {
        new SearchTitle({
            'AJAX_PAGE': '<?= CUtil::JSEscape(POST_FORM_ACTION_URI) ?>',
            'CONTAINER_ID': '<?= $CONTAINER_ID ?>',
            'INPUT_ID': '<?= $INPUT_ID ?>',
            'MIN_QUERY_LEN': 2,
            'USE_SPEECH': Boolean('<?=$arParams['USE_SPEECH'] === 'Y'?>'),
            'USE_HINT': Boolean(<?=$arParams['USE_HINT'] === 'Y'?>),
            'FIRST_ITEM_SELECTOR': '.search-dropdown-item .item-name',
            'USE_REQUEST_HISTORY': Boolean(<?=$arParams['USE_REQUEST_HISTORY'] === 'Y' && !empty($arResult['REQUEST_HISTORY'])?>),
            'HISTORY': {
                'WRAP_ID': 'smartsearch-title__req_history',
                'ITEM_SELECTOR': '.item',
                'DELETE_CLASS': 'delete-item',
            },
            'SEARCH_IMG': {
                'CURRENT_IMG_CONTAINER': 'current_search_img',
                'FORM_CONTAINER_ID': 'search_img_form',
                'SHOW_FORM_BTN': 'smartsearch-title-search-img'
            }
        });
    });
</script>
