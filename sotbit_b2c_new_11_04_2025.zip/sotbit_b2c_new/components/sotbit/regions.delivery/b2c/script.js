class SotbitRegionsDelivery {
    constructor(params = {}) {
        this.time = params.time;
        this.count = params.deliveryCount;
        this.component = params.component;
        this.regions = params.regions;

        document.addEventListener('click', (event) => {
            const showPopup = Array.prototype.slice.call(document.querySelectorAll('[data-entity="show-delivery-modal"]'));
            if (showPopup.some(i => event.composedPath().includes(i))) {
                this.renderDeliveryModal();
            }

            const favoriteRegions = Array.prototype.slice.call(document.querySelectorAll('[data-entity="change-region"]'));
            if (favoriteRegions.some(i => event.composedPath().includes(i))) {
                this.changeLocation(event.target.dataset.id);
            }
        });

        document.addEventListener('input', (event) => {
            const inputs = Array.prototype.slice.call(document.querySelectorAll('[data-entity="search-delivery"]'));
            if (inputs.some(user => event.composedPath().includes(user))) {
                this.searchEvent(event);
            }
        });
    }

    renderDeliveryModal() {
        BX.Sotbit.B2C.showPopup({
            title: BX.message('MODAL_TITLE'),
            html: document.getElementById('delivery-modal').innerHTML,
            width: (this.count > 2 || !this.count) ? 1040 : 704,
            showConfirmButton: false,
            customClass: {
                container: 'popup-form',
                htmlContainer: 'regions-delivery__popup_container'
            },
        }).then(result => {
            this.modal = result[1];
            this.modalContainer = result[1].getHtmlContainer();
            this.initEvents();
        });
    }

    initEvents() {
        this.isOpen = false;

        this.searchDelivery = this.modalContainer.querySelector('[data-entity="search-delivery"]');
        this.searchResult = this.modalContainer.querySelector('[data-entity="search-delivery-result"]');

        this.searchDelivery.addEventListener('input', this.searchEvent.bind(this))
    }


    searchEvent() {
        this.searchResult.innerHTML = '';
        const value = this.searchDelivery.value;

        if (value.trim() === '') {
            this.hideSearchResult();
        }

        let issetItems = false;

        const regionsListElementOptions = {
            props: {
                className: 'search-dropdown-list custom-scrollbar'
            },
            children: [],
        };

        this.regions
            .filter(i => new RegExp(value, 'i').test(i.NAME))
            .forEach(i => {
                regionsListElementOptions.children.push(BX.create('span', {
                    attrs: {'data-id': i.ID},
                    html: i.NAME.replace(new RegExp(value, 'i'), `<b>${value}</b>`),
                    events: {click: () => this.changeLocation(i.ID)}
                }));

                issetItems = true;
            });

        if (issetItems === false) {
            regionsListElementOptions.children.push(BX.create('span', {
                text: BX.message('SEARCH_EMPTY')
            }));
        }

        this.searchResult.appendChild(BX.create('div', regionsListElementOptions));

        !this.isOpen && this.showSearchResult();
    }

    showSearchResult() {
        BX.Sotbit.B2C.showElement(this.searchResult, {
            duration: 100,
            callback: () => {
                this.isOpen = true;

                document.addEventListener('click', (event) => {
                    if (!event.composedPath().includes(this.searchResult)) {
                        this.hideSearchResult();
                    }
                }, {once: true})
            }
        });
    }

    hideSearchResult() {
        if (!this.isOpen) {
            return;
        }

        BX.Sotbit.B2C.hideElement(this.searchResult, {
            duration: 100,
            callback: () => this.isOpen = false
        });
    }

    changeLocation(id) {
        BX.showWait();
        BX.ajax({
            url: this.component.path + '/ajax.php' + (document.location.href.indexOf('clear_cache=Y') !== -1 ? '?clear_cache=Y' : ''),
            method: 'POST',
            dataType: 'html',
            timeout: 60,
            data: {
                siteId: BX.message('SITE_ID'),
                template: this.component.template,
                parameters: this.component.params,
                Id: id,
            },
            onsuccess: BX.delegate(function (result) {
                const parser = new DOMParser();
                const node = parser.parseFromString(result, "text/html");
                this.modal.update(
                    {'html': node.getElementById('delivery-modal').innerHTML}
                );

                this.initEvents();
                BX.closeWait();
            }, this)
        });
    }
}
