<?php
$MESS['B2C_REGION_DELIVERY_EMPTY_TITLE'] = 'Нет доставок в выбранном регионе';
$MESS['B2C_REGION_DELIVERY_TITLE'] = 'Способы доставки';
$MESS['B2C_REGION_DELIVERY_CHANGE_REGION_TITLE'] = 'Сменить регион';
$MESS['B2C_REGION_DELIVERY_SEARCH_REGION'] = 'Введите Ваш город';
$MESS['B2C_REGION_DELIVERY_DELIVERY_TIME'] = 'Срок доставки:';
$MESS['MODAL_TITLE'] = 'Доставка';
$MESS['SEARCH_EMPTY'] = 'К сожалению ничего не найдено';