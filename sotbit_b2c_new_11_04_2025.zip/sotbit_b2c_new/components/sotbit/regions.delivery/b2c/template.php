<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Public\Icon;

$this->setFrameMode(true);
$signer = new \Bitrix\Main\Security\Sign\Signer;
$signedParams = $signer->sign(base64_encode(serialize($arParams)), 'regions.delivery');
$this->addExternalCss(SITE_TEMPLATE_PATH . '/assets/css/common/form-popup.min.css');
?>

<div class="regions_delivery d-flex flex-column gap-3" data-entity="current-delivery">
    <div class="d-flex justify-content-between align-items-baseline gap-5">
        <div>
            <? if ($arResult['CURRENT_DELIVERY']): ?>
                <span class="fs-1 text-secondary-700">
                 <?= $arResult['CURRENT_DELIVERY']['NAME'] ?>:
            </span>
                <? if ($arResult['CURRENT_DELIVERY']['TIME']): ?>
                    <span class="ml-3 fs-2">
                    <?= $arResult['CURRENT_DELIVERY']['TIME'] ?>
                </span>
                <? endif; ?>
            <? else: ?>
                <?= Loc::getMessage('B2C_REGION_DELIVERY_EMPTY_TITLE'); ?>
            <? endif; ?>
        </div>
        <span class="regions_delivery__current_price fs-1 fw-medium">
            <?= $arResult['CURRENT_DELIVERY']['PRINT_PRICE'] ?>
        </span>
    </div>
    <a href="javascript:void(0);" class="fs-2 fw-medium"
       data-entity="show-delivery-modal"><?= Loc::getMessage('B2C_REGION_DELIVERY_TITLE'); ?></a>
</div>

<template id="delivery-modal">
    <div class="regions_delivery__modal custom-scrollbar">
        <div class="mb-4">
            <input type="checkbox" class="d-none" id="choose-region">
            <label class="region-regions_delivery__modal_choose d-flex align-items-center gap-2" for="choose-region"
                   title="<?= Loc::getMessage('B2C_REGION_DELIVERY_CHANGE_REGION_TITLE'); ?>">
                <svg width="24" height="24">
                    <use xlink:href="<?= Icon::get('location') ?>"></use>
                </svg>
                <span data-entity="select-city__block__text-city"><?= $arResult['USER_REGION_NAME'] ?></span>
                <svg class="contacts-arrow" width="24" height="24">
                    <use xlink:href="<?= Icon::get('chevron') ?>"></use>
                </svg>
            </label>
            <div class="regions_delivery__modal_search">
                <? if ($arResult['FAVORITES']): ?>
                    <div class="d-flex flex-wrap gap-4">
                        <? foreach ($arResult['FAVORITES'] as $location): ?>
                            <span class="pill pill-small fs-1 fw-normal" data-entity="change-region"
                                  data-id="<?= $location['ID'] ?>" title="<?= $location['LOCATION_NAME'] ?>">
                            <?= $location['LOCATION_NAME'] ?>
                        </span>
                        <? endforeach; ?>
                    </div>
                <? endif; ?>
                <div class="search search mt-4">
                <span class="search-btn">
                    <svg width="32" height="32">
                        <use xlink:href="<?= Icon::get('search') ?>"></use>
                    </svg>
                </span>
                    <label class="search-label">
                        <input id="title-search-input" type="text" class="search-input"
                               placeholder="<?= Loc::getMessage('B2C_REGION_DELIVERY_SEARCH_REGION'); ?>"
                               autocomplete="off" data-entity="search-delivery">
                    </label>
                    <div class="search-dropdown d-none" data-entity="search-delivery-result"></div>
                </div>
            </div>
        </div>

        <? if (empty($arResult['DELIVERY'])): ?>
            <div class="regions_delivery__modal_empty d-flex flex-column align-items-center gap-4">
                <div class="regions_delivery__modal_empty_img">
                    <img src="<?= SITE_TEMPLATE_PATH . '/assets/image/empty.webp' ?>"
                         alt="<?= Loc::getMessage('B2C_REGION_DELIVERY_EMPTY_TITLE'); ?>">
                </div>
                <div class="regions_delivery__modal_empty_title fw-medium">
                    <?= Loc::getMessage('B2C_REGION_DELIVERY_EMPTY_TITLE'); ?>
                </div>
            </div>
        <? else: ?>
            <div class="regions_delivery__modal_wrap">
                <? foreach ($arResult['DELIVERY'] as $delivery): ?>
                    <div class="regions_delivery__modal_item d-flex flex-column gap-3 p-4">
                        <div>
                            <img src="<?= $delivery['LOGOTIP']['SRC'] ?>" alt="<?= $delivery['NAME'] ?>">
                        </div>
                        <span class="fs-2 fw-medium"><?= $delivery['NAME'] ?></span>
                        <div>
                            <span class="fs-2 fw-bold"><?= $delivery['PRINT_PRICE'] ?></span>
                            <? if ($delivery['DESCRIPTION']): ?>
                                <div>
                                    <?= $delivery['DESCRIPTION'] ?>
                                </div>
                            <? endif; ?>
                            <? if ($delivery['TIME']): ?>
                                <div>
                                    <span class="text-secondary-600">
                                        <?= Loc::getMessage('B2C_REGION_DELIVERY_DELIVERY_TIME'); ?>
                                    </span>
                                            <span class="ml-3 fs-2">
                                        <?= $delivery['TIME'] ?>
                                    </span>
                                </div>
                            <? endif; ?>
                        </div>
                    </div>
                <? endforeach; ?>
            </div>
        <? endif; ?>
    </div>
</template>

<script>
    if (!window.b2cRegionsDelivery) {
        BX.message(<?= CUtil::PhpToJSObject(Loc::loadLanguageFile(__FILE__)) ?>);

        window.b2cRegionsDelivery = new SotbitRegionsDelivery({
            deliveryCount: <?=count($arResult['DELIVERY'])?>,
            regions: <?=CUtil::PhpToJSObject($arResult['REGIONS'])?>,
            component: {
                path: '<?=CUtil::JSEscape($componentPath)?>',
                params: '<?=CUtil::JSEscape($signedParams)?>',
                template: '<?=$this->__name?>',
            }
        });
    } else {
        window.b2cRegionsDelivery.deliveryCount = <?=count($arResult['DELIVERY'])?>;
    }
</script>
