<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
    die();
}

if (!\Bitrix\Main\Loader::includeModule('sotbit.regions')) {
    return;
}

if ($userId = \Bitrix\Main\Engine\CurrentUser::get()->getId()) {
    $lastOrder = \Bitrix\Sale\OrderTable::query()
        ->addSelect('DELIVERY_ID')
        ->where('USER_ID', $userId)
        ->setOrder(['ID' => 'desc'])
        ->setLimit(1)
        ->fetch();

    $currentDeliveryId = $lastOrder ? (int)$lastOrder['DELIVERY_ID'] : null;
}

$arResult['REGIONS'] = \Sotbit\Regions\System\Location::getAllLocations();
$arResult['FAVORITES'] = \Bitrix\Sale\Location\LocationTable::query()
    ->setSelect([
        'ID',
        'CODE',
        'LOCATION_NAME' => 'NAME.NAME',
    ])
    ->setOrder(
        [
            'SORT' => 'asc',
            'TYPE_ID' => 'asc',
            'NAME.NAME' => 'asc'
        ]
    )
    ->whereIn('CODE', \Sotbit\Regions\System\Location::getFavorites())
    ->where('NAME.LANGUAGE_ID', LANGUAGE_ID)
    ->setCacheTtl(36000000)
    ->fetchAll();

if ($arResult['DELIVERY']) {
    foreach ($arResult['DELIVERY'] as &$delivery) {
        if ($delivery['LOGOTIP']) {
            $delivery['LOGOTIP'] = CFile::ResizeImageGet(
                $delivery['LOGOTIP'],
                [
                    'width' => 120,
                    'height' => 58
                ],
                BX_RESIZE_IMAGE_PROPORTIONAL
            );
            $delivery['LOGOTIP']['SRC'] = $delivery['LOGOTIP']['src'];
        } else {
            $delivery['LOGOTIP']['SRC'] = SITE_TEMPLATE_PATH . '/assets/image/no_image/delivery.png';
        }

        if ($currentDeliveryId && $currentDeliveryId === (int)$delivery['ID']) {
            $arResult['CURRENT_DELIVERY'] = $delivery;
        }
    }
}

$arResult['CURRENT_DELIVERY'] = $arResult['CURRENT_DELIVERY'] ?? current($arResult['DELIVERY']);