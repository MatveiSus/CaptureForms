<?php
$MESS['BONUSES_ACCOUNT_AVAILABLE_TITLE'] = 'Доступно бонусных баллов';
$MESS['BONUSES_ACCOUNT_AVAILABLE_VALUE'] = 'Активные бонусы:';
$MESS['BONUSES_ACCOUNT_RATE'] = '(1 бонус = #RATE#)';
$MESS['BONUSES_ACCOUNT_TEMPORARY_TITLE'] = 'Ближайшее сгорание бонусов';
$MESS['BONUSES_ACCOUNT_TEMPORARY_DATE'] = 'Дата сгорания:';
$MESS['BONUSES_ACCOUNT_TEMPORARY_VALUE'] = 'Сумма сгорания:';
$MESS['BONUSES_ACCOUNT_TRANSACTIONS_LIST'] = 'История транзакций';
$MESS['BONUSES_ACCOUNT_TRANSACTIONS_NAV'] = 'Транзакции';
$MESS['BONUSES_ACCOUNT_TRANSACTIONS_EMPTY'] = 'К сожалению, на данный момент нет доступных транзакций';
