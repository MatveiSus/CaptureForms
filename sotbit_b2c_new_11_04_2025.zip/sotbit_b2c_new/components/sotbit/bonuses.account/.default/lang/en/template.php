<?php
$MESS['BONUSES_ACCOUNT_AVAILABLE_TITLE'] = 'Available bonus points';
$MESS['BONUSES_ACCOUNT_AVAILABLE_VALUE'] = 'Active bonuses:';
$MESS['BONUSES_ACCOUNT_RATE'] = '(1 bonus = #RATE#)';
$MESS['BONUSES_ACCOUNT_TEMPORARY_TITLE'] = 'Next bonus expiration';
$MESS['BONUSES_ACCOUNT_TEMPORARY_DATE'] = 'Expiration date:';
$MESS['BONUSES_ACCOUNT_TEMPORARY_VALUE'] = 'Expiration amount:';
$MESS['BONUSES_ACCOUNT_TRANSACTIONS_LIST'] = 'Transaction History';
$MESS['BONUSES_ACCOUNT_TRANSACTIONS_NAV'] = 'Transactions';
$MESS['BONUSES_ACCOUNT_TRANSACTIONS_EMPTY'] = 'Sorry, there are no transactions available at the moment';