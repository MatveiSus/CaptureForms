<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;

if (isset($arResult['ERROR_MESSAGE']) && !empty($arResult['ERROR_MESSAGE'])) {
    ShowError($arResult['ERROR_MESSAGE']);
    return;
}

$spriteImgPath = $this->__folder . '/img/sprite.svg';
?>

<div id="bonuses_account" class="bonuses_account__wrap">
    <div class="bonuses_account__topbar gap-4 gap-md-3">
        <div class="bonuses_account__budget bonuses_account__topbar_item bg-primary-100">
            <svg width="62" height="62" viewBox="0 0 62 62" fill="none" xmlns="http://www.w3.org/2000/svg"
                 class="flex-shrink-0">
                <use href="<?= "{$spriteImgPath}#current-bonuses" ?>"></use>
            </svg>
            <div class="right_section">
                <span class="fw-medium fs-1">
                    <?= Loc::getMessage('BONUSES_ACCOUNT_AVAILABLE_TITLE'); ?>
                </span>
                <span class="field-row flex-wrap">
                    <label><?= Loc::getMessage('BONUSES_ACCOUNT_AVAILABLE_VALUE'); ?></label>
                    <i class="value fs-2"><?= $arResult['ACCOUNT']['BALANCE_FORMATED'] ?></i>
                    <span class="text-secondary-500 fs-2"><?= Loc::getMessage('BONUSES_ACCOUNT_RATE', ['#RATE#' => $arResult['BONUSES']['RATE_FORMATTED']]); ?></span>
                </span>
            </div>
        </div>
        <?php
        if (isset($arResult['BONUSES']['TEMPORARY']) && is_array($arResult['BONUSES']['TEMPORARY']['CURRENT'])):
            $currentTemporary = $arResult['BONUSES']['TEMPORARY']['CURRENT'];
            ?>
            <div class="bonuses_account__temporary bonuses_account__topbar_item bg-primary-100">
                <svg width="62" height="62" viewBox="0 0 62 62" fill="none" xmlns="http://www.w3.org/2000/svg"
                     class="flex-shrink-0">
                    <use href="<?= "{$spriteImgPath}#temporary-bonuses" ?>"></use>
                </svg>
                <div class="right_section">
                    <span class="fw-medium fs-1">
                        <?= Loc::getMessage('BONUSES_ACCOUNT_TEMPORARY_TITLE'); ?>
                    </span>
                    <span class="field-row">
                        <label><?= Loc::getMessage('BONUSES_ACCOUNT_TEMPORARY_DATE'); ?></label>
                        <span class="fs-2"><?= $currentTemporary['WRITE_OF_DATE']->toString() ?></span>
                    </span>
                    <span class="field-row">
                         <label><?= Loc::getMessage('BONUSES_ACCOUNT_TEMPORARY_VALUE'); ?></label>
                         <i class="value fs-2"><?= $currentTemporary['QUANTITY'] ?></i>
                    </span>
                </div>
            </div>
        <?php
        endif; ?>
    </div>

    <?php
    if (!empty($arResult['TRANSACTIONS'])) {
        ?>
        <div class="bonuses_account__transactions">
            <h1><?= Loc::getMessage('BONUSES_ACCOUNT_TRANSACTIONS_LIST'); ?></h1>

            <div class="bonuses_account__transactions_wrap mt-4">
                <?php
                if (empty($arResult['TRANSACTIONS']['ITEMS'])) {
                    ?>
                    <div class="fs-4 fw-medium text-secondary-700"><?= Loc::getMessage('BONUSES_ACCOUNT_TRANSACTIONS_EMPTY'); ?></div>
                    <?
                } else { ?>
                    <table class="bonuses_account__transactions_table d-sm-none">
                        <thead>
                        <?php
                        foreach ($arParams['TRANSACTIONS_HEADER'] as $code => $name): ?>
                            <th class="fs-2 text-secondary-600"><?= $name ?></th>
                        <?php
                        endforeach; ?>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($arResult['TRANSACTIONS']['ITEMS'] as $arTransaction):
                            $transactionEventType = 'type-' . mb_strtolower($arTransaction['EVENT']);
                            ?>
                            <tr>
                                <?php
                                foreach ($arParams['TRANSACTIONS_HEADER'] as $code => $name): ?>
                                    <?php
                                    switch ($code) {
                                        case 'BALANCE':
                                            $value = number_format($arTransaction[$code], 0, '.', ' ');
                                            break;
                                        case 'QUANTITY':
                                            $value = number_format($arTransaction[$code], 0, '.', ' ');
                                            $value = "<span class=\"{$transactionEventType} {$transactionEventType}-value\">{$value}<span>";
                                            break;
                                        case 'EVENT':
                                            $value = $arResult['TRANSACTIONS']['EVENT_LANG'][$arTransaction['EVENT']];
                                            $value = "<span class=\"{$transactionEventType}\">{$value}<span>";
                                            break;
                                        case 'DATE':
                                            $value = $arTransaction['DATE'] ? $arTransaction['DATE']->toString() : '-';
                                            break;
                                        default:
                                            $value = $arTransaction[$code];
                                    }
                                    ?>
                                    <td><?= $value ?></td>
                                <?php
                                endforeach; ?>
                            </tr>
                        <?php
                        endforeach; ?>
                        </tbody>
                    </table>

                    <div class="bonuses_account__transactions_table mobile d-none d-sm-block">
                        <?php
                        foreach ($arResult['TRANSACTIONS']['ITEMS'] as $arTransaction):
                            $transactionEventType = 'type-' . mb_strtolower($arTransaction['EVENT']);
                            ?>
                        <div class="bonuses_account__transactions_row">
                            <?php
                            foreach ($arParams['TRANSACTIONS_HEADER'] as $code => $name): ?>
                                <?php
                                switch ($code) {
                                    case 'BALANCE':
                                        $value = number_format($arTransaction[$code], 0, '.', ' ');
                                        break;
                                    case 'QUANTITY':
                                        $value = number_format($arTransaction[$code], 0, '.', ' ');
                                        $value = "<span class=\"{$transactionEventType} {$transactionEventType}-value\">{$value}<span>";
                                        break;
                                    case 'EVENT':
                                        $value = $arResult['TRANSACTIONS']['EVENT_LANG'][$arTransaction['EVENT']];
                                        $value = "<span class=\"{$transactionEventType}\">{$value}<span>";
                                        break;
                                    case 'DATE':
                                        $value = $arTransaction['DATE'] ? $arTransaction['DATE']->toString() : '-';
                                        break;
                                    default:
                                        $value = $arTransaction[$code];
                                }
                                ?>
                                <div class="d-flex gap-4 justify-content-between">
                                    <span class="fs-2 text-secondary-600"><?= $name ?></span>
                                    <span><?= $value ?></span>
                                </div>
                            <?php
                            endforeach; ?>
                        </div>
                        <?php
                        endforeach; ?>
                    </div>
                <?php
                } ?>
            </div>

            <div class="mt-5">
                <?php
                $GLOBALS['APPLICATION']->IncludeComponent(
                    "bitrix:main.pagenavigation",
                    $arParams['TRANSACTIONS_PAGER_TEMPLATE'] ?? '',
                    array(
                        "NAV_OBJECT" => $arResult['TRANSACTIONS']['NAV'],
                        "NAV_ELEMENTS_TITLE" => Loc::getMessage('BONUSES_ACCOUNT_TRANSACTIONS_NAV')
                    ),
                    false
                );
                ?>
            </div>
        </div>
        <?php
    } ?>
</div>
