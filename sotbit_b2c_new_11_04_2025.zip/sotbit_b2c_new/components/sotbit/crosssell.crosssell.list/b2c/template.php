<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{
    Localization\Loc,
    UI\Extension,
};

$this->setFrameMode(true);
global ${$arParams["FILTER_NAME"]};

Extension::load(['sotbit.b2c.tabsy', 'sotbit.b2c.keenslider']);
Loc::loadMessages(__FILE__);

$generalParams = array(
    "ADD_PICT_PROP" => $arParams['ADD_PICT_PROP'],
    "ADD_PROPERTIES_TO_BASKET" => $arParams['ADD_PROPERTIES_TO_BASKET'],
    "ADD_SECTIONS_CHAIN" => $arParams['ADD_SECTIONS_CHAIN'],
    "ADD_TO_BASKET_ACTION" => $arParams['ADD_TO_BASKET_ACTION'],
    "AJAX_MODE" => $arParams['AJAX_MODE'],
    "AJAX_OPTION_ADDITIONAL" => $arParams['AJAX_OPTION_ADDITIONAL'],
    "AJAX_OPTION_HISTORY" => $arParams['AJAX_OPTION_HISTORY'],
    "AJAX_OPTION_JUMP" => $arParams['AJAX_OPTION_JUMP'],
    "AJAX_OPTION_STYLE" => $arParams['AJAX_OPTION_STYLE'],
    "BACKGROUND_IMAGE" => $arParams['BACKGROUND_IMAGE'],
    "BASKET_URL" => $arParams['BASKET_URL'],
    "BROWSER_TITLE" => $arParams['BROWSER_TITLE'],
    "CACHE_FILTER" => $arParams['CACHE_FILTER'],
    "CACHE_GROUPS" => $arParams['CACHE_GROUPS'],
    "CACHE_TIME" => $arParams['CACHE_TIME'],
    "CACHE_TYPE" => $arParams['CACHE_TYPE'],
    "COMPARE_PATH" => $arParams['COMPARE_PATH'],
    "COMPARE_NAME" => $arParams['COMPARE_PATH'],
    "COMPATIBLE_MODE" => $arParams['COMPATIBLE_MODE'],
    "CONVERT_CURRENCY" => $arParams['CONVERT_CURRENCY'],
    "CURRENCY_ID" => $arParams['CURRENCY_ID'],
    "DETAIL_URL" => $arParams['DETAIL_URL'],
    "DISABLE_INIT_JS_IN_COMPONENT" => $arParams['DISABLE_INIT_JS_IN_COMPONENTSHOW_QUANTITY'],
    "DISPLAY_COMPARE" => $arParams['DISPLAY_COMPARE'],
    "DISPLAY_TOP_PAGER" => $arParams['DISPLAY_TOP_PAGER'],
    "DISPLAY_BOTTOM_PAGER" => $arParams['DISPLAY_BOTTOM_PAGER'],
    "ENLARGE_PRODUCT" => $arParams['ENLARGE_PRODUCT'],
    "ELEMENT_SORT_FIELD2" => $arParams["ELEMENT_SORT_FIELD2"],
    "ELEMENT_SORT_ORDER2" => $arParams["ELEMENT_SORT_ORDER2"],
    "HIDE_NOT_AVAILABLE" => $arParams['HIDE_NOT_AVAILABLE'],
    "HIDE_NOT_AVAILABLE_OFFERS" => $arParams['HIDE_NOT_AVAILABLE_OFFERS'],
    "IBLOCK_ID" => $arParams['IBLOCK_ID'],
    "IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
    "INCLUDE_SUBSECTIONS" => "Y",
    "LAZY_LOAD" => $arParams['LAZY_LOAD'],
    "LABEL_PROP" => $arParams["LABEL_PROP"],
    "LINE_ELEMENT_COUNT" => $arParams['LINE_ELEMENT_COUNT'],
    "LOAD_ON_SCROLL" => $arParams['LOAD_ON_SCROLL'],
    "MESSAGE_404" => $arParams['MESSAGE_404'],
    "MESS_BTN_ADD_TO_BASKET" => $arParams['MESS_BTN_ADD_TO_BASKET'],
    "MESS_BTN_BUY" => $arParams['MESS_BTN_BUY'],
    "MESS_BTN_DETAIL" => $arParams['MESS_BTN_DETAIL'],
    "MESS_BTN_SUBSCRIBE" => $arParams['MESS_BTN_SUBSCRIBE'],
    "MESS_NOT_AVAILABLE" => $arParams['MESS_NOT_AVAILABLE'],
    "META_DESCRIPTION" => $arParams['META_DESCRIPTION'],
    "META_KEYWORDS" => $arParams['META_KEYWORDS'],
    "OFFERS_PROPERTY_CODE" => $arParams['OFFERS_PROPERTY_CODE'],
    "OFFERS_LIMIT" => $arParams['OFFERS_LIMIT'],
    "OFFER_ADD_PICT_PROP" => $arParams['OFFER_ADD_PICT_PROP'],
    "OFFERS_FIELD_CODE" => $arParams['OFFERS_FIELD_CODE'],
    "OFFER_TREE_PROPS" => $arParams['OFFER_TREE_PROPS'],
    "PAGER_BASE_LINK_ENABLE" => $arParams['PAGER_BASE_LINK_ENABLE'],
    "PAGER_DESC_NUMBERING" => $arParams['PAGER_DESC_NUMBERING'],
    "PAGER_DESC_NUMBERING_CACHE_TIME" => $arParams['PAGER_DESC_NUMBERING_CACHE_TIME'],
    "PAGER_SHOW_ALL" => $arParams['PAGER_SHOW_ALL'],
    "PAGER_SHOW_ALWAYS" => $arParams['PAGER_SHOW_ALWAYS'],
    "PAGER_TEMPLATE" => $arParams['PAGER_TEMPLATE'],
    "PAGER_TITLE" => $arParams['PAGER_TITLE'],
    "PARTIAL_PRODUCT_PROPERTIES" => $arParams['PARTIAL_PRODUCT_PROPERTIES'],
    "PRICE_CODE" => $arParams['PRICE_CODE'],
    "PRICE_VAT_INCLUDE" => $arParams['PRICE_VAT_INCLUDE'],
    "PRODUCT_BLOCKS_ORDER" => $arParams['PRODUCT_BLOCKS_ORDER'],
    "PRODUCT_DISPLAY_MODE" => $arParams['PRODUCT_DISPLAY_MODE'],
    "PRODUCT_ID_VARIABLE" => $arParams['PRODUCT_ID_VARIABLE'],
    "PRODUCT_PROPERTIES" => $arParams['PRODUCT_PROPERTIES'],
    "PRODUCT_PROPS_VARIABLE" => $arParams['PRODUCT_PROPS_VARIABLE'],
    "PRODUCT_QUANTITY_VARIABLE" => $arParams['PRODUCT_QUANTITY_VARIABLE'],
    "PRODUCT_ROW_VARIANTS" => $arParams['PRODUCT_ROW_VARIANTS'],
    "PRODUCT_SUBSCRIPTION" => $arParams['PRODUCT_SUBSCRIPTION'],
    "PROPERTY_CODE" => $arParams['PROPERTY_CODE'],
    "RCM_PROD_ID" => $arParams['RCM_PROD_ID'],
    "RCM_TYPE" => $arParams['RCM_TYPE'],
    "SECTION_NAME" => $arParams['SECTION_NAME'],
    "SEF_MODE" => $arParams['SEF_MODE'],
    "SET_BROWSER_TITLE" => $arParams['SET_BROWSER_TITLE'],
    "SET_LAST_MODIFIED" => $arParams['PRODUCT_PROPS_VARIABLE'],
    "SET_META_DESCRIPTION" => $arParams['SET_META_DESCRIPTION'],
    "SET_META_KEYWORDS" => $arParams['SET_META_KEYWORDS'],
    "SET_STATUS_404" => $arParams['SET_STATUS_404'],
    "SET_TITLE" => $arParams['SET_TITLE'],
    "SHOW_404" => $arParams['SHOW_404'],
    "SHOW_CLOSE_POPUP" => $arParams['SHOW_CLOSE_POPUP'],
    "SHOW_DISCOUNT_PERCENT" => $arParams['SHOW_DISCOUNT_PERCENT'],
    "SHOW_FROM_SECTION" => $arParams['SHOW_FROM_SECTION'],
    "SHOW_MAX_QUANTITY" => $arParams['SHOW_MAX_QUANTITY'],
    "SHOW_OLD_PRICE" => $arParams['SHOW_OLD_PRICE'],
    "SHOW_PRICE_COUNT" => $arParams['SHOW_PRICE_COUNT'],
    "SHOW_SLIDER" => $arParams['SHOW_SLIDER'],
    "SHOW_ALL_WO_SECTION" => "Y",
    "TEMPLATE_THEME" => $arParams['TEMPLATE_THEME'],
    "VARIANT_LIST_VIEW" => $arParams['VARIANT_LIST_VIEW'],
    "USE_ENHANCED_ECOMMERCE" => $arParams['USE_ENHANCED_ECOMMERCE'],
    "USE_MAIN_ELEMENT_SECTION" => $arParams['USE_MAIN_ELEMENT_SECTION'],
    "USE_PRICE_COUNT" => $arParams['USE_PRICE_COUNT'],
    "USE_PRODUCT_QUANTITY" => $arParams['USE_PRODUCT_QUANTITY'],
    "USE_FILTER" => 'Y',
    "USE_COMPARE_LIST" => $arParams['USE_COMPARE_LIST'],
    "OBJECT_PARENT_COMPONENT" => $component,
    "LIST_PROPERTY_CODE" => $arParams["LIST_PROPERTY_CODE"],
    "SKU_VISUAL_VARIANT" => $arParams["SKU_VISUAL_VARIANT"],
    "ITEM_HOVER_ANIMATION" => $arParams["ITEM_HOVER_ANIMATION"],
    "ITEM_SCROLL_ON_HOVER" => $arParams["ITEM_SCROLL_ON_HOVER"],
    "ARTICLE_PROPERTY" => $arParams["ARTICLE_PROPERTY"],
    "OFFER_ARTICLE_PROPERTY" => $arParams["OFFER_ARTICLE_PROPERTY"],
    "USE_SKU_DISTINCT_URL" => $arParams["USE_SKU_DISTINCT_URL"],
    'FAVORITE_URL' => $arParams['FAVORITE_URL'],
    'COMPARE_URL' => $arParams['COMPARE_URL'],
);

//if works in section mode (from complex component)
if (is_array($arResult['CROSSSELL_ARRAY'])) {
    if ($arParams['SHOW_TABS'] == 'Y') {
        $crosssells = $arResult['CROSSSELL_ARRAY'];
        $container = "crosssells_" . $this->randString();
        ?>
    <div id="<?= $container ?>" class="crosssel-container tabsy mt-6 mt-sm-5">
        <div class="keen-slider d-flex flex-row flex-no-wrap tabsy__label_wrap">
            <?
            foreach ($crosssells as $tabId => $crosssell): ?>
                <label class="tabsy__label keen-slider__slide <?= !$active ? ' active' : '' ?>"
                       for="<?= $tabId ?>"><?= $crosssell['NAME'] ?></label>
                <?
                $active = true; ?>
            <?
            endforeach; ?>
        </div>
        <?
        $i = 0;
        $collectionParameters = array();
        foreach ($crosssells as $tabId => $crosssell) {
            $collectionParameters[$tabId]['IBLOCK_ID'] = $arParams['IBLOCK_ID'];
            $collectionParameters[$tabId]['FROM_COMPLEX'] = $arParams['FROM_COMPLEX'];
            ${$arParams["FILTER_NAME"]} = $crosssell['FILTER'];

            if ($arParams['AJAX_MODE'] === 'Y'): ?>
                <input type="radio" id="<?= $tabId ?>" name="crosssel-collection"
                       class="<?= ($i === 0) ? "collection-loaded" : '' ?>" <?= ($i === 0) ? "checked" : '' ?>>
            <?
            else: ?>
                <input type="radio" id="<?= $tabId ?>" name="crosssel-collection"
                       class="collection-loaded" <?= ($i === 0) ? "checked" : '' ?>>
            <?
            endif; ?>
            <div class="tabsy__tab" data-collection-id="<?= $tabId ?>">
                <div class="content">
                    <?
                    if (($i === 0) || ($arParams['AJAX_MODE'] !== 'Y')) {
                        $APPLICATION->IncludeComponent(
                            "bitrix:catalog.section",
                            $arParams['SECTION_TEMPLATE'],
                            array(
                                "ELEMENT_SORT_FIELD" => $crosssell["SORT_BY"],
                                "ELEMENT_SORT_ORDER" => $crosssell["SORT_ORDER"],
                                "FILTER_NAME" => $arParams["FILTER_NAME"],
                                "ITEM_TEMPLATE" => $crosssell['ITEM_TEMPLATE'],
                                "PAGE_ELEMENT_COUNT" => $crosssell['PRODUCT_NUMBER'],
                            ) + $generalParams,
                            $component
                        );
                    }
                    ?>
                </div>
            </div>
            <?
            $i++;
        }

        $componentPath = $arResult['COMPONENT_PATH'];
        ?>
        <script>
            BX.ready(() => {
                new B2CCrosssellList({
                    container: '<?= $container ?>',
                    inputName: 'crosssel-collection',
                    arParams: <?= CUtil::PhpToJSObject($arParams, false, true) ?>,
                    componentPath: '<?= $componentPath ?>',
                    crosssellArray: <?= CUtil::PhpToJSObject($arResult['CROSSSELL_ARRAY']) ?>
                })
            });
        </script>

        <?
    } else {
        foreach ($arResult['CROSSSELL_ARRAY'] as $crosssell) {
            ${$arParams["FILTER_NAME"]} = $crosssell['FILTER'];

            if ($arResult['SAFE'] && $crosssell['FILTER']) {
                $APPLICATION->IncludeComponent(
                    "bitrix:catalog.section",
                    $arParams['SECTION_TEMPLATE'],
                    array(
                        "ELEMENT_SORT_FIELD" => $crosssell["SORT_BY"],
                        "ELEMENT_SORT_ORDER" => $crosssell["SORT_ORDER"],
                        "FILTER_NAME" => $arParams["FILTER_NAME"],
                        "PAGE_ELEMENT_COUNT" => $crosssell['PRODUCT_NUMBER'],
                        "SECTION_NAME" => $crosssell['NAME'] ?: $generalParams['SECTION_NAME'],
                    ) + $generalParams,
                    $component
                );
            }
        }
    }
} else {
    //standard behavior (if called not section mode)
    if ($arResult['SAFE'] && $arResult['IBLOCK_ID']) {
        ${$arParams["FILTER_NAME"]} = $arResult['FILTER'];
        ?>
        <div class="crosssel-container tabsy mt-6 mt-sm-5">
            <div class="d-flex flex-row flex-no-wrap tabsy__label_wrap">
                <div class='tabsy__label active'><?= $arResult['COND_NAME'] ?></div>
            </div>
        </div>

        <?php
        $APPLICATION->IncludeComponent(
            "bitrix:catalog.section",
            $arParams['SECTION_TEMPLATE'],
            array(
                "ELEMENT_SORT_FIELD" => $arResult['SORT_BY'],
                "ELEMENT_SORT_ORDER" => $arResult['SORT_ORDER'],
                "PAGE_ELEMENT_COUNT" => $arResult['NUMBER_OF_PRODUCTS'],
                "FILTER_NAME" => $arParams["FILTER_NAME"],
                'SECTION_NAME' => $crosssell['NAME'] ?: $arParams['SECTION_NAME'],
            ) + $generalParams,
            $component
        );
    }
}
