class B2CCrosssellList {
    constructor(params) {
        this.container = params.container;
        this.inputName = params.inputName;
        this.componentPath = params.componentPath;
        this.arParams = params.arParams;
        this.crosssellArray = params.crosssellArray;
        this.init();
    }

    init() {
        this.tabsy = new Tabsy({
            selector: `#${this.container}`,
            inputName: `${this.inputName}`,
            onChange: this.changeTab.bind(this)
        });

        BX.Sotbit.B2C.createSlider(`${this.tabsy.selector} .tabsy__label_wrap`, {
            slides: {
                perView: 'auto',
                spacing: 24
            },
            loop: false,
        }, 'KeenSlider');
    }

    changeTab() {
        return new Promise(async (resolve, reject) => {
            document.querySelector(this.tabsy.selector)?.querySelectorAll('.tabsy__label.active')
                .forEach((label) => label.classList.remove('active'));

            if (this.tabsy.currentTab.classList.contains('collection-loaded')) {
                this.tabsy.currentTab.labels.forEach((label) => label.classList.add('active'));
                BX.onCustomEvent('crosssellTabChange');
                resolve();
                return;
            }

            try {
                await this.getCrosssell(this.tabsy.currentTab.id);
                this.tabsy.currentTab.labels.forEach((label) => label.classList.add('active'));
                BX.onCustomEvent('crosssellTabChange');
                resolve();
            } catch (e) {
                reject(e);
            }
        });
    }

    async getCrosssell(crosssellId) {
        return new Promise(async (resolve, reject) => {
            BX.showWait();
            BX.ajax({
                url: this.componentPath + '/ajax.php' + (document.location.href.indexOf('clear_cache=Y') !== -1 ? '?clear_cache=Y' : ''),
                method: 'POST',
                dataType: 'html',
                timeout: 60,
                async: true,
                data:
                    {
                        params: this.arParams,
                        siteId: BX.message('SITE_ID'),
                        crosssellId: crosssellId,
                        crosssellArray: this.crosssellArray
                    },
                onsuccess: (result) => {
                    const container = document.querySelector(`.tabsy__tab[data-collection-id="${crosssellId}"]`);
                    container.innerHTML = result;
                    this.tabsy.currentTab.classList.add('collection-loaded');
                    BX.closeWait();
                    resolve();
                },

                onfailure: function (type, e) {
                    console.error(e)
                    BX.closeWait();
                    reject(e);
                }
            });
        });

    }
}
