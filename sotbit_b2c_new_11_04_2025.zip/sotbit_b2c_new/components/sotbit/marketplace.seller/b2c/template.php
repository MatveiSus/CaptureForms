<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Public\Icon;

/**
 * @var array $arResult
 * @var string $templateFolder
 */

$this->setFrameMode(true);
?>

<div class="seller">
    <div class="seller__info">
        <?php
        if ($arResult['PARTNER']['DISPLAY_FIELDS']['LOGO']) { ?>
            <div class="seller__image">
                <img class="img-cover"
                     src="<?= $arResult['PARTNER']['DISPLAY_FIELDS']['LOGO']['src'] ?>"
                     alt="<?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?>">
            </div>
            <?php
        } ?>

        <div class="seller__title-container">
            <?php
            if ($arResult["PARTNER"]['DISPLAY_FIELDS']['DETAIL_PAGE_URL']) { ?>
                <a class="seller__title" href="<?= $arResult["PARTNER"]['DISPLAY_FIELDS']['DETAIL_PAGE_URL'] ?>"
                   title="<?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?>">
                    <?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?>
                </a>
                <?php
            } else { ?>
                <span class="seller__title" title="<?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?>"
                ><?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?></span>
                <?php
            } ?>

            <span class="seller__subtitle"><?= $arResult["PARTNER"]["PRODUCTS_COUNT"] ?>&nbsp;<?= $this->getComponent(
                )->getProductCountLang($arResult["PARTNER"]["PRODUCTS_COUNT"]) ?></span>
        </div>
    </div>
    <div class="seller__rating">
        <div class="seller__rating-item">
            <svg class="seller__rating-icon" width="24" height="24">
                <use xlink:href="<?= Icon::get('star_empty') ?>"></use>
            </svg>
            <span class="seller__rating-count"><?= $arResult["PARTNER"]["RATING"] ?></span>
            <span><?= Loc::getMessage('SM_PARTNER_DETAIL_RATING') ?></span>
        </div>
        <div class="seller__rating-item">
            <svg class="seller__rating-icon" width="24" height="24">
                <use xlink:href="<?= Icon::get('chat') ?>"></use>
            </svg>
            <span class="seller__rating-count"><?= $arResult["PARTNER"]["REVIEWS_COUNT"] ?></span>
            <span><?= $this->getComponent()->getReviewCountLang(
                    $arResult["PARTNER"]["REVIEWS_COUNT"]
                ) ?></span>
        </div>
    </div>
</div>
