<?php
$MESS["SA_REVIEWS_TITLE"] = "Reviews";
$MESS["SA_COMMENT_TITLE"] = "A comment";
$MESS["SOTBIT_REVIEWS_ERROR_MODULE_ACTIVE"] = "The sotbit.reviews module is not enabled";
