<?php
$MESS['SA_REVIEWS_TITLE'] = 'Отзывы';
$MESS['SA_COMMENT_TITLE'] = 'Вопросы';
$MESS['SOTBIT_REVIEWS_ERROR_MODULE_ACTIVE'] = 'Модуль sotbit.reviews не включен';
