<?php
$MESS["TITLE_MODAL_COMPLAINTS_SELECTION"] = "Are you sure you want to report a user?";
$MESS["TITLE_BTN_COMPLAINT"] = "Report a user";
$MESS["TITLE_MODAL_COPY"] = "Review link copied successfully";
$MESS["TITLE_BTN_COPY"] = "Share";
$MESS["TITLE_BTN_QUOTS"] = "Quote";
$MESS["TITLE_ANSWER"] = "Seller's response";
$MESS["TITLE_MODAL_EDIT"] = "Review has been changed!";
$MESS["TITLE_USER_NO"] = "Anonymous buyer";
$MESS["TITLE_COUNT_REVIEWS"] = "Reviews: ";
$MESS["TITLE_COUNT_NULL"] = "No reviews";
$MESS["TITLE_COUNT_NULL_MESSAGE"] = "There are no reviews for this product yet";
