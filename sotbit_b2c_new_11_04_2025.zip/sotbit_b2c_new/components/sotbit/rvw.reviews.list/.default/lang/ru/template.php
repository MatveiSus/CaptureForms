<?php
$MESS['TITLE_MODAL_COMPLAINTS_SELECTION'] = 'Вы уверены, что хотите пожаловаться на пользователя?';


$MESS['TITLE_BTN_COMPLAINT'] = 'Пожаловаться на пользователя';
$MESS['TITLE_MODAL_COPY'] = 'Ссылка на отзыв успешно скопирована';
$MESS['TITLE_BTN_COPY'] = 'Поделиться';
$MESS['TITLE_BTN_QUOTS'] = 'Цитировать';
$MESS['TITLE_ANSWER'] = 'Ответ продавца';
$MESS['TITLE_MODAL_EDIT'] = 'Отзыв изменён!';
$MESS['TITLE_USER_NO'] = 'Анонимный покупатель';
$MESS['TITLE_USER_NUMBER'] = 'Покупатель № #NUMBER#';

$MESS['TITLE_COUNT_REVIEWS'] = 'Отзывов: ';
$MESS['TITLE_COUNT_NULL'] = 'Нет отзывов';
$MESS['TITLE_COUNT_NULL_MESSAGE'] = 'У этого товара пока нет отзывов';