<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/** @var array $arCurrentValues */

if (isset($arCurrentValues['DISPLAY_COMPARE']) && $arCurrentValues['DISPLAY_COMPARE'] === 'Y') {
    $arTemplateParameters['COMPARE_URL'] = array(
        'PARENT' => 'COMPARE',
        'NAME' => GetMessage('CT_SMPD_COMPARE_URL'),
        'TYPE' => 'STRING',
        'DEFAULT' => SITE_DIR . 'catalog/compare/'
    );
}