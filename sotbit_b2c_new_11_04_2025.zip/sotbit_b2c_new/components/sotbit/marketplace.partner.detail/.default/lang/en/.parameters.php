<?php

$MESS['CT_SMPD_COMPARE_URL'] = "Compare page URL";
