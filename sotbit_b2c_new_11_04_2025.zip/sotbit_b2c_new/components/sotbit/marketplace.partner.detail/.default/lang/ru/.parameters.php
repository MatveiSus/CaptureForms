<?php

$MESS['CT_SMPD_COMPARE_URL'] = "URL, ведущий на страницу сравнения";