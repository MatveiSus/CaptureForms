<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var array $arParams
 * @var array $arResult
 * @var string $templateFolder
 * @var CBitrixComponent $component
 */

use Bitrix\Main\{Config\Option, Localization\Loc, UI\Extension, Web\Json};
use Sotbit\B2C\{Helper\Config, Public\Icon, Public\Sort};

$this->setFrameMode(true);

global $APPLICATION;

$useMinifiedAssets = Option::get('main', 'use_minified_assets', 'N') === 'Y';
$descriptionElementId = null;
$useMultipleContacts = false;
$partnerDetailElementId = 'partner-detail';

$this->addExternalCss(SITE_TEMPLATE_PATH . '/assets/css/common/socnet' . ($useMinifiedAssets ? '.min' : '') . '.css');
$APPLICATION->AddChainItem(htmlspecialcharsbx($APPLICATION->GetTitle()), $arParams['URL_TEMPLATES']['list']);
?>

    <div id="<?= $partnerDetailElementId ?>" class="partner-detail">
        <?php
        if ((int)$_REQUEST['PAGEN_1'] < 1) { ?>
            <div class="partner-detail__info">
                <?php
                if ($arResult['PARTNER']['DISPLAY_FIELDS']['LOGO']) { ?>
                    <div class="partner-detail__logo">
                        <img class="img-cover"
                             src="<?= $arResult['PARTNER']['DISPLAY_FIELDS']['LOGO']['src'] ?>"
                             alt="<?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?>"
                        >
                    </div>
                    <?php
                } ?>

                <h1 class="partner-detail__name"><?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?></h1>

                <span class="partner-detail__product-count">
                <?= $arResult["PARTNER"]["PRODUCTS_COUNT"] ?>
                <span class="partner-detail__muted-text"><?= $this->__component->getProductCountLang(
                        $arResult["PARTNER"]["PRODUCTS_COUNT"]
                    ) ?></span>
                </span>

                <?php
                if ($arResult["PARTNER"]['EMAILS'] || $arResult["PARTNER"]['PHONES']) { ?>
                    <div class="partner-detail__contacts">
                        <?php
                        if ($arResult["PARTNER"]['EMAILS']) {
                            $isEmailMultiple = count($arResult["PARTNER"]['EMAILS']) > 1;
                            $useMultipleContacts = $isEmailMultiple;
                            $firstEmail = current($arResult["PARTNER"]['EMAILS']);
                            ?>
                            <div class="partner-detail__contact partner-detail__contact--email<?= $isEmailMultiple ? ' partner-detail__contact--multiple' : '' ?>">
                                <a class="partner-detail__contact-item"
                                   href="mailto:<?= $firstEmail ?>"
                                   title="<?= $firstEmail ?>"
                                >
                                    <svg class="partner-detail__contact-icon" width="24" height="24">
                                        <use xlink:href="<?= Icon::get('envelope') ?>"></use>
                                    </svg>

                                    <span class="partner-detail__contact-text"><?= $firstEmail ?></span>
                                </a>
                                <?php
                                if ($isEmailMultiple) {
                                    ?>
                                    <ul class="partner-detail__contact-dropdown">
                                        <?php
                                        foreach ($arResult["PARTNER"]['EMAILS'] as $email) { ?>
                                            <li>
                                                <a class="partner-detail__contact-link"
                                                   href="mailto:<?= $email ?>"
                                                   title="<?= $email ?>"
                                                >
                                                    <?= $email ?>
                                                </a>
                                            </li>
                                            <?php
                                        } ?>
                                    </ul>

                                    <svg class="partner-detail__contact-icon partner-detail__contact-icon--chevron"
                                         width="24" height="24"
                                         data-contact="email"
                                    >
                                        <use xlink:href="<?= Icon::get('chevron') ?>"></use>
                                    </svg>
                                    <?php
                                } ?>
                            </div>
                            <?php
                        } ?>

                        <?php
                        if ($arResult["PARTNER"]['PHONES']) {
                            $isPhoneMultiple = count($arResult["PARTNER"]['PHONES']) > 1;
                            $useMultipleContacts = $isEmailMultiple;
                            $firstPhone = current($arResult["PARTNER"]['PHONES']);
                            ?>
                            <div class="partner-detail__contact partner-detail__contact--phone<?= $isPhoneMultiple ? ' partner-detail__contact--multiple' : '' ?>">
                                <a class="partner-detail__contact-item"
                                   href="tel:<?= $firstPhone ?>">
                                    <svg class="partner-detail__contact-icon" width="24" height="24">
                                        <use xlink:href="<?= Icon::get('phone') ?>"></use>
                                    </svg>

                                    <?= $firstPhone ?>
                                </a>
                                <?php
                                if ($isPhoneMultiple) { ?>
                                    <ul class="partner-detail__contact-dropdown">
                                        <?php
                                        foreach ($arResult["PARTNER"]['PHONES'] as $phone) { ?>
                                            <li>
                                                <a class="partner-detail__contact-link"
                                                   href="tel:<?= $phone ?>"
                                                   title="<?= $phone ?>"
                                                >
                                                    <?= $phone ?>
                                                </a>
                                            </li>
                                            <?php
                                        } ?>
                                    </ul>

                                    <svg class="partner-detail__contact-icon partner-detail__contact-icon--chevron"
                                         width="24" height="24"
                                         data-contact="phone"
                                    >
                                        <use xlink:href="<?= Icon::get('chevron') ?>"></use>
                                    </svg>
                                    <?php
                                } ?>
                            </div>
                            <?php
                        } ?>
                    </div>
                    <?php
                } ?>

                <?php
                if ($arParams["FIELD_SOCIAL_SERVICES"]) {
                    $ufCodeToImageIdMap = [
                        'UF_SOTBIT_INSTAGRAM' => 'in',
                        'UF_SOTBIT_X' => 'tw',
                        'UF_SOTBIT_LINKEDIN' => 'linkedin',
                        'UF_SOTBIT_FACEBOOK' => 'fb',
                        'UF_SOTBIT_YOUTUBE' => 'youtube',
                        'UF_SOTBIT_TELEGRAM' => 'telegram',
                        'UF_SOTBIT_VK' => 'vk',
                        'UF_SOTBIT_VK_VIDEO' => 'vk_video',
                        'UF_SOTBIT_RUTUBE' => 'rutube',
                    ];

                    $isSocnetBlockNotEmpty = (bool)array_filter(
                        array_intersect_key($arResult["PARTNER"]['DISPLAY_FIELDS'], $ufCodeToImageIdMap)
                    );

                    if ($isSocnetBlockNotEmpty) {
                        ?>
                        <div class="partner-detail__socnet">
                        <span class="partner-detail__socnet-title"><?= Loc::getMessage(
                                'SM_PARTNER_DETAIL_SOCNET_TITLE'
                            ) ?></span>
                            <ul class="partner-detail__socnet-list">
                                <?php
                                foreach ($arParams["FIELD_SOCIAL_SERVICES"] as $socialName) {
                                    if ($arResult["PARTNER"]['DISPLAY_FIELDS'][$socialName]) { ?>
                                        <li>
                                            <a class="partner-detail__socnet-item socnet-link socnet-link--<?= $ufCodeToImageIdMap[$socialName] ?>"
                                               href="<?= $arResult["PARTNER"]['DISPLAY_FIELDS'][$socialName] ?>"
                                               title="<?= Loc::getMessage(
                                                   'SM_PARTNER_DETAIL_SOCNET_' . strtoupper(
                                                       $ufCodeToImageIdMap[$socialName]
                                                   )
                                               ) ?>"
                                            >
                                                <svg class="socnet-link__icon" width="24" height="24">
                                                    <use xlink:href="<?= SITE_TEMPLATE_PATH . '/assets/image/socnet.svg#' . $ufCodeToImageIdMap[$socialName] ?>"></use>
                                                </svg>
                                            </a>
                                        </li>
                                        <?php
                                    }
                                } ?>
                            </ul>
                        </div>
                        <?php
                    }
                } ?>

                <div class="partner-detail__rating">
                    <div class="partner-detail__rating-item">
                        <svg class="partner-detail__rating-icon partner-detail__rating-icon--stars" width="24"
                             height="24">
                            <use xlink:href="<?= Icon::get('star') ?>"></use>
                        </svg>
                        <span><?= $arResult["PARTNER"]["RATING"] ?></span>
                        <span class="partner-detail__muted-text"><?= Loc::getMessage(
                                'SM_PARTNER_DETAIL_RATING'
                            ) ?></span>
                    </div>
                    <div class="partner-detail__rating-item">
                        <svg class="partner-detail__rating-icon" width="24" height="24">
                            <use xlink:href="<?= Icon::get('chat') ?>"></use>
                        </svg>
                        <span><?= $arResult["PARTNER"]["REVIEWS_COUNT"] ?></span>
                        <span class="partner-detail__muted-text"><?= $this->__component->getReviewCountLang(
                                $arResult["PARTNER"]["REVIEWS_COUNT"]
                            ) ?></span>
                    </div>
                </div>
            </div>

            <?php
            if ($arResult["PARTNER"]['DISPLAY_FIELDS']['BANNER']) { ?>
                <div class="partner-detail__banner">
                    <img class="img-cover"
                         src="<?= $arResult["PARTNER"]['DISPLAY_FIELDS']['BANNER']['SRC'] ?>"
                         alt="<?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?>">
                </div>
                <?php
            }

            if ($arResult["PARTNER"]['DISPLAY_FIELDS']['DESCRIPTION']) {
                $descriptionElementId = 'partner-detail-description';
                ?>
                <div class="partner-detail__description" id="<?= $descriptionElementId ?>">
                    <?= $arResult["PARTNER"]['DISPLAY_FIELDS']['DESCRIPTION'] ?>
                </div>
                <?php
            }
        } else { ?>
            <h1 class="partner-detail__name"><?= $arResult["PARTNER"]['DISPLAY_FIELDS']['NAME'] ?></h1>
            <?php
        } ?>

        <div class="partner-detail__products">
            <div class="partner-detail__sort">
                <?php
                $sort = Sort::include($this); ?>
            </div>

            <?php
            $APPLICATION->IncludeComponent(
                "bitrix:catalog.section",
                $arParams['SECTION_TEMPLATE'],
                array(
                    "CACHE_FILTER" => $arParams['CACHE_FILTER'],
                    "CACHE_GROUPS" => $arParams['CACHE_GROUPS'],
                    "CACHE_TIME" => $arParams['CACHE_TIME'],
                    "CACHE_TYPE" => $arParams['CACHE_TYPE'],
                    "DISPLAY_TOP_PAGER" => $arParams['DISPLAY_TOP_PAGER'],
                    "DISPLAY_BOTTOM_PAGER" => $arParams['DISPLAY_BOTTOM_PAGER'],
                    "SHOW_ALL_WO_SECTION" => "Y",
                    "ELEMENT_SORT_FIELD2" => $arParams['ELEMENT_SORT_FIELD2'],
                    "ELEMENT_SORT_FIELD" => $sort['FIELD'],
                    "ELEMENT_SORT_ORDER" => $sort['ORDER'],
                    "PAGE_ELEMENT_COUNT" => $arResult['NUMBER_OF_PRODUCTS'],
                    "ELEMENT_SORT_ORDER2" => $arParams['ELEMENT_SORT_ORDER2'],
                    "FILTER_NAME" => $arParams['FILTER_NAME'],
                    "USE_FILTER" => 'Y',
                    "IBLOCK_ID" => $arParams['IBLOCK_ID'],
                    "INCLUDE_SUBSECTIONS" => "Y",
                    "LABEL_PROP" => $arParams['LABEL_PROP'],
                    "LINE_ELEMENT_COUNT" => $arParams['LINE_ELEMENT_COUNT'],
                    "ADD_PROPERTIES_TO_BASKET" => $arParams['ADD_PROPERTIES_TO_BASKET'],
                    "ADD_SECTIONS_CHAIN" => $arParams['ADD_SECTIONS_CHAIN'],
                    "ADD_TO_BASKET_ACTION" => $arParams['ADD_TO_BASKET_ACTION'],
                    "AJAX_MODE" => $arParams['AJAX_MODE'],
                    "AJAX_OPTION_ADDITIONAL" => $arParams['AJAX_OPTION_ADDITIONAL'],
                    "AJAX_OPTION_HISTORY" => $arParams['AJAX_OPTION_HISTORY'],
                    "AJAX_OPTION_JUMP" => $arParams['AJAX_OPTION_JUMP'],
                    "AJAX_OPTION_STYLE" => $arParams['AJAX_OPTION_STYLE'],
                    "BACKGROUND_IMAGE" => $arParams['BACKGROUND_IMAGE'],
                    "BASKET_URL" => $arParams['BASKET_URL'],
                    "BROWSER_TITLE" => $arParams['BROWSER_TITLE'],
                    "COMPATIBLE_MODE" => $arParams['COMPATIBLE_MODE'],
                    "CONVERT_CURRENCY" => $arParams['CONVERT_CURRENCY'],
                    "DETAIL_URL" => $arParams['DETAIL_URL'],
                    "DISABLE_INIT_JS_IN_COMPONENT" => $arParams['DISABLE_INIT_JS_IN_COMPONENT'],
                    "DISPLAY_COMPARE" => $arParams['DISPLAY_COMPARE'],
                    "ENLARGE_PRODUCT" => $arParams['ENLARGE_PRODUCT'],
                    "HIDE_NOT_AVAILABLE" => $arParams['HIDE_NOT_AVAILABLE'],
                    "HIDE_NOT_AVAILABLE_OFFERS" => $arParams['HIDE_NOT_AVAILABLE_OFFERS'],
                    "IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
                    "LAZY_LOAD" => $arParams['LAZY_LOAD'],
                    "LOAD_ON_SCROLL" => $arParams['LOAD_ON_SCROLL'],
                    "MESSAGE_404" => $arParams['MESSAGE_404'],
                    "MESS_BTN_ADD_TO_BASKET" => $arParams['MESS_BTN_ADD_TO_BASKET'],
                    "MESS_BTN_BUY" => $arParams['MESS_BTN_BUY'],
                    "MESS_BTN_DETAIL" => $arParams['MESS_BTN_DETAIL'],
                    "MESS_BTN_SUBSCRIBE" => $arParams['MESS_BTN_SUBSCRIBE'],
                    "MESS_NOT_AVAILABLE" => $arParams['MESS_NOT_AVAILABLE'],
                    "META_DESCRIPTION" => $arParams['META_DESCRIPTION'],
                    "META_KEYWORDS" => $arParams['META_KEYWORDS'],
                    "OFFERS_LIMIT" => $arParams['OFFERS_LIMIT'],
                    "PAGER_BASE_LINK_ENABLE" => $arParams['PAGER_BASE_LINK_ENABLE'],
                    "PAGER_DESC_NUMBERING" => $arParams['PAGER_DESC_NUMBERING'],
                    "PAGER_DESC_NUMBERING_CACHE_TIME" => $arParams['PAGER_DESC_NUMBERING_CACHE_TIME'],
                    "PAGER_SHOW_ALL" => $arParams['PAGER_SHOW_ALL'],
                    "PAGER_SHOW_ALWAYS" => $arParams['PAGER_SHOW_ALWAYS'],
                    "PAGER_TEMPLATE" => $arParams['PAGER_TEMPLATE'],
                    "PAGER_TITLE" => $arParams['PAGER_TITLE'],
                    "PARTIAL_PRODUCT_PROPERTIES" => $arParams['PARTIAL_PRODUCT_PROPERTIES'],
                    "PRICE_CODE" => $arParams['PRICE_CODE'],
                    "PRICE_VAT_INCLUDE" => $arParams['PRICE_VAT_INCLUDE'],
                    "PRODUCT_BLOCKS_ORDER" => $arParams['PRODUCT_BLOCKS_ORDER'],
                    "PRODUCT_ID_VARIABLE" => $arParams['PRODUCT_ID_VARIABLE'],
                    "PRODUCT_PROPERTIES" => $arParams['PRODUCT_PROPERTIES'],
                    "PRODUCT_PROPS_VARIABLE" => $arParams['PRODUCT_PROPS_VARIABLE'],
                    "PRODUCT_QUANTITY_VARIABLE" => $arParams['PRODUCT_QUANTITY_VARIABLE'],
                    "PRODUCT_ROW_VARIANTS" => $arParams['PRODUCT_ROW_VARIANTS'],
                    "PRODUCT_SUBSCRIPTION" => $arParams['PRODUCT_SUBSCRIPTION'],
                    "PROPERTY_CODE" => $arParams['PROPERTY_CODE'],
                    "RCM_PROD_ID" => $arParams['RCM_PROD_ID'],
                    "RCM_TYPE" => $arParams['RCM_TYPE'],
                    "SEF_MODE" => $arParams['SEF_MODE'],
                    "SET_BROWSER_TITLE" => $arParams['SET_BROWSER_TITLE'],
                    "SET_LAST_MODIFIED" => $arParams['PRODUCT_PROPS_VARIABLE'],
                    "SET_META_DESCRIPTION" => $arParams['SET_META_DESCRIPTION'],
                    "SET_META_KEYWORDS" => $arParams['SET_META_KEYWORDS'],
                    "SET_STATUS_404" => $arParams['SET_STATUS_404'],
                    "SET_TITLE" => $arParams['SET_TITLE'],
                    "SHOW_404" => $arParams['SHOW_404'],
                    "SHOW_CLOSE_POPUP" => $arParams['SHOW_CLOSE_POPUP'],
                    "SHOW_DISCOUNT_PERCENT" => $arParams['SHOW_DISCOUNT_PERCENT'],
                    "SHOW_FROM_SECTION" => $arParams['SHOW_FROM_SECTION'],
                    "SHOW_MAX_QUANTITY" => $arParams['SHOW_MAX_QUANTITY'],
                    "SHOW_OLD_PRICE" => $arParams['SHOW_OLD_PRICE'],
                    "SHOW_PRICE_COUNT" => $arParams['SHOW_PRICE_COUNT'],
                    "SHOW_SLIDER" => $arParams['SHOW_SLIDER'],
                    "TEMPLATE_THEME" => $arParams['TEMPLATE_THEME'],
                    "USE_ENHANCED_ECOMMERCE" => $arParams['USE_ENHANCED_ECOMMERCE'],
                    "USE_MAIN_ELEMENT_SECTION" => $arParams['USE_MAIN_ELEMENT_SECTION'],
                    "USE_PRICE_COUNT" => $arParams['USE_PRICE_COUNT'],
                    "USE_PRODUCT_QUANTITY" => $arParams['USE_PRODUCT_QUANTITY'],
                    "SHOW_QUANTITY" => $arParams['USE_PRODUCT_QUANTITY'],
                    "OFFER_TREE_PROPS" => $arParams['OFFER_TREE_PROPS'],
                    "PRODUCT_DISPLAY_MODE" => $arParams['PRODUCT_DISPLAY_MODE'],
                    "ADD_PICT_PROP" => $arParams['ADD_PICT_PROP'],
                    "OFFER_ADD_PICT_PROP" => $arParams['OFFER_ADD_PICT_PROP'],
                    "COMPARE_PATH" => $arParams['COMPARE_PATH'],
                    "COMPARE_NAME" => $arParams['COMPARE_NAME'],
                    "COMPARE_URL" => $arParams['COMPARE_URL'],
                    "FAVORITE_URL" => $arParams['FAVORITE_URL'],
                    "USE_COMPARE_LIST" => $arParams['USE_COMPARE_LIST'],
                    "USE_SKU_TITLE_LIST" => Config::get("CATALOG_SEO_USE_SKU_TITLE_LIST"),
                    "USE_SKU_TITLE_DETAIL" => Config::get("CATALOG_SEO_USE_SKU_TITLE_DETAIL"),
                    "USE_SKU_DISTINCT_URL" => Config::get("CATALOG_SEO_USE_DISTINCT_URL"),
                    "USE_SKU_SEO" => Config::get("CATALOG_SEO_USE_SKU_SEO"),
                    "MESS_SHOW_MAX_QUANTITY" => Loc::getMessage("MESS_SHOW_MAX_QUANTITY"),
                    "SKU_VISUAL_VARIANT" => Config::get("CATALOG_LIST_SKU_VARIANT"),
                    "ITEM_HOVER_ANIMATION" => Config::get("CATALOG_ITEM_HOVER_ANIMATION"),
                    "ITEM_SCROLL_ON_HOVER" => Config::get("CATALOG_ITEM_SCROLL_ON_HOVER"),
                ),
                $component
            );
            ?>
        </div>
    </div>

<?php

if ($useMultipleContacts) {
    $this->addExternalJs($templateFolder . '/contacts' . ($useMinifiedAssets ? '.min' : '') . '.js');
}

if ($useMultipleContacts || $descriptionElementId) { ?>
    <script>
        <?php if ($useMultipleContacts) { ?>
        BX.message({SM_PARTNER_DETAIL_CONTACTS: '<?= Loc::getMessage('SM_PARTNER_DETAIL_CONTACTS') ?>'});
        BX.ready(() => initializeMobileContactsModal('<?= $partnerDetailElementId ?>', <?= Json::encode(
            [
                'email' => $arResult["PARTNER"]['EMAILS'],
                'phone' => $arResult["PARTNER"]['PHONES']
            ]
        ) ?>));
        <?php }
        if ($descriptionElementId) {
        Extension::load('sotbit.b2c.expandable_text');
        ?>
        BX.ready(() => ExpandableText && new ExpandableText('<?= $descriptionElementId ?>'));
        <?php } ?>
    </script>
    <?php
}
