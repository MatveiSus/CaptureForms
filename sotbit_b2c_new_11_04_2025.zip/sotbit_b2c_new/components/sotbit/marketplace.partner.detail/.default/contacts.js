const initializeMobileContactsModal = (containerId, contactsData) => {
    const container = document.getElementById(containerId);

    if (!container) {
        return console.error(`Element #${containerId} not found`);
    }

    const HIDE_MOBILE_MODAL_MEDIA_QUERY = '(min-width: 1025px)';

    const handleResize = () => {
        if (window.matchMedia(HIDE_MOBILE_MODAL_MEDIA_QUERY).matches) {
            popupInstance.close();
            popupInstance = null;
            window.removeEventListener('resize', handleResize);
        }
    }

    let popupInstance = null;

    container.querySelectorAll('[data-contact]').forEach((contactChevronElement) => {
        const contactType = contactChevronElement.dataset.contact;

        contactChevronElement.addEventListener('click', () => {
            if (window.matchMedia(HIDE_MOBILE_MODAL_MEDIA_QUERY).matches) {
                return;
            }

            const iconId = contactType === 'email' ? 'envelope' : 'phone';

            BX.Sotbit.B2C.showPopup({
                title: BX.message('SM_PARTNER_DETAIL_CONTACTS'),
                html: `
                    <div class="partner-detail__contact-modal">
                        <svg class="partner-detail__contact-modal-icon" width="24" height="24">
                            <use xlink:href="${BX.Sotbit.B2C.templatePath}/assets/image/sprite.svg#${iconId}"></use>
                        </svg>
                        <ul class="partner-detail__contact-modal-items">
                            ${contactsData[contactType].map((contact) => `
                                <li><a class="partner-detail__contact-link" href="${contactType === 'email' ? 'mailto:' : 'tel:'}${contact}" title="${contact}">${contact}</a></li>
                            `).join('')}                
                        </ul>
                    </div>
                `,
                width: '100%',
                showCancelButton: false,
                showConfirmButton: false,
                position: 'bottom-end',
                backdrop: true,
                showClass: {
                    popup: `
                          animate__animated
                          animate__fadeInUp
                          animate__faster
                        `
                },
                hideClass: {
                    popup: `
                          animate__animated
                          animate__fadeOutDown
                          animate__faster
                        `
                },
            }).then(([popupAction, popup]) => {
                popupInstance = popup;
                window.addEventListener('resize', handleResize);

                popupAction.then(() => window.removeEventListener('resize', handleResize));
            });
        });
    });
}
