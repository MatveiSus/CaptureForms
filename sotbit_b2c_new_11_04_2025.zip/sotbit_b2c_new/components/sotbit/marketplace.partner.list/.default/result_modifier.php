<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) {
    die();
}

if (!$arResult['PARTNERS']) {
    return;
}

$arAlphabet = [];

if (!function_exists('getFirstValidChar')) {
    function getFirstValidChar(string $name)
    {
        for ($i = 0; $i < mb_strlen($name); $i++) {
            $char = mb_substr($name, $i, 1);
            if (preg_match("/[a-zA-Zа-яА-ЯёЁ0-9]/u",$char)) {
                return is_numeric($char) ? '0-9' : mb_strtoupper($char);
            }
        }

        return '-';
    }
}

foreach ($arResult['PARTNERS']['DISPLAY_FIELDS'] as $partnerFields) {
    $arAlphabet[getFirstValidChar($partnerFields['NAME'])][] = $partnerFields;
}

ksort($arAlphabet);
$arResult['PARTNER_ALPHABET'] = $arAlphabet;