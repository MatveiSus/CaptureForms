<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;

$this->setFrameMode(true);

if (!$arResult['PARTNERS']) {
    return;
}
?>

<div class="partner_list">
    <div class="partner_list__alphabet" data-type="partner-alphabet">
        <button class="partner_list__alphabet_item active"
           data-id="all"><?= Loc::getMessage('SM_PARTNER_LIST_SYMBOL_ALL'); ?></button>
        <? foreach (array_keys($arResult['PARTNER_ALPHABET']) as $symbol): ?>
            <button class="partner_list__alphabet_item" data-id="<?= $symbol ?>"><?= $symbol ?></button>
        <? endforeach; ?>
    </div>
    <div data-type="partner-sections">
        <? foreach ($arResult['PARTNER_ALPHABET'] as $symbol => $arPartners): ?>
            <div class="partner_list__section">
                <div class="section_symbol">
                    <?= $symbol ?>
                </div>
                <div class="section_table">
                    <? foreach ($arPartners as $partner): ?>
                        <a href="<?= $partner['DETAIL_PAGE_URL'] ?>" class="table_item" title="<?= $partner['NAME'] ?>"><?= $partner['NAME'] ?></a>
                    <? endforeach; ?>
                </div>
            </div>
        <? endforeach; ?>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        new PartnerListComponent({
            alphabet_partner: <?=CUtil::PhpToJSObject($arResult['PARTNER_ALPHABET'])?>,
        });
    });
</script>
