;(function () {
    PartnerListComponent = function (params) {
        this.partnerAlphabet = params.alphabet_partner;
        this.alphabet = document.querySelector('[data-type="partner-alphabet"]');
        this.sectionList = document.querySelector('[data-type="partner-sections"]');
        this.init(params);
    }

    PartnerListComponent.prototype = {
        init: function () {
            this.initSymbolChange();
        },

        initSymbolChange: function () {
            this.alphabet.querySelectorAll('.partner_list__alphabet_item').forEach(item => {
               item.addEventListener('click', this.changeSymbol.bind(this));
            });
        },

        resetActive: function () {
            this.alphabet.querySelectorAll('.partner_list__alphabet_item').forEach(item => {
                item.classList.remove('active');
            });
        },

        changeSymbol: function (e) {
            const symbolLink = e.target;

            if (symbolLink.classList.contains('active')) {
                return;
            }

            this.resetActive();
            BX.showWait();
            this.createList(symbolLink.dataset.id);
            BX.closeWait();

            symbolLink.classList.add('active');
        },

        createList: function (symbol) {
            this.sectionList.innerHTML = '';
            if (symbol === 'all') {
                for (let s in this.partnerAlphabet) {
                    this.createSymbolList(s);
                }
            } else {
                this.createSymbolList(symbol);
            }
        },

        createSymbolList: function (symbol) {
            this.sectionList.appendChild(BX.create('div', {
                attrs: { className: 'partner_list__section' },
                children: [
                    BX.create('div', {
                        props : { className : 'section_symbol'},
                        text: symbol
                    }),
                    BX.create('div', {
                        props : { className : 'section_table'},
                        html: this.getPartnerList(symbol)
                    }),
                ],
            }));
        },

        getPartnerList: function (symbol) {
            let html = '';
            this.partnerAlphabet[symbol].forEach(partner => {
                html += `<a href="${partner.DETAIL_PAGE_URL}" class="table_item">${partner.NAME}</a>`;
            });

            return html;
        }
    }
})();