<?php
$MESS['TITLE_MODAL_COMPLAINTS_SELECTION'] = 'Вы уверены, что хотите пожаловаться на пользователя';

$MESS['TITLE_BTN_COMPLAINT'] = 'Пожаловаться на пользователя';
$MESS['TITLE_MODAL_COPY'] = 'Ссылка на вопрос успешно скопирована';
$MESS['TITLE_BTN_COPY'] = 'Поделиться';
$MESS['TITLE_BTN_QUOTS'] = 'Цитировать';
$MESS['TITLE_ANSWER'] = 'Ответ продавца';
$MESS['TITLE_MODAL_EDIT'] = 'Вопрос изменён!';
$MESS['TITLE_USER_NO'] = 'Анонимный покупатель';
$MESS['TITLE_USER_NUMBER'] = 'Покупатель № #NUMBER#';

$MESS['TITLE_COUNT_QUESTIONS'] = 'Вопросов: ';
$MESS['TITLE_COUNT_NULL'] = 'Нет вопросов';
$MESS['TITLE_COUNT_NULL_MESSAGE'] = 'У этого товара пока нет вопросов';