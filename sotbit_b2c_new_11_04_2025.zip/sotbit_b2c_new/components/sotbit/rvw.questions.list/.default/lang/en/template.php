<?php
$MESS['TITLE_MODAL_COMPLAINTS_SELECTION'] = 'Are you sure you want to report this user';
$MESS['TITLE_BTN_COMPLAINT'] = 'Report user';
$MESS['TITLE_MODAL_COPY'] = 'Question link copied successfully';
$MESS['TITLE_BTN_COPY'] = 'Share';
$MESS['TITLE_BTN_QUOTS'] = 'Quote';
$MESS['TITLE_ANSWER'] = 'Sellers answer';
$MESS['TITLE_MODAL_EDIT'] = 'Question edited!';
$MESS['TITLE_USER_NO'] = 'Anonymous buyer';
$MESS['TITLE_COUNT_QUESTIONS'] = 'Questions: ';
$MESS['TITLE_COUNT_NULL'] = 'No questions';
$MESS['TITLE_COUNT_NULL_MESSAGE'] = 'This product has no questions yet';
