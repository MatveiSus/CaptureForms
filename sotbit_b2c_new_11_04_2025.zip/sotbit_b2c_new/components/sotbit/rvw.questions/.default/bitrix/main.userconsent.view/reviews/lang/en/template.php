<?php

$MESS['USER_CONSENT_VIEW_LABEL_DEFAULT'] = "When submitting a review, please read the publication rules";
$MESS['USER_CONSENT_VIEW_CLOSE'] = 'Close';
