function UserConsentView(params) {
    this.isAgreementShown = false;
    this.text = params.text;
    this.buttonId = params.buttonId;
    this.title = this.getAgreementTitle();

    this.addEventListeners();
}

UserConsentView.prototype.getAgreementTitle = function () {
    const textTitleDotPos = this.text.indexOf(".");
    let textTitlePos = this.text.indexOf("\n");
    let title;

    textTitlePos = textTitlePos < textTitleDotPos ? textTitlePos : textTitleDotPos;

    title = (this.text.substr(0, textTitlePos).trim())
        .split(".")
        .map(Function.prototype.call, String.prototype.trim)
        .filter(String)[0];

    return title;
}

UserConsentView.prototype.showAgreement = async function () {
    if (this.isAgreementShown) {
        return;
    }

    if (!window.swal) {
        await BX.loadExt('sotbit.b2c.sweetalert2');
    }

    BX.Sotbit.B2C.fixBodyScroll();

    swal.fire({
        title: this.title,
        html: this.text,
        scrollbarPadding: false,
        width: 700,
        showCancelButton: true,
        showConfirmButton: false,
        cancelButtonText: BX.message('USER_CONSENT_VIEW_CLOSE'),
        showClass: {
            'popup': ''
        },
        hideClass: {
            'popup': ''
        },
        customClass: {
            container: 'user-consent-view',
            title: 'user-consent-view-title',
            cancelButton: 'user-consent-view-cancel-button',
            htmlContainer: 'user-consent-view-content custom-scrollbar'
        },
    }).then(() => {
        BX.Sotbit.B2C.unfixBodyScroll();
        this.isAgreementShown = false;
    });
}

UserConsentView.prototype.addEventListeners = function () {
    document.getElementById(this.buttonId).addEventListener('click', () => this.showAgreement());
}
