<?php

$MESS['USER_CONSENT_VIEW_LABEL_NAME'] = 'Label text';