<?php

$MESS['USER_CONSENT_VIEW_LABEL_DEFAULT'] = 'Отправляя отзыв, пожалуйста, ознакомьтесь с правилами публикации';
$MESS['USER_CONSENT_VIEW_CLOSE'] = 'Закрыть';
