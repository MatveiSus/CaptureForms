<?php
$MESS["MORE_BTN"] = "Show more";
$MESS["INFO_PAGENATION"] = "Questions #START# - #FINISH# from #ALL#";
