<?
$MESS["MORE_BTN"] = "Показать больше";
$MESS["INFO_PAGENATION"] = "Вопросы #START# - #FINISH# из #ALL#";
?>