<?php

$MESS['CT_SMP_COMPARE_URL'] = "URL, ведущий на страницу сравнения";