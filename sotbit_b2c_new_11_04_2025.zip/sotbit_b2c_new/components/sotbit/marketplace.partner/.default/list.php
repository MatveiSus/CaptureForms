<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

$this->setFrameMode(true);
$APPLICATION->AddChainItem(htmlspecialcharsbx($APPLICATION->GetTitle()), $arResult['URL_TEMPLATES']['list']);
?>

<div class="d-flex flex-column flex-lg-row gap-3 gap-lg-4 mb-5">
    <?php
    $APPLICATION->IncludeComponent("bitrix:breadcrumb", ""); ?>

    <h1 class="fs-4 fw-medium">
        <?php
        $APPLICATION->ShowTitle(); ?>
    </h1>
</div>

<?php
$APPLICATION->IncludeComponent(
    "sotbit:marketplace.partner.list",
    ".default",
    [
        "CACHE_TYPE" => $arParams["CACHE_TYPE"],
        "CACHE_TIME" => $arParams["CACHE_TIME"],
        "CACHE_GROUPS" => $arParams["CACHE_GROUPS"],
        "FIELD_NAME" => $arParams["FIELD_NAME"],
        "FIELD_DESCRIPTION" => $arParams["FIELD_DESCRIPTION"],
        "FIELD_LOGO" => $arParams["FIELD_LOGO"],
        "VARIABLES" => $arResult['VARIABLES'],
        "URL_TEMPLATES" => $arResult['URL_TEMPLATES'],
        "ALIASES" => $arResult['ALIASES'],
    ],
    $component
);
?>
