<?php
$MESS["B2C_META_TAGS_BTN_SHOW"] = "show all";
$MESS["B2C_META_TAGS_BTN_HIDE"] = "Hide";
