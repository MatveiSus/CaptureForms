<?php
$MESS['B2C_META_TAGS_BTN_SHOW'] = 'Показать все';
$MESS['B2C_META_TAGS_BTN_HIDE'] = 'Скрыть';