<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;

$HIDE_COUNT = 15;

$this->setFrameMode(true);
if ($arResult['ITEMS']):?>
    <div class="mb-5">
        <div id="seometa-tags" class="tags-pills__wrapper d-flex flex-row gap-4 flex-wrap shave">
            <? foreach ($arResult['ITEMS'] as $k => $item):
                if ($item['TITLE'] && $item['URL']) {
                    $count = $arParams['PRODUCT_COUNT'] === 'Y' ? ' (' . $item['PRODUCT_COUNT'] . ')' : '';
                    ?>
                    <a href="<?= $item['URL'] ?>" class="pill <?= $k > $HIDE_COUNT ? 'hide' : '' ?>"
                       title="<?= $item['TITLE'] . $count ?>">
                        <?= $item['TITLE'] . $count ?>
                    </a>
                    <?
                }
            endforeach; ?>
            <button data-type="shave" class="fw-medium <?= $k <= $HIDE_COUNT ? 'd-none' : '' ?>"><?=Loc::getMessage('B2C_META_TAGS_BTN_SHOW');?></button>
        </div>
    </div>

    <script>
        BX.ready(() => {
            new B2CMetaTags ({
                wrap: 'seometa-tags',
                message: {
                    btn: ['<?=Loc::getMessage('B2C_META_TAGS_BTN_HIDE')?>', '<?=Loc::getMessage('B2C_META_TAGS_BTN_SHOW')?>']
                }
            })
        });
    </script>
<? endif; ?>
