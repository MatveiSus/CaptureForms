;(function() {
    B2CMetaTags = function (params = {}) {
        this.wrap = document.getElementById(params.wrap);
        this.message = params.message;
        this.init();
    }

    B2CMetaTags.prototype = {
        init: function () {
            this.wrap.querySelectorAll('[data-type="shave"]').forEach(btn => {
                this.btn = btn;
                btn.addEventListener('click', this.toggleList.bind(this));
            });
        },

        toggleList: function () {
            this.wrap.classList.toggle('shave');
            this.btn.innerText = this.message.btn[+(this.wrap.classList.contains('shave'))];
        },
    }
})();