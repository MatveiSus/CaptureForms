<?
$MESS['SEO_META_TAGS_MORE'] = 'Показать все';
$MESS['SEO_META_TAGS_LESS'] = 'Скрыть';
?>