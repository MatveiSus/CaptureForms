<?
$MESS['SM_SORT_ORDER'] = 'Порядок сортировки категорий тегов';
$MESS['SM_SORT_ORDER_ASC'] = 'По возрастанию';
$MESS['SM_SORT_ORDER_DESC'] = 'По убыванию';
?>
