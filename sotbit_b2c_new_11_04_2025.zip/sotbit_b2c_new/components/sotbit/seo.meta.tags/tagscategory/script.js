BX.Sotbit.B2C.components.CategoryTags = class {
    constructor(params) {
        this.visibleTagsCount = params.visibleTagsCount;
        this.container = document.getElementById(params.containerId);

        this.container.classList.add('active');

        this.categories = this.container.firstElementChild;
        this.categoryNames = this.categories.querySelectorAll('.tagscategory__category-name');
        this.hiddenTags = Array.prototype.slice.call(
            this.container.querySelectorAll('.tagscategory__tag'),
            this.visibleTagsCount
        );
        this.showMoreButton = this.container.querySelector('.tagscategory__button');
        if (!this.hiddenTags.length) {
            this.showMoreButton.style.display = 'none';
        } else {
            this.animationOptions = {
                duration: 300,
                easing: 'cubic-bezier(0.25, 0.1, 0.25, 1)'
            };
            this.isAnimationRunning = false;
            this.expanded = false;

            this.handleResize();
            this.addEventListeners();
        }
    }

    setExpanded(expanded) {
        if (this.isAnimationRunning || this.expanded === expanded) {
            return;
        }

        this.isAnimationRunning = true;

        this.setShowMoreButtonText(expanded);
        this.setHiddenTagsState(expanded);

        const totalCategoriesHeight = BX.Sotbit.B2C.getTotalChildrenHeight(this.categories);
        const startHeight = expanded ? `${this.getContainerMinHeight()}px` : `${totalCategoriesHeight}px`;
        const endHeight = expanded ? `${totalCategoriesHeight}px` : `${this.getContainerMinHeight()}px`;
        const animation = this.categories.animate([
            {
                height: startHeight
            },
            {
                height: endHeight
            }
        ], this.animationOptions);

        animation.onfinish = () => {
            this.categories.setAttribute('aria-expanded', expanded);
            this.categories.style.height = endHeight;
            this.isAnimationRunning = false;
            this.expanded = expanded;
        }
    }

    setHiddenTagsState(hidden) {
        this.hiddenTags.forEach((tag) => tag.classList[hidden ? 'remove' : 'add']('tagscategory__tag--hidden'));
    }

    setShowMoreButtonText(expanded) {
        const message = expanded ? BX.message('SEO_META_TAGS_LESS') : BX.message('SEO_META_TAGS_MORE');
        this.showMoreButton.textContent = message;
        this.showMoreButton.setAttribute('title', message);
    }

    handleResize() {
        this.adjustContainerHeight();
        this.setCategoryTitle();
    }

    setCategoryTitle() {
        this.categoryNames.forEach((element) => {
           if (element.firstElementChild.offsetWidth > element.offsetWidth) {
               element.setAttribute('title', element.firstElementChild.textContent);
           } else {
               element.removeAttribute('title');
           }
        });
    }

    adjustContainerHeight() {
        setTimeout(() => {
            this.categories.style.height = '';
            this.categories.style.height = this.expanded
                ? `${BX.Sotbit.B2C.getTotalChildrenHeight(this.categories)}px`
                : `${this.getContainerMinHeight()}px`;
        }, 0);
    }

    getContainerMinHeight() {
        const lastVisibleTag = this.container.querySelector(`.tagscategory__tag:nth-child(${this.visibleTagsCount + 1})`);
        const containerRect = this.categories.getBoundingClientRect();
        const lastVisibleTagRect = lastVisibleTag.getBoundingClientRect();

        return Math.round(lastVisibleTagRect.bottom - containerRect.top);
    }

    addEventListeners() {
        window.addEventListener('resize', () => this.handleResize());
        this.showMoreButton.addEventListener('click', () => this.setExpanded(!this.expanded));
    }
}