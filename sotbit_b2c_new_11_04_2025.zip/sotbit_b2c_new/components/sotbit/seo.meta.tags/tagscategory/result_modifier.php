<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

/**
 * @var array $arParams
 * @var array $arResult
 */

if (!$arResult['ITEMS']) {
    return;
}

$arCategory = [];

foreach ($arResult['ITEMS'] as $item) {
    if ($arCategory[$item['TAGS_SECTION_ID']]) {
        $arCategory[$item['TAGS_SECTION_ID']]['ITEMS'][] = $item;
    } else {
        $arCategory[$item['TAGS_SECTION_ID'] ?: 1] = [
            'TITLE' => $item['TAGS_SECTION_NAME'],
            'SORT' => $item['TAGS_SECTION_SORT'],
            'ITEMS' => [$item],
        ];
    }
}

if ($arParams['SORT_ORDER_TAGS']) {
    $sort = $arParams['SORT_ORDER_TAGS'];
}

if ($sort === 'asc') {
    uasort($arCategory, function ($a, $b) {
        return $a['SORT'] <=> $b['SORT'];
    });
} else {
    uasort($arCategory, function ($a, $b) {
        return $b['SORT'] <=> $a['SORT'];
    });
}

$arResult['CATEGORY_TAGS'] = $arCategory;