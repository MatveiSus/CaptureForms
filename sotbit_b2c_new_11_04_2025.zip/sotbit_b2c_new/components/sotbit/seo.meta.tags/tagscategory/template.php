<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

/**
 * @var array $arParams
 * @var array $arResult
 */

use Bitrix\Main\Localization\Loc;

$this->setFrameMode(true);

if (!$arResult['CATEGORY_TAGS']) {
    return;
}

$containerId = 'seometa-tagscategory-' . $this->randString();
$tagsCount = 0;
?>

<div id="<?= $containerId ?>" class="tagscategory">
    <div class="tagscategory__categories" aria-expanded="false">
        <?php foreach ($arResult['CATEGORY_TAGS'] as $category) { ?>
            <div class="tagscategory__category">
                <span class="tagscategory__category-name"><span><?= $category['TITLE'] . ':' ?></span></span>

                <?php foreach ($category['ITEMS'] as $tag) {
                    $tagsCount++;

                    if ($arParams['PRODUCT_COUNT'] == 'Y') {
                        $tag['TITLE'] .= " ({$tag['PRODUCT_COUNT']})";
                    } ?>
                    <a class="tagscategory__tag<?= $tagsCount > $arParams['CNT_TAGS'] ? ' tagscategory__tag--hidden' : '' ?> pill pill-small"
                       href="<?= $tag['URL'] ?>"
                       title="<?= $tag['TITLE'] ?>"
                       tabindex="-1"
                    >
                        <span class="tagscategory__tag-name"><?= $tag['TITLE'] ?></span>
                    </a>
                <?php } ?>
            </div>
        <?php } ?>
    </div>
    <button class="tagscategory__button active"
            title="<?= Loc::getMessage('SEO_META_TAGS_MORE') ?>"
    >
        <?= Loc::getMessage('SEO_META_TAGS_MORE') ?>
    </button>
</div>

<script>
    BX.message({
        'SEO_META_TAGS_MORE': '<?= Loc::getMessage('SEO_META_TAGS_MORE') ?>',
        'SEO_META_TAGS_LESS': '<?= Loc::getMessage('SEO_META_TAGS_LESS') ?>',
    });

    BX.ready(() => {
        BX.Sotbit.B2C.components.CategoryTags && new BX.Sotbit.B2C.components.CategoryTags({
            containerId: '<?= $containerId ?>',
            visibleTagsCount: <?= (int)$arParams['CNT_TAGS'] ?>,
        });
    });
</script>
