<?php

$MESS['SM_REVIEWS_MODAL_TITLE'] = 'Отзывы о товаре';
$MESS['SM_REVIEWS_ANONYMOUS_USER'] = 'Анонимный пользователь';
$MESS['SM_REVIEWS_DIGNITY'] = 'Достоинства:';
$MESS['SM_REVIEWS_FLAWS'] = 'Недостатки:';
$MESS['SM_REVIEWS_ANSWER'] = 'Ответ покупателю';
$MESS['SM_REVIEWS_EMPTY_LIST_TITLE'] = 'Нет отзывов';
$MESS['SM_REVIEWS_EMPTY_LIST_TEXT'] = 'У этого товара пока нет отзывов. Станьте первым!';
$MESS['SM_REVIEWS_EMPTY_RATING'] = '0.0';
