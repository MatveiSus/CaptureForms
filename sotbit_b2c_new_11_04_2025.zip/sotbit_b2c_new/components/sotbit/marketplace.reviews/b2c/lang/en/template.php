<?php

$MESS["SM_REVIEWS_MODAL_TITLE"] = "Product reviews";
$MESS["SM_REVIEWS_ANONYMOUS_USER"] = "Anonymous user";
$MESS["SM_REVIEWS_DIGNITY"] = "Advantages:";
$MESS["SM_REVIEWS_FLAWS"] = "Flaws:";
$MESS["SM_REVIEWS_ANSWER"] = "Reply to buyer";
$MESS["SM_REVIEWS_EMPTY_LIST_TITLE"] = "No reviews";
$MESS["SM_REVIEWS_EMPTY_LIST_TEXT"] = "There are no reviews for this product yet. Be the first!";
$MESS['SM_REVIEWS_EMPTY_RATING'] = '0.0';
