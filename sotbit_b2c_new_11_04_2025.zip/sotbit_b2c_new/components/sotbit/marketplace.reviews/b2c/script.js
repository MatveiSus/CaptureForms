(function () {
    SM_ReviewsList = {
        init: async function () {
            if (!window.FsLightbox) {
                await BX.loadExt('sotbit.b2c.fslightbox');
            }

            refreshFsLightbox();
        },
    }
})();

document.addEventListener('DOMContentLoaded', () => {
    SM_ReviewsList.init();
});
