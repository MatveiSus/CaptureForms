<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var array $arParams
 * @var array $arResult
 *
 * @var CBitrixComponent $component
 */

use Bitrix\Main\{
    Engine\CurrentUser,
    Localization\Loc,
};
use Sotbit\B2C\{Public\Icon, Public\Image};

global $APPLICATION;

$currentUser = CurrentUser::get();

if ($arResult['ITEMS']): ?>
    <div id="reviews_wrap">
        <div class="reviews_title__row">
            <span class="title">
                <?= Loc::getMessage('SM_REVIEWS_MODAL_TITLE'); ?>
            </span>

            <?php
            if ($arParams['SHOW_REVIEWS_COUNT'] === 'Y') { ?>
                <span class="count">
                    <?= $arResult['ITEMS_COUNT'] ?>
                </span>
                <?php
            } ?>
        </div>

        <div class="reviews_rating__row">
            <span class="star text-warning">
                <svg class="text-warning" width="48" height="48">
                    <use xlink:href="<?= Icon::get('star') ?>"></use>
                </svg>
            </span>
            <span class="rating"><?= $arResult['PRODUCT_RATING'] ?></span>
            <?
            if ($currentUser->getId()): ?>
                <div class="reviews_add__component">
                    <?
                    $APPLICATION->IncludeComponent(
                        "sotbit:marketplace.reviews.add",
                        "b2c",
                        array(
                            "PRODUCT_ID" => $arParams["PRODUCT_ID"],
                            "MAX_FILES" => $arParams["MAX_FILES"],
                            "MAX_FILE_SIZE" => $arParams["MAX_FILE_SIZE"],
                            "AGREEMENT_ID" => $arParams["AGREEMENT_ID"],
                            "MAIN_COLOR" => $arParams["MAIN_COLOR"],
                        ),
                        $component
                    );
                    ?>
                </div>
            <?
            endif; ?>
        </div>

        <div class="reviews_carousel_wrapper position-relative">
            <?php
            if ($arResult['IMAGES']) { ?>
            <div class="keen-slider reviews_carousel">
                <?php
                foreach ($arResult['IMAGES'] as $image) { ?>
                    <a data-fslightbox="gallery_reviews" href="<?= $image['SRC'] ?>"
                       class="keen-slider__slide small-slider-image reviews_carousel__image">
                        <?= Image::loadLazy($image['SRC'], 'image', [
                            'IMAGE' => [
                                'class' => 'img-cover'
                            ]
                        ]) ?>
                    </a>
                    <?php
                } ?>
            </div>

            <div class="keen-slider__arrow keen-slider__arrow--prev"></div>
            <div class="keen-slider__arrow keen-slider__arrow--next"></div>
        </div>

        <script>
            const reviewsGallery = BX.Sotbit.B2C.createSlider('.reviews_carousel', {}, 'KeenSlider');
        </script>
        <?php
        } ?>

        <div class="reviews_list">
            <?
            foreach ($arResult['ITEMS'] as $item): ?>
                <div class="review_item">
                    <div class="stars">
                        <?
                        for ($i = 1; $i <= $item['RATING']; $i++): ?>
                            <span class="text-warning">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"
                                     fill="none">
                                <path d="M9.10433 2.89899C9.47114 2.15574 10.531 2.15574 10.8978 2.89899L12.8282 6.81048L17.1448 7.43772C17.9651 7.55691 18.2926 8.56488 17.699 9.14342L14.5755 12.1881L15.3129 16.4872C15.453 17.3042 14.5956 17.9271 13.8619 17.5414L10.0011 15.5116L6.14018 17.5414C5.40655 17.9271 4.54913 17.3041 4.68924 16.4872L5.4266 12.1881L2.30308 9.14341C1.70956 8.56488 2.03708 7.55691 2.8573 7.43772L7.17389 6.81048L9.10433 2.89899Z"
                                      fill="currentColor"/>
                                </svg>
                            </span>
                        <?
                        endfor; ?>
                    </div>
                    <div class="profile_wrap">
                        <span class="user">
                            <?= $item['ANONYMOUS'] !== 'Y' ? $item['USER_PRINT'] : Loc::getMessage(
                                'SM_REVIEWS_ANONYMOUS_USER'
                            ) ?>
                        </span>
                        <span class="date">
                            <?= $item['DATE']->format("d.m.Y") ?>
                        </span>
                    </div>
                    <?
                    if (trim($item['COMMENT'])): ?>
                        <div class="review_field">
                            <?= $item['COMMENT'] ?>
                        </div>
                    <?
                    endif; ?>
                    <?
                    if (trim($item['DIGNITY'])): ?>
                        <div class="review_field">
                            <span class="text-label"><?= Loc::getMessage('SM_REVIEWS_DIGNITY'); ?></span>
                            <?= $item['DIGNITY'] ?>
                        </div>
                    <?
                    endif; ?>
                    <?
                    if (trim($item['FLAWS'])): ?>
                        <div class="review_field">
                            <span class="text-label"><?= Loc::getMessage('SM_REVIEWS_FLAWS'); ?></span>
                            <?= $item['FLAWS'] ?>
                        </div>
                    <?
                    endif; ?>
                    <?
                    if ($item['MEDIA']): ?>
                        <div class="review_field media_row">
                            <?
                            foreach ($item['MEDIA'] as $file): ?>
                                <div class="media-item">
                                    <a data-fslightbox="gallery_<?= $item['ID'] ?>" href="<?= $file['SRC'] ?>">
                                        <?
                                        if (strpos($file['CONTENT_TYPE'], 'video') !== false): ?>
                                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none"
                                                 xmlns="http://www.w3.org/2000/svg">
                                                <rect width="48" height="48" rx="4" fill="#EEEEEE"/>
                                                <g filter="url(#filter0_b_6146_1272)">
                                                    <rect x="20" y="18" width="11" height="11" fill="white"
                                                          fill-opacity="0.2"/>
                                                </g>
                                                <path d="M24.5 12.5312C22.3306 12.5312 20.2099 13.1746 18.4061 14.3798C16.6023 15.5851 15.1964 17.2982 14.3662 19.3024C13.536 21.3067 13.3188 23.5122 13.742 25.6399C14.1652 27.7676 15.2099 29.7221 16.7439 31.2561C18.2779 32.7901 20.2324 33.8348 22.3601 34.258C24.4878 34.6812 26.6933 34.464 28.6976 33.6338C30.7018 32.8036 32.4149 31.3977 33.6202 29.5939C34.8254 27.7901 35.4688 25.6694 35.4688 23.5C35.4654 20.5919 34.3087 17.8039 32.2524 15.7476C30.1961 13.6913 27.4081 12.5346 24.5 12.5312ZM28.343 24.202L23.2805 27.577C23.1535 27.6619 23.0058 27.7106 22.8532 27.7181C22.7006 27.7255 22.5489 27.6914 22.4142 27.6193C22.2795 27.5472 22.1669 27.4399 22.0884 27.3088C22.01 27.1777 21.9686 27.0278 21.9688 26.875V20.125C21.9686 19.9722 22.01 19.8223 22.0884 19.6912C22.1669 19.5601 22.2795 19.4528 22.4142 19.3807C22.5489 19.3086 22.7006 19.2745 22.8532 19.2819C23.0058 19.2894 23.1535 19.3381 23.2805 19.423L28.343 22.798C28.4586 22.875 28.5534 22.9794 28.6189 23.1019C28.6845 23.2243 28.7188 23.3611 28.7188 23.5C28.7188 23.6389 28.6845 23.7757 28.6189 23.8981C28.5534 24.0206 28.4586 24.125 28.343 24.202Z"
                                                      fill="#9E9E9E"/>
                                                <defs>
                                                    <filter id="filter0_b_6146_1272" x="16" y="14" width="19"
                                                            height="19" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                        <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                                                        <feGaussianBlur in="BackgroundImageFix" stdDeviation="2"/>
                                                        <feComposite in2="SourceAlpha" operator="in"
                                                                     result="effect1_backgroundBlur_6146_1272"/>
                                                        <feBlend mode="normal" in="SourceGraphic"
                                                                 in2="effect1_backgroundBlur_6146_1272" result="shape"/>
                                                    </filter>
                                                </defs>
                                            </svg>
                                        <?
                                        else: ?>
                                            <img src="<?= $file['SRC'] ?>" alt="image">
                                        <?
                                        endif; ?>
                                    </a>
                                </div>
                            <?
                            endforeach; ?>
                        </div>
                    <?
                    endif; ?>
                    <?
                    if ($item['ANSWER']): ?>
                        <div class="review_field answer_row">
                            <div class="title"><?= Loc::getMessage('SM_REVIEWS_ANSWER'); ?></div>
                            <div>
                                <?= $item['ANSWER'] ?>
                            </div>
                        </div>
                    <?
                    endif; ?>
                </div>
            <?
            endforeach; ?>
        </div>
    </div>

    <div>
        <?
        $APPLICATION->IncludeComponent(
            "bitrix:main.pagenavigation",
            $arParams['PAGER_TEMPLATE'],
            array(
                "NAV_OBJECT" => $arResult['NAV_OBJECT'],
                "SEF_MODE" => "N",
            ),
            $component
        );
        ?>
    </div>
<?
else: ?>
    <div id="reviews_wrap">
        <div class="reviews_title__row">
            <span class="title">
                <?= Loc::getMessage('SM_REVIEWS_EMPTY_LIST_TITLE'); ?>
            </span>
        </div>

        <div class="empty-items__row">
            <?= Loc::getMessage('SM_REVIEWS_EMPTY_LIST_TEXT'); ?>
        </div>

        <div class="reviews_rating__row">
            <span class="star text-warning">
                <svg class="text-warning" width="48" height="48">
                    <use xlink:href="<?= Icon::get('star') ?>"></use>
                </svg>
            </span>
            <span class="rating"><?= Loc::getMessage('SM_REVIEWS_EMPTY_RATING') ?></span>
            <?
            if ($currentUser->getId()): ?>
                <div class="reviews_add__component">
                    <?
                    $APPLICATION->IncludeComponent(
                        "sotbit:marketplace.reviews.add",
                        "b2c",
                        array(
                            "PRODUCT_ID" => $arParams["PRODUCT_ID"],
                            "MAX_FILES" => $arParams["MAX_FILES"],
                            "MAX_FILE_SIZE" => $arParams["MAX_FILE_SIZE"],
                            "AGREEMENT_ID" => $arParams["AGREEMENT_ID"],
                            "MAIN_COLOR" => $arParams["MAIN_COLOR"],
                        ),
                        $component
                    );
                    ?>
                </div>
            <?
            endif; ?>
        </div>
    </div>
<?
endif; ?>
