<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

foreach ($arResult['ITEMS'] as $item) {
    foreach ($item['MEDIA'] as $image) {
        $arResult['IMAGES'][] = $image;
    }
}
