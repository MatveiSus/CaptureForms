<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\UI\Extension;
use Sotbit\B2C\Public\Icon;

Extension::load(['sotbit.b2c.choices']);
?>

<div id="regions_choose_component" class="region-choose">
    <div class="region-choose__header d-flex align-items-center gap-2" data-entity="select-city__block__header_city">
        <svg width="24" height="24">
            <use xlink:href="<?= Icon::get('location') ?>"></use>
        </svg>
        <span class="region-choose__header-city" data-entity="select-city__block__text-city"></span>
        <svg class="contacts-arrow" width="24" height="24">
            <use xlink:href="<?= Icon::get('chevron') ?>"></use>
        </svg>
    </div>

    <div id="regions_choose_component_dropdown"
         class="regions__choose_popup position-absolute p-4 bg-white border-radius d-none">
             <span class="select-city__dropdown__title mb-4 d-flex justify-content-center"
                   data-entity="select-city__dropdown__title"
             ><?= Loc::getMessage('SOTBIT_REGIONS_YOUR_CITY') . ' ###?' ?></span>

        <div class="d-flex gap-3 select-city__button_row">
            <input type="button" class="btn" value="<?= Loc::getMessage('SOTBIT_REGIONS_YES') ?>"
                   data-entity="select-city__dropdown__choose__yes">
            <input type="button" class="btn btn-secondary"
                   value="<?= Loc::getMessage('SOTBIT_REGIONS_NO') ?>"
                   data-entity="select-city__dropdown__choose__no">
        </div>
    </div>
</div>

<template id="regions_choose__template" data-entity="regions_choose__template">
    <div id="region_choose__modal" data-entity="region_choose_select-city__modal">
        <div class="region_choose__search-wrap">
            <div class="d-flex align-items-center gap-2 mb-4">
                <svg class="flex-shrink-0" width="24" height="24">
                    <use xlink:href="<?= Icon::get('location') ?>"></use>
                </svg>
                <span data-entity="select-city__block__text-city"></span>
            </div>

            <div class="mb-5" data-entity="sotbit-regions-countries-wrap">
                <label class="d-flex flex-column">
                    <select name="search_region"
                            data-choices='{"removeItemButton": false}'
                            data-entity="sotbit-regions-countries-select"
                    >
                    </select>
                </label>
            </div>
            <div class="mb-5">
                <label class="d-flex flex-column">
                    <span class="fs-1 fw-medium mb-2"><?= Loc::getMessage('SOTBIT_REGIONS_WRITE_SITY') ?></span>
                    <input class="input-text" type="text" name="select-city" maxlength="50"
                           placeholder="<?= Loc::getMessage('SOTBIT_REGIONS_WRITE_SITY_PLACEHOLDER') ?>"
                           data-entity="select-city__modal__submit__input">
                    <span class="text-error mt-2"><?= Loc::getMessage('SOTBIT_REGIONS_WRITE_SITY_ERROR') ?></span>
                </label>
            </div>
        </div>

        <div class="region_choose__regions-wrap custom-scrollbar">
            <div class="select-city__tab_content" data-entity="select-city__tab_content">
                <div class="select-city__empty_search fw-medium fs-4"><?= Loc::getMessage(
                        'SOTBIT_REGIONS_WRITE_SITY_ERROR_TEXT'
                    ) ?></div>
                <div class="select-city__groups">
                    <div class="fw-bold fs-2 mb-3"
                         style="display: none;"
                         data-entity="select-city__tab_name_content__big_city"
                    ><?= Loc::getMessage('SOTBIT_REGIONS_BIG_CITIES') ?></div>

                    <div class="mb-5 select-city__list_wrapper_favorites"
                         data-entity="select-city__list_wrapper_favorites">
                        <div class="select-city__list" data-entity="select-city__list"></div>
                    </div>
                    <div class="fw-bold fs-2"><?= Loc::getMessage('SOTBIT_REGIONS_CITIES') ?></div>
                    <div data-entity="select-city__list_wrapper_cities"></div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
    BX.message({
        'region_choose_modal_title': '<?= Loc::getMessage('SOTBIT_REGIONS_MODAL_TITLE') ?>'
    });

    document.addEventListener('DOMContentLoaded', () => {
        BX.Sotbit.B2C.components.regionsChoose = new B2CRegionsChoose();
    });
</script>
