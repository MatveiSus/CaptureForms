<?php 
$MESS["SOTBIT_REGIONS_YOUR_CITY"] = "Ваш город";
$MESS["SOTBIT_REGIONS_YES"] = "Да";
$MESS["SOTBIT_REGIONS_NO"] = "Нет";
$MESS["SOTBIT_REGIONS_MODAL_TITLE"] = "Выбрать регион";
$MESS["SOTBIT_REGIONS_WRONG_DETECT"] = "Неправильно определили? Выберите из списка:";
$MESS["SOTBIT_REGIONS_SELECT"] = "Или укажите в строке ниже:";
$MESS["SOTBIT_REGIONS_SELECT_SUBMIT"] = "Выбрать";
$MESS["SOTBIT_REGIONS_ERROR"] = "Указанный регион не найден";
$MESS["SOTBIT_REGIONS_BIG_CITIES"] = "Крупные города";
$MESS["SOTBIT_REGIONS_CITIES"] = "Населенные пункты";
$MESS["SOTBIT_REGIONS_WRITE_SITY"] = "Найти город";
$MESS["SOTBIT_REGIONS_WRITE_SITY_PLACEHOLDER"] = "Введите Ваш город";
$MESS["SOTBIT_REGIONS_WRITE_SITY_ERROR"] = "Выберите город из списка";
$MESS["SOTBIT_REGIONS_WRITE_SITY_ERROR_TEXT"] = "К сожалению ничего не найдено";
$MESS["SOTBIT_REGIONS_SP"] = "Санкт-Петербург";
$MESS["SOTBIT_REGIONS_MOSCOW"] = "Москва";
?>