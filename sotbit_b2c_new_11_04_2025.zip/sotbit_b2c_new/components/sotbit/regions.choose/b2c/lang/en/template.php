<?php
$MESS["SOTBIT_REGIONS_YOUR_CITY"] = "Your city";
$MESS["SOTBIT_REGIONS_YES"] = "Yes";
$MESS["SOTBIT_REGIONS_NO"] = "No";
$MESS["SOTBIT_REGIONS_MODAL_TITLE"] = "Select region";
$MESS["SOTBIT_REGIONS_WRONG_DETECT"] = "Incorrectly identified? Select from the list:";
$MESS["SOTBIT_REGIONS_SELECT"] = "Or enter on the line below:";
$MESS["SOTBIT_REGIONS_SELECT_SUBMIT"] = "Choose";
$MESS["SOTBIT_REGIONS_ERROR"] = "The specified region was not found";
$MESS["SOTBIT_REGIONS_BIG_CITIES"] = "Big cities";
$MESS["SOTBIT_REGIONS_CITIES"] = "Settlements";
$MESS["SOTBIT_REGIONS_WRITE_SITY"] = "Find city";
$MESS["SOTBIT_REGIONS_WRITE_SITY_PLACEHOLDER"] = "Enter your city";
$MESS["SOTBIT_REGIONS_WRITE_SITY_ERROR"] = "Choose a city from the list";
$MESS["SOTBIT_REGIONS_WRITE_SITY_ERROR_TEXT"] = "Unfortunately nothing was found";
$MESS["SOTBIT_REGIONS_SP"] = "Saint Petersburg";
$MESS["SOTBIT_REGIONS_MOSCOW"] = "Moscow";
