class B2CRegionsChoose {
    constructor() {
        this.getRegion();

        this.rootId = 'regions_choose_component';
        this.rootDropDownId = 'regions_choose_component_dropdown';
        this.selectRegionID = 'region_choose_select-city__modal';
        this.selectorTemplate = 'regions_choose__template';

        this.questionRegionId = null;
        this.currentRegionId = null;
        this.loctionList = null;

        this.bigCityList = null;
        this.countryList = null;
        this.activCountry = null;
        this.defaultExampleRegion = null;

        this.sweetAlertInstance = null;
        this.sweetAlertResult = null;
        this.searchValue = '';

        this.root = document.getElementById(this.rootId);

        this.rootDropDown = document.getElementById(this.rootDropDownId);
        this.selectRegion = this.getTemplate();

        this.countryWrap = this.getEntity(this.selectRegion, 'sotbit-regions-countries-wrap');
        this.countrySelect = this.getEntity(this.selectRegion, 'sotbit-regions-countries-select');
        this.citiesWrap = this.getEntity(this.selectRegion, 'select-city__tab_content');

        this.setEvents();
    }

    setEvents() {
        const yesBtn = this.getEntity(this.rootDropDown, 'select-city__dropdown__choose__yes');
        const notBnt = this.getEntity(this.rootDropDown, 'select-city__dropdown__choose__no');
        const cityChange = this.getEntity(this.root, 'select-city__block__header_city');

        this.searchLine = this.getEntity(this.selectRegion, 'select-city__modal__submit__input');
        this.searchLine.addEventListener('input', e => this.onInputSearch(e));

        yesBtn.addEventListener('click', () => {
            this.onSetRegion(this.questionRegionId)
        });
        notBnt.addEventListener('click', () => {
            this.onShowALLRegions();
            this.dropDownShow(false);
        });

        cityChange.addEventListener('click', () => this.onShowALLRegions());
        this.countrySelect.addEventListener('change', () => this.onShowALLRegions(this.countrySelect.value));
    }

    onShowALLRegions(countryId = Number.MAX_SAFE_INTEGER) {
        if (this.loctionList !== null && countryId === Number.MAX_SAFE_INTEGER) {
            return this.SHOW_SELECT_REGIONS({
                allRegions: this.loctionList,
                locationTemplateData: {activ: this.activCountry}
            });
        }

        BX.ajax.runAction('sotbit:regions.ChooseComponentController.showLocations', {
            data: {countryId}
        }).then(
            (res) => res.data.actions.forEach(i => this[i](res.data)),
            (err) => console.log(err),
        );
    }

    getRegion(deleteCookies = false) {
        const query = new URLSearchParams(window.location.search);
        const params = deleteCookies
            ? {deletCookies: 1}
            : {redirectRegionId: query.get('redirectRegionId')}

        this.removeRegionGetParams(query);

        BX.ajax.runAction('sotbit:regions.ChooseComponentController.getRegion', {
            data: params,
        }).then(
            (res) => {
                res.data.actions.forEach(i => this[i](res.data));
                BX.onCustomEvent('getRegion');
            },
            (err) => console.log(err),
        );
    }


    getEntity(parent, entity, all = false) {
        if (!parent || !entity) {
            return null;
        }
        if (all) {
            return parent.querySelectorAll('[data-entity="' + entity + '"]');
        }
        return parent.querySelector('[data-entity="' + entity + '"]');
    }

    getTemplate() {
        const tmp = this.getEntity(document, this.selectorTemplate);
        return this.getEntity(tmp.content.cloneNode(true), this.selectRegionID);
    }

    removeRegionGetParams(query) {
        if (query.has('redirectRegionId')) {
            const url = new URL(window.location.href, window.location.href);
            url.searchParams.delete('redirectRegionId');
            window.history.replaceState(null, '', url)
        }
    }

    SHOW_REGION_NAME({currentRegionName}) {
        this.getEntity(this.root, 'select-city__block__text-city').innerText = currentRegionName;
        this.getEntity(this.selectRegion, 'select-city__block__text-city').innerText = currentRegionName;
    }

    SHOW_QUESTION({currentRegionName, currentRegionId}) {
        this.questionRegionId = currentRegionId;
        this.dropDownShow(true);
        const element = this.getEntity(this.rootDropDown, 'select-city__dropdown__title');
        element.innerText = element.textContent.replace('###', currentRegionName).trim();
    }

    REDIRECT_TO_SUBDOMAIN({currentRegionCode, currentRegionId}) {
        const newUrl = window.location.href.replace(window.location.hostname, currentRegionCode);
        const url = new URL(newUrl, `${window.location.protocol}${currentRegionCode}`);
        url.searchParams.set('redirectRegionId', currentRegionId);
        window.location.href = url.toString();
    }

    async SHOW_SELECT_REGIONS({allRegions, locationTemplateData}) {
        if (this.sweetAlertInstance !== null) {
            this.showRegionsModal();
        }

        if (locationTemplateData === null) {
            locationTemplateData = {
                bigCity: allRegions,
                country: {},
                activ: 0,
            };
        }

        if (this.activCountry === locationTemplateData['activ']) {
            return;
        }

        this.loctionList = allRegions;
        this.countryList = locationTemplateData['country'];
        this.activCountry = locationTemplateData['activ'];
        this.bigCityList = locationTemplateData['bigCity'];

        this.citiesRender();
        this.renderCountryTabs();
        this.showRegionsModal().then(() => {
            this.countrySelect && BX.Sotbit.B2C.createCustomSelect(this.countrySelect);
        });

    }

    async renderModal() {
        [this.sweetAlertResult, this.sweetAlertInstance] = await BX.Sotbit.B2C.showPopup({
            width: '456px',
            title: BX.message('region_choose_modal_title'),
            html: '<div data-entity="regions-modal-content"></div>',
            position: 'top-end',
            showClass: {
                popup: `
                  animate__animated
                  ${BX.Sotbit.B2C.isLaptop() ? 'animate__fadeInUp' : 'animate__fadeIn'}
                  animate__faster
                `,
                backdrop: 'pressed swal2-backdrop-show region-choose-modal'
            },
            hideClass: {
                popup: `
                  animate__animated
                  ${BX.Sotbit.B2C.isLaptop() ? 'animate__fadeOutDown' : 'animate__fadeOut'}
                  animate__faster
                `,
                backdrop: 'pressed swal2-backdrop-hide region-choose-modal',
            },
            grow: 'column',
            showConfirmButton: false,
            showCloseButton: true,
        });

        this.sweetAlertContent = this.getEntity(document, 'regions-modal-content');

    }

    onSetRegion(regionId) {
        BX.ajax.runAction('sotbit:regions.ChooseComponentController.setRegion', {
            data: {regionId: regionId},
        }).then(
            (res) => res.data.actions.forEach(i => this[i](res.data)),
            (err) => {
                console.log(err)
            },
        )
    }

    dropDownShow(action) {
        this.setDropDownSideOffset();

        if (action) {
            BX.Sotbit.B2C.showElement(this.rootDropDown);
        } else {
            BX.Sotbit.B2C.hideElement(this.rootDropDown);
        }
    }

    setDropDownSideOffset() {
        const regionsElement = this.getEntity(this.root, 'select-city__block__header_city');

        if (!regionsElement) {
            return console.warn('Regions element not found, cannot determine offset side for positioning');
        }

        const {left, width} = regionsElement.getBoundingClientRect();
        const side = left + width > window.innerWidth / 2 ? 'right' : 'left';

        this.rootDropDown.style[side] = `0px`;
    }

    onInputSearch(e) {
        this.searchValue = e.currentTarget.value;
        this.showSearchEmpty(this.citiesRender());
    }

    citiesRender() {
        const bitCityWraper = this.getEntity(
            this.getEntity(this.selectRegion, 'select-city__list_wrapper_favorites'),
            'select-city__list',
        );
        const litersWrapper = this.getEntity(this.selectRegion, 'select-city__list_wrapper_cities');
        let issetItems = false;

        Array.from(bitCityWraper.childNodes).forEach(i => i.remove());
        Array.from(litersWrapper.childNodes).forEach(i => i.remove());

        if (!!this.bigCityList && Object.keys(this.bigCityList).length !== 0) {
            this.getEntity(this.selectRegion, 'select-city__tab_name_content__big_city')
                .setAttribute('style', 'display: block;');
        } else {
            this.getEntity(this.selectRegion, 'select-city__tab_name_content__big_city')
                .setAttribute('style', 'display: none;');
        }

        Object.keys(this.bigCityList)
            .filter(i => new RegExp(this.searchValue, 'i').test(this.bigCityList[i]))
            .forEach(i => {
                const element = document.createElement('span');
                element.innerText = this.bigCityList[i];
                element.addEventListener('click', () => {
                    this.onSetRegion(i);
                });
                bitCityWraper.append(element);

                issetItems = true;
            });

        const liters = new Set(
            Object.values(this.loctionList)
                .filter(i => new RegExp(this.searchValue, 'i').test(i))
                .map(i => i[0])
        );

        Array.from(Array.from(liters).sort()).forEach(i => {
            const oneliterWrapper = document.createElement('div')
            oneliterWrapper.setAttribute('class', 'mt-3');

            const literElem = document.createElement('span');
            literElem.setAttribute('class', 'fs-4 fw-medium');
            literElem.innerText = i;
            oneliterWrapper.append(literElem);

            const citysWrapper = document.createElement('div');
            citysWrapper.setAttribute('class', 'select-city__list');
            Object.keys(this.loctionList)
                .filter(j => i === this.loctionList[j][0])
                .filter(i => new RegExp(this.searchValue, 'i').test(this.loctionList[i]))
                .forEach(cityId => {
                    const cityElem = document.createElement('span');
                    cityElem.addEventListener('click', () => {
                        this.onSetRegion(cityId);
                    });
                    cityElem.innerText = this.loctionList[cityId];
                    citysWrapper.append(cityElem);
                });

            oneliterWrapper.append(citysWrapper);
            litersWrapper.append(oneliterWrapper);
            issetItems = true;
        });

        return issetItems;
    }

    showSearchEmpty(issetItems) {
        if (issetItems) {
            this.citiesWrap.classList.remove('empty-search');
            this.searchLine.classList.remove('error');
        } else {
            this.citiesWrap.classList.add('empty-search');
            this.searchLine.classList.add('error');
        }
    }

    renderCountryTabs() {
        if (Object.keys(this.countryList).length <= 1) {
            this.countryWrap.remove();
            this.countrySelect = null;
            if (BX.Sotbit.B2C.isDesktop()) {
                this.citiesWrap.style.maxHeight = 'calc(100vh - 250px)';
            } else {
                this.citiesWrap.style.maxHeight = 'calc(58vh - 150px)';
            }
            return;
        }


        Object.keys(this.countryList).forEach(i => {
            const element = document.createElement('option');
            element.setAttribute('value', i);

            if (this.activCountry === i) {
                element.setAttribute('selected', 'selected');
            }

            element.innerText = this.countryList[i];

            this.countrySelect.append(element);
        });
    }


    async showRegionsModal() {
        if (this.sweetAlertInstance === null) {
            await this.renderModal();
            this.sweetAlertContent.appendChild(this.selectRegion);
            return;
        }

        if (this.sweetAlertInstance.isVisible()) {
            this.sweetAlertContent.innerHTML = '';
            this.sweetAlertContent.appendChild(this.selectRegion);
        } else {
            await this.renderModal();
            this.sweetAlertContent.appendChild(this.selectRegion);
        }

    }
}
