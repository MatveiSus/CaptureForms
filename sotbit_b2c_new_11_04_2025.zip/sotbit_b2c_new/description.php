<?
use Bitrix\Main\Localization\Loc;

$arTemplate = array (
    'NAME' => 'Сотбит:Розница-new',
    'DESCRIPTION' => Loc::getMessage('SMR_TEMPLATE_DESCRIPTION').'-new',
    'SORT' => 100,
    'TYPE' => '',
);
?>