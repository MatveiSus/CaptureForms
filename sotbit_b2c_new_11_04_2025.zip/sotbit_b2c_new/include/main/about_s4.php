<?php

use Sotbit\B2C\Public\Image;

?>
<div class="mainpage-about__info">
    <span class="mainpage-about__subtitle">
        О нас
    </span>
    <h1 class="mainpage-about__title">
         <span style="font-size: 20pt;">ГидроТехПромСнаб - поставка рукавов из Европы</span>
    </h1>
    <div class="mainpage-about__content">
			 Компания ГидроТехПромСнаб (ГПТС) являясь структурным подразделением ООО "Торговый Дом "Леотек" обеспечивает бесперебойные поставки в Россию промышленных рукавов и РВД. Сотрудничая с нами вы получаете определенные преимущества:<br>
    </div>
    <div class="mainpage-about__content">
			<ul>
				<li>Отсутствие посредников</li>
				<li>Выгодные цены</li>
				<li>Широкий ассортимент наличия на складе</li>
				<li>Быстрая доставка из Европы рукавов под заказ/под клиента</li>
				<li>Хорошие скидки постоянным клиентам до 30%</li>
				<li>В 99% случаев выставляем счета ниже конкурентов за счет оптимизации процессов закупки и доставки рукавов</li>
			</ul>
    </div>
    <a href="<?= SITE_DIR ?>about/" class="mainpage-about__button btn btn-primary" title="Подробнее">Подробнее</a>
</div>
<div class="mainpage-about__image-container">
    <?= Image::loadLazy(
        SITE_TEMPLATE_PATH . '/assets/image/about.jpg',
        $GLOBALS['APPLICATION']->getProperty('title'),
        [
            'CONTAINER' => [
                'class' => 'mainpage-about__image'
            ],
            'IMAGE' => [
                'class' => 'img-cover'
            ]
        ]
    ); ?>
</div>
