<?php

use Sotbit\B2C\Public\Image;

?>
<div class="mainpage-about__info">
    <span class="mainpage-about__subtitle">
        О нас
    </span>
    <h1 class="mainpage-about__title">
        Сотбит.Розница: Интернет-магазин
    </h1>
    <div class="mainpage-about__content">
        Сотбит Розница: Интернет-магазин - это готовое решение профессионального уровня, позволяющее вам в сжатые
        сроки и с минимальными издержками запустить продажи товаров.<br>
        Ключевые особенности:
        <ul>
            <li>Быстрый запуск</li>
            <li>Легкая адаптация под различный ассортимент</li>
            <li>Возможность оптовой и розничной торговли, удобство использования</li>
            <li>Качественный дизайн</li>
            <li>Большой выбор вариантов оформления магазина</li>
            <li>Готовые технологии для организации рекламы на сайте</li>
        </ul>
    </div>
    <a href="<?= SITE_DIR ?>about/" class="mainpage-about__button btn btn-primary" title="Подробнее">Подробнее</a>
</div>
<div class="mainpage-about__image-container">
    <?= Image::loadLazy(
        SITE_TEMPLATE_PATH . '/assets/image/about.jpg',
        $GLOBALS['APPLICATION']->getProperty('title'),
        [
            'CONTAINER' => [
                'class' => 'mainpage-about__image'
            ],
            'IMAGE' => [
                'class' => 'img-cover'
            ]
        ]
    ); ?>
</div>
