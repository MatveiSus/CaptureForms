<?php

use Sotbit\B2C\Public\Image;

?>
<div class="mainpage-about__info">
    <span class="mainpage-about__subtitle">
        О нас
    </span>
    <h1 class="mainpage-about__title">
         Trelleborg в России!&nbsp;
    </h1>
    <div class="mainpage-about__content">
			 Инновации — одна из основных ценностей Trelleborg. Центром разработки продукции Trelleborg являются инженерные полимерные решения, которые отвечают специфическим требованиям клиентов к функциональным свойствам. Их целью также является улучшение бизнес-факторов — производительности, затрат, продаж и прибыльности — и профиля устойчивости для клиентов.&nbsp;Инновационные и надежные решения Trelleborg, которые герметизируют, увлажняют и защищают в сложных условиях. Независимо от того, является ли проблема экстремальным холодом, жарой, давлением или износом, или просто огромной силой природы, решения Trelleborg всегда готовы помочь.<br>
    </div>
    <div class="mainpage-about__content">
			<ul>
			</ul>
    </div>

    <a href="<?= SITE_DIR ?>about/" class="mainpage-about__button btn btn-primary" title="Подробнее">Подробнее</a>
</div>
<div class="mainpage-about__image-container">
    <?= Image::loadLazy(
        '/about/baner-about-trelleborg.jpeg',
        $GLOBALS['APPLICATION']->getProperty('title'),
        [
            'CONTAINER' => [
                'class' => 'mainpage-about__image'
            ],
            'IMAGE' => [
                'class' => 'img-cover'
            ]
        ]
    ); ?>
</div>
