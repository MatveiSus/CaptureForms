<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var string $title
 * @var string $url
 * @var string $linkTitle
 * @var string $linkTarget
 */

use Bitrix\Main\{Config\Option, Page\Asset};

Asset::getInstance()->addCss(
    SITE_TEMPLATE_PATH . '/include/main/blocks/style' . (Option::get(
        'main',
        'use_minified_assets',
        'N'
    ) === 'Y' ? '.min' : '') . '.css'
);

?>

<h2 class="main-page-block__title">
    <?php
    //non-breaking spaces are needed to create gap while not moving arrow icon to a new line ?>
    <a class="main-page-block__title-text"
       href="<?= $url ?>"
       target="<?= $linkTarget ?? '_self' ?>" <?= $linkTitle ? "title=\"$linkTitle\"" : '' ?>><?= $title ?>&nbsp;&nbsp;&nbsp;</a>
</h2>
