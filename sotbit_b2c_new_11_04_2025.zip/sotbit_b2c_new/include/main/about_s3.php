<?php

use Sotbit\B2C\Public\Image;

?>
<div class="mainpage-about__info">
    <span class="mainpage-about__subtitle">
         <span style="font-size: 12pt;">TUBI GOMMA TORINO S.p.a. в России</span>
    </span>
    <h1 class="mainpage-about__title">
         <span style="font-size: 16pt;">ТМ TubiGomma снова в продаже на российском рынке</span></h1>
 <span style="font-size: 14pt;">
    </h1>
    <div class="mainpage-about__content">
			 Компания ГидроТехПромСнаб (ГПТС) являясь структурным подразделением ООО "Торговый Дом "Леотек" обеспечивает бесперебойные поставки в Россию промышленных рукавов и РВД. Сотрудничая с нами вы получаете определенные преимущества:<br>
    </div>
    <div class="mainpage-about__content">
			<p>
 <span style="font-size: 14pt;">Компания TUBI GOMMA TORINO является лидирующим производителем промышленных резиновых рукавов и уже более 60 лет активно поставляет свою продукцию как на итальянский, так и на международный рынки.&nbsp;</span><br>
				<span style="font-size: 14pt;"> </span>
			</p>
			<span style="font-size: 14pt;"> </span>
			<p>
				<span style="font-size: 14pt;">
				TGT - частная компания среднего размера с блестящей репутацией , которая всегда адаптировалась к потребностям клиентов и требованиям рынка, принимая на себя всю ответственность в качестве производителя и эксперта по продукции и ее применению.</span><br>
				<span style="font-size: 14pt;"> </span>
			</p>
			<span style="font-size: 14pt;"> </span>
			<p>
				<span style="font-size: 14pt;">
				Такая позиция всегда заставляла компанию расширять свои усилия в направлении более специализированных рынков и требовательных отраслей.</span><br>
			</p>
    </div>
    <div class="mainpage-about__content">
			<ul>
			</ul>
    </div>
    <a href="<?= SITE_DIR ?>about/" class="mainpage-about__button btn btn-primary" title="Подробнее">Подробнее</a>
</div>
<div class="mainpage-about__image-container">
    <?= Image::loadLazy(
        '/about/baner-about-tubigomma.jpeg',
        $GLOBALS['APPLICATION']->getProperty('title'),
        [
            'CONTAINER' => [
                'class' => 'mainpage-about__image'
            ],
            'IMAGE' => [
                'class' => 'img-cover'
            ]
        ]
    ); ?>
</div>
