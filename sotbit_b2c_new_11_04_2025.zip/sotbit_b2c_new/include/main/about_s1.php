<?php

use Sotbit\B2C\Public\Image;

?>
<div class="mainpage-about__info">
    <span class="mainpage-about__subtitle">
        <span style="font-size: 12pt;">О компаниях Trelleborg Group (Франция) и ООО "ТД "Леотек" </span>
    </span>
    <h1 class="mainpage-about__title">
         <span style="font-size: 16pt;">ООО "ТД "Леотек" - ведущий дистрибьютор Trelleborg Group&nbsp;</span>
    </h1>
    <div class="mainpage-about__content">
			<p>
				 Торговый Дом "Леотек" и компания Trelleborg Fluid Handling Solutions выступают в качестве надежного партнера для клиентов на каждом этапе жизненного цикла продукции: от выбора материалов и сертификации, проектирования и производства до установки и обслуживания.&nbsp;Мы применяем уникальное сочетание опыта и технических знаний для предоставления комплексного решения по обработке жидкостей премиум-класса, которое обеспечивает полное спокойствие: снижает риск, повышает безопасность и обеспечивает максимальную выгоду для наших клиентов. Рукава для заправки топливом Trelleborg Aerokler обладают высокой износостойкостью. Не загрязняют топливо и являются лучшим решением для заправки самолетов. Легкий, гибкий и износостойкий шланг Aerokler позволит комфортно и безопасно проводить необходимые манипуляции с топливом при заправке авиационной техники. В стандартной комплектации доступен длиной 30 и 40 метров.
			</p>

    </div>
    <div class="mainpage-about__content">
			<ul>
			</ul>
    </div>
    <a href="<?= SITE_DIR ?>about/" class="mainpage-about__button btn btn-primary" title="Подробнее">Подробнее</a>
</div>
<div class="mainpage-about__image-container">
    <?= Image::loadLazy(
        '/about/baner-about-AEROKLERF.jpg',
        $GLOBALS['APPLICATION']->getProperty('title'),
        [
            'CONTAINER' => [
                'class' => 'mainpage-about__image'
            ],
            'IMAGE' => [
                'class' => 'img-cover'
            ]
        ]
    ); ?>
</div>
