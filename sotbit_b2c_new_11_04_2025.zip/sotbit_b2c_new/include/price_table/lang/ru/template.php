<?php

$MESS["PRICE_TABLE"] = "Таблица цен";
$MESS["PRICE_TABLE_RANGES_HEADER"] = "#TITLE# (цена за #RATIO#)";
$MESS["PRICE_TABLE_RANGES_TITLE"] = "Цены";
$MESS["PRICE_TABLE_RANGE_FROM"] = "от #FROM#";
$MESS["PRICE_TABLE_RANGE_TO"] = "до #TO#";
$MESS["PRICE_TABLE_RANGE_MORE"] = "и более";
