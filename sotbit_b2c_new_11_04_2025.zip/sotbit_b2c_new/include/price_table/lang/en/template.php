<?php

$MESS["PRICE_TABLE"] = "Pricing table";
$MESS["PRICE_TABLE_RANGES_HEADER"] = "#TITLE# (price for #RATIO#)";
$MESS["PRICE_TABLE_RANGES_TITLE"] = "Prices";
$MESS["PRICE_TABLE_RANGE_FROM"] = "from #FROM#";
$MESS["PRICE_TABLE_RANGE_TO"] = "to #TO#";
$MESS["PRICE_TABLE_RANGE_MORE"] = "and more";
