<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * Intended to use within catalog.item or catalog.element components
 *
 * @var array $arParams
 * @var array $arResult
 * @var array $actualItem
 * @var bool $showRanges
 * @var bool $showPriceTypes
 * @var bool $showPriceTypes
 * @var bool $useAllPrices
 * @var float $measureRatio
 */

use Bitrix\Main\{Config\Option, Localization\Loc, Page\Asset, Web\Json};
use Sotbit\B2C\Public\Icon;

if (!$arParams['USE_PRICE_COUNT']) {
    return;
}

Loc::loadMessages(__FILE__);

$this->addExternalCss(SITE_TEMPLATE_PATH . '/include/price_table/style' . (Option::get('main', 'use_minified_assets', 'N') === 'Y' ? '.min' : '') . '.css');

$showPriceTable = $showRanges || $showPriceTypes;
$useRatio = $arParams['USE_RATIO_IN_RANGES'] === 'Y';
?>

<div class="price-table <?= $showPriceTable ? '' : 'd-none' ?>" data-entity="price-table">
    <div class="price-table__label">
        <?= Loc::getMessage('PRICE_TABLE') ?>
        <svg class="price-table__arrow" width="16" height="16">
            <use xlink:href="<?= Icon::get('chevron') ?>"></use>
        </svg>
    </div>
    <div class="price-table__content" data-entity="price-table-content">
        <div class="price-table__list custom-scrollbar">
            <span class="price-table__header" data-entity="price-table-header"><?= Loc::getMessage(
                    'PRICE_TABLE_RANGES_HEADER',
                    [
                        '#TITLE#' => $arParams['MESS_PRICE_RANGES_TITLE'] ?: Loc::getMessage(
                            'PRICE_TABLE_RANGES_TITLE'
                        ),
                        '#RATIO#' => ($useRatio ? $measureRatio : 1) . ' ' . $actualItem['ITEM_MEASURE']['TITLE']
                    ]
                ) ?></span>
            <ul class="price-table__items" data-entity="price-table-items">
                <?php
                if ($showPriceTypes) {
                    // if FILL_ITEM_ALL_PRICES === 'Y' but price ranges are not used
                    foreach ($actualItem['ITEM_ALL_PRICES'][0]['PRICES'] as $price) { ?>
                        <li>
                            <?= $arResult['ALL_PRICES_NAMES'][$price['PRICE_TYPE_ID']] ?>
                            - <span><?= ($useRatio ? $price['PRINT_RATIO_PRICE'] : $price['PRINT_PRICE']) ?></span>
                        </li>
                        <?php
                    }
                } elseif ($useAllPrices) {
                    // if FILL_ITEM_ALL_PRICES === 'Y' and price ranges are used
                    foreach ($actualItem['ITEM_ALL_PRICES'] as $priceBlock) { ?>
                        <li>
                            <ul>
                                <li>
                                    <?php
                                    echo Loc::getMessage(
                                            'PRICE_TABLE_RANGE_FROM',
                                            ['#FROM#' => $priceBlock['QUANTITY_FROM'] . ' ' . $actualItem['ITEM_MEASURE']['TITLE']]
                                        ) . ' ';

                                    if (!$priceBlock['QUANTITY_TO']) {
                                        echo Loc::getMessage(
                                            'PRICE_TABLE_RANGE_MORE'
                                        );
                                    } else {
                                        echo Loc::getMessage(
                                            'PRICE_TABLE_RANGE_TO',
                                            ['#TO#' => $priceBlock['QUANTITY_TO'] . ' ' . $actualItem['ITEM_MEASURE']['TITLE']]
                                        );
                                    } ?>
                                </li>

                                <?php
                                foreach ($priceBlock['PRICES'] as $price) { ?>
                                    <li>
                                        <?= $arResult['ALL_PRICES_NAMES'][$price['PRICE_TYPE_ID']] ?>
                                        - <span><?= ($useRatio ? $price['PRINT_RATIO_PRICE'] : $price['PRINT_PRICE']) ?></span>
                                    </li>
                                    <?php
                                } ?>
                            </ul>
                        </li>
                        <?php
                    }
                } else {
                    // if FILL_ITEM_ALL_PRICES === 'N' are not filled
                    foreach ($actualItem['ITEM_QUANTITY_RANGES'] as $range) {
                        if ($range['HASH'] !== 'ZERO-INF') {
                            $itemPrice = false;

                            foreach ($arResult['ITEM_PRICES'] as $itemPrice) {
                                if ($itemPrice['QUANTITY_HASH'] === $range['HASH']) {
                                    break;
                                }
                            }

                            if ($itemPrice) { ?>
                                <li>
                                    <?php
                                    echo Loc::getMessage(
                                            'PRICE_TABLE_RANGE_FROM',
                                            ['#FROM#' => $range['SORT_FROM'] . ' ' . $actualItem['ITEM_MEASURE']['TITLE']]
                                        ) . ' ';

                                    if (is_infinite($range['SORT_TO'])) {
                                        echo Loc::getMessage(
                                            'PRICE_TABLE_RANGE_MORE'
                                        );
                                    } else {
                                        echo Loc::getMessage(
                                            'PRICE_TABLE_RANGE_TO',
                                            ['#TO#' => $range['SORT_TO'] . ' ' . $actualItem['ITEM_MEASURE']['TITLE']]
                                        );
                                    };
                                    echo ' - ';
                                    echo '<span>' . ($useRatio ? $itemPrice['PRINT_RATIO_PRICE'] : $itemPrice['PRINT_PRICE']) . '</span>'; ?>
                                </li>
                                <?php
                            }
                        }
                    }
                } ?>
            </ul>
        </div>
    </div>
</div>

<script>
    BX.message(<?= Json::encode(Loc::loadLanguageFile(__FILE__)) ?>);
</script>
