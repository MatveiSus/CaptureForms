<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var string $title
 * @var string $alt
 */

?>
<div class="d-flex flex-column align-items-center mt-6 mb-5">
    <img class="mw-100 d-block mb-4" src="<?= SITE_TEMPLATE_PATH . '/assets/image/empty.webp' ?>"
         alt="<?= $alt ?>">
    <span class="fw-medium fs-3"><?= $title ?></span>
</div>
