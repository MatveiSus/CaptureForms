<?php

use Bitrix\Main\{
    Loader,
    Localization\Loc,
};
use Bitrix\Fileman\Block\Sanitizer;
use Sotbit\B2C\Helper\Modules;
use Sotbit\B2C\Helper\Config;
use Sotbit\B2C\Public\Icon;

Loader::includeModule('fileman');

$regionData = Modules::getRegionData();
$showRegionData = Modules::useRegions() && $regionData !== null;
$phoneData = $email = $workingHours = $address = [];

if ($showRegionData) {
    if (is_array($regionData['UF_PHONE'])) {
        $phoneData = array_map(fn($item) => ['PHONE' => $item], $regionData['UF_PHONE']);
    }

    if (is_array($regionData['UF_EMAIL'])) {
        $email = implode('<br>', $regionData['UF_EMAIL']);
    }

    if (!empty($regionData['UF_WORKING_MODE'])) {
        $workingHours = $regionData['UF_WORKING_MODE'];
    }

    if (!empty($regionData['UF_ADDRESS'])) {
        $address = $regionData['UF_ADDRESS'];
    }
}

if (empty($phoneData)) {
    $phoneData = Config::get('CONTACTS_PHONE');
}

$phoneData = array_filter($phoneData);
$firstPhoneItem = reset($phoneData)['PHONE'];

if (empty($email)) {
    $email = Config::get('CONTACTS_EMAIL');
}

if (empty($workingHours)) {
    $workingHours = Config::get('CONTACTS_WORKING_HOURS');
}

if (empty($address)) {
    $address = Config::get('CONTACTS_ADDRESS');
}

if ($phoneData || $email || $workingHours || $address) { ?>
    <div class="contact-data d-flex gap-4 mt-5">
        <?php
        if ($phoneData): ?>
            <div class="d-flex gap-4 p-4 bg-primary-100 border-radius w-100 contact-data__item">
                <div class="contact-data__item-icon border-radius position-relative overflow-hidden d-flex flex-shrink-0 justify-content-center align-items-center">
                    <svg width="32" height="32">
                        <use xlink:href="<?= Icon::get('phone'); ?>"></use>
                    </svg>
                </div>


                <div class="d-flex flex-column">
                    <span class="fs-1 text-secondary-600"><?= Loc::getMessage(
                            'B2C_CONTACTS_PAGE_TEL'
                        ); ?></span>
                    <ul class="d-flex flex-column">
                        <?php
                        foreach ($phoneData as $phoneItem): ?>
                            <li class="d-flex flex-column mb-3">
                                <a class="fw-medium text-dark"
                                   href="tel:<?= htmlspecialcharsEx(
                                       str_replace(
                                           ' ',
                                           '',
                                           $phoneItem['PHONE']
                                       )
                                   ) ?>"><?= $phoneItem['PHONE'] ?></a>
                                <span class="contacts-page-description fs-1 text-secondary-600 word-wrap-anywhere"><?= $phoneItem['DESCRIPTION'] ?></span>
                            </li>
                        <?php
                        endforeach; ?>
                    </ul>
                </div>
            </div>
        <?php
        endif; ?>

        <?php
        if ($email): ?>
            <div class="d-flex gap-4 p-4 bg-primary-100 border-radius w-100 contact-data__item">
                <div class="contact-data__item-icon border-radius position-relative overflow-hidden d-flex flex-shrink-0 justify-content-center align-items-center">
                    <svg width="32" height="32">
                        <use xlink:href="<?= Icon::get('envelope'); ?>"></use>
                    </svg>
                </div>

                <div class="d-flex flex-column">
                    <span class="fs-1 text-secondary-600"><?= Loc::getMessage(
                            'B2C_CONTACTS_PAGE_EMAIL'
                        ); ?></span>
                    <a class="fw-medium text-dark"
                       href="mailto:<?= $email ?>"><?= $email ?></a>
                </div>
            </div>
        <?php
        endif; ?>

        <?php
        if ($workingHours): ?>
            <div class="d-flex gap-4 p-4 bg-primary-100 border-radius w-100 contact-data__item">
                <div class="contact-data__item-icon border-radius position-relative overflow-hidden d-flex flex-shrink-0 justify-content-center align-items-center">
                    <svg width="32" height="32">
                        <use xlink:href="<?= Icon::get('clock'); ?>"></use>
                    </svg>
                </div>

                <div class="d-flex flex-column">
                    <span class="fs-1 text-secondary-600"><?= Loc::getMessage(
                            'B2C_CONTACTS_PAGE_WH'
                        ); ?></span>
                    <p class="fw-medium"><?= Sanitizer::clean($workingHours) ?></p>
                </div>
            </div>
        <?php
        endif; ?>

        <?php
        if ($address): ?>
            <div class="d-flex gap-4 p-4 bg-primary-100 border-radius w-100 contact-data__item">
                <div class="contact-data__item-icon border-radius position-relative overflow-hidden d-flex flex-shrink-0 justify-content-center align-items-center">
                    <svg width="32" height="32">
                        <use xlink:href="<?= Icon::get('location'); ?>"></use>
                    </svg>
                </div>

                <div class="d-flex flex-column">
                    <span class="fs-1 text-secondary-600"><?= Loc::getMessage(
                            'B2C_CONTACTS_PAGE_ADDRESS'
                        ); ?></span>
                    <p class="fw-medium"><?= $address ?></p>
                </div>
            </div>
        <?php
        endif; ?>
    </div>
    <?php
} ?>

<h2 class="fs-4 fw-medium mt-5 mb-4"><?= Loc::getMessage('B2C_CONTACTS_PAGE_MAP_TITLE'); ?></h2>

<div style="border-radius: 32px; overflow: hidden;">
    <?php
    $APPLICATION->IncludeComponent(
	"bitrix:map.yandex.view",
	".default",
	array(
		"INIT_MAP_TYPE" => "MAP",
		"MAP_DATA" => Sotbit\B2C\Helper\Modules::getRegionMapData('a:4:{s:10:"yandex_lat";d:55.721260966217315;s:10:"yandex_lon";d:37.58552951952914;s:12:"yandex_scale";i:10;s:10:"PLACEMARKS";a:1:{i:0;a:3:{s:3:"LON";d:37.541734410734;s:3:"LAT";d:55.6556021847383;s:4:"TEXT";s:39:"Профсоюзная улица, 61А";}}}'),
		"MAP_WIDTH" => "100%",
		"MAP_HEIGHT" => "500",
		"CONTROLS" => array(
			0 => "ZOOM",
			1 => "SMALLZOOM",
			2 => "MINIMAP",
			3 => "TYPECONTROL",
			4 => "SCALELINE",
		),
		"OPTIONS" => array(
			0 => "ENABLE_SCROLL_ZOOM",
			1 => "ENABLE_DBLCLICK_ZOOM",
			2 => "ENABLE_DRAGGING",
		),
		"MAP_ID" => "yam_1",
		"COMPONENT_TEMPLATE" => ".default",
		"API_KEY" => ""
	),
	false
); ?>
</div>
