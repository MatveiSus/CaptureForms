<?php

$MESS['B2C_CONTACTS_PAGE_TEL'] = 'Телефон:';
$MESS['B2C_CONTACTS_PAGE_EMAIL'] = 'E-mail:';
$MESS['B2C_CONTACTS_PAGE_WH'] = 'Режим работы:';
$MESS['B2C_CONTACTS_PAGE_ADDRESS'] = 'Адрес:';
$MESS['B2C_CONTACTS_PAGE_MAP_TITLE'] = 'Схема проезда:';
