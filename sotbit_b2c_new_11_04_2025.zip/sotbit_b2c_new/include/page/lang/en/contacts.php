<?php

$MESS["B2C_CONTACTS_PAGE_TEL"] = "Telephone:";
$MESS["B2C_CONTACTS_PAGE_EMAIL"] = "Email:";
$MESS["B2C_CONTACTS_PAGE_WH"] = "Operating mode:";
$MESS["B2C_CONTACTS_PAGE_ADRESS"] = "Address:";
$MESS["B2C_CONTACTS_PAGE_MAP_TITLE"] = "Driving directions:";
