<?php

if (\Bitrix\Main\Loader::includeModule('sotbit.schemaorg')) {
    global $APPLICATION;
    \Sotbit\Schemaorg\EventHandlers::makeContent($APPLICATION->GetCurPage(false), 'localbusiness');
    $data = SchemaMain::getData();
    if (is_array($data)) {
        SchemaMain::setData($data);
    }
}