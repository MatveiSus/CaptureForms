<?php

use Sotbit\B2C\Helper\Config;

if (!Config::isDemoSite() || Config::isBot()) {
    return;
}

global $APPLICATION;

ob_start();
$APPLICATION->IncludeComponent('sotbit:b2c.demosettings', '');
$APPLICATION->AddViewContent('sotbit_b2c_demo_settings', ob_get_clean());
?>
