<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\{
    Helper\Config,
    Public\Icon
};
?>
<button class="go-top-btn <?= mb_strtolower(Config::get('GO_TO_TOP_BUTTON_POSITION')) ?>"
        data-entity="go-top-btn"
        title="<?= Loc::getMessage('GO_TO_TOP_BUTTON_TITLE'); ?>"
        aria-hidden="true"
>
    <svg width="24" height="24">
        <use xlink:href="<?= Icon::get('arrow_full') ?>"></use>
    </svg>
</button>
