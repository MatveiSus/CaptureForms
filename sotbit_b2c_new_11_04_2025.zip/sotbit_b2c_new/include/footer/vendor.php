<?php

use Bitrix\Main\Localization\Loc;
use Sotbit\B2C\Public\Image;

?>
<a href="https://sotbit.ru" title="<?= Loc::getMessage('COPYRIGHT_TITLE') ?>" class="footer__vendor" target="_blank">
    <?= Image::loadLazy(
        SITE_TEMPLATE_PATH . '/assets/image/sotbit.svg',
        GetMessage('COPYRIGHT_LOGO_ALT'),
        [
            'CONTAINER' => [
                'class' => 'footer__vendor-logo',
                'style' => 'width: 86px; height: 18px;'
            ],
            'IMAGE' => [
                'width' => 86,
                'height' => 18,
            ],
            'LOADER' => [
                'style' => 'transform: scale(6);',
            ]
        ]
    ) ?>
    <span class="footer__vendor-text"><?= Loc::getMessage('COPYRIGHT_DEVELOPERS') ?></span>
</a>