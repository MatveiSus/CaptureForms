<div class="d-flex justify-content-between flex-wrap gap-4 text-white fs-1">
	 © <?=date('Y');?> ООО "Торговый Дом "Леотек". Сайт tubigomma.ru -  представитель Tubi Gomma Torino S.p.a. в России.
</div>
<br>