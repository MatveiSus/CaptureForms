<script>
    document.querySelector('#request-callback-form1').addEventListener('click', function() {
        ym(98182326, 'reachGoal', 'Klikobratzvonok1');
        console.log('Klikobratzvonok1');
    });
    document.querySelector('#request-callback-form2').addEventListener('click', function() {
        ym(98182326, 'reachGoal', 'zakaz1');
    });
    document.querySelector('[data-entity="basket-menu-item"]').addEventListener('click', function() {
        ym(98182326, 'reachGoal', 'oformleniy1');
    });
    const saveButton = document.querySelector('#bx-soa-total .btn-order-save');

    if (saveButton) {
        saveButton.addEventListener('click', function() {
            ym(98182326, 'reachGoal', 'oformleniy2');
        });
    }
    
    function applyPhoneMask(selector) {
        var input = document.querySelector(selector);
        if (input) {
            IMask(input, {
                mask: '+{7}(000)000-00-00'
            });
        }
    }
    applyPhoneMask('#soa-property-57');
    applyPhoneMask('#soa-property-68');

    function restrictToLetters(selector) {
        var inputs = document.querySelectorAll(selector);
        inputs.forEach(function(input) {
            input.addEventListener('input', function() {
                this.value = this.value.replace(/[^a-zA-Zа-яА-ЯёЁ\s]/g, '');
            });
        });
    }
    restrictToLetters('#soa-property-55');
    restrictToLetters('#soa-property-66');
</script>