<div class="d-flex justify-content-between flex-wrap gap-4 text-white fs-1">
	 © <?=date('Y');?> ООО "Торговый Дом "Леотек". Сайт Треллеборг.рф -  представитель Trelleborg Fluid Handling Solutions в России.
</div>
<br>