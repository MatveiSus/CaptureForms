<span><?= \Bitrix\Main\Localization\Loc::getMessage('COPYRIGHT', ['#YEAR_CURRENT#' => date('Y')]) ?></span>
