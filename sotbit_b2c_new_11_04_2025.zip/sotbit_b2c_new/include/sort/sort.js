BX.Sotbit.B2C.Sort = class {
    constructor(data) {
        this.popup = document.querySelector('[data-role="sort_popup"]');
        this.sortElement = document.querySelector('[data-role="sort"]');
        this.data = data;
        this.isOpen = false;
        this.overlay = null;

        this.addEventListeners();
    }

    setSortParams(field, order) {
        const url = new URL(window.location);

        url.searchParams.set('sort_by', field);
        url.searchParams.set('sort_order', order);

        this.closeListPopup();

        window.location = url;
    }

    isMobile() {
        return window.matchMedia('(max-width: 1024px)').matches;
    }

    openListPopup() {
        if (this.isMobile()) {
            this.overlay = BX.Sotbit.B2C.showOverlay(20);
        }

        this.sortElement.classList.add('active');

        BX.Sotbit.B2C.showElement(this.popup, {
            duration: 100,
            callback: () => {
                document.addEventListener('click', (event) => {
                    if (!event.composedPath().includes(this.popup)) {
                        this.closeListPopup();
                    }
                }, {
                    once: true
                });

                this.isOpen = true;
            }
        })
    }

    closeListPopup() {
        this.overlay?.hide();
        this.sortElement.classList.remove('active');

        BX.Sotbit.B2C.hideElement(this.popup, {
            duration: 100,
            callback: () => {
                this.isOpen = false;
            }
        });
    }

    handleResize() {
        if (this.isOpen) {
            this.closeListPopup();
        }
    }

    addEventListeners() {
        this.sortElement.querySelector('[data-role="sort_btn"]').addEventListener('click', () => {
            this.isOpen ? this.closeListPopup() : this.openListPopup();
        });

        window.addEventListener('resize', this.handleResize.bind(this));
    }
}

// disable filter and sort if section is empty
BX.addCustomEvent('catalogSectionLoaded', (data) => {
    if (!data) {
        const sortButton = document.querySelector('[data-role="sort_btn"]');
        sortButton && (sortButton.disabled = true);

        const smartFilterButton = document.querySelector('[data-entity="smart-filter-btn"]');
        smartFilterButton && (smartFilterButton.disabled = true);
    }
});
