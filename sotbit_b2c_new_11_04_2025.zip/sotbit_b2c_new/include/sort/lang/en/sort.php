<?php
$MESS["CATALOG_FILTERS"] = "Filters";
$MESS["SORT"] = "Sort";