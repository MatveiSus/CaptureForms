<?php

$MESS["CATALOG_FILTERS"] = "Фильтры";
$MESS["SORT"] = "Сортировка";