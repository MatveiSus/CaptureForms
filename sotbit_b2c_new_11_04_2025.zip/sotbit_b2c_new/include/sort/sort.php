<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var array $configOptions
 * @var array $currentSort
 */

use Bitrix\Main\{Localization\Loc, Web\Json};
use Sotbit\B2C\Public\Icon;

Loc::loadMessages(__FILE__);
?>

    <div class="sort position-relative w-fit-content" data-role="sort">
        <button class="catalog__sort sort__btn text-dark" data-role="sort_btn">
            <span class="sort__title fw-medium">
                <?= $currentSort['NAME'] ?>
            </span>
            <svg class="sort__icon flex-shrink-0" width="24" height="24">
                <use xlink:href="<?= Icon::get('chevron') ?>"></use>
            </svg>
        </button>

        <ul class="sort__list-popup bg-white d-none py-3" data-role="sort_popup">
            <li class="sort__list-item sort__list-header justify-content-between">
                <span class="fw-medium">
                    <?= Loc::getMessage('SORT') ?>
                </span>

                <button class="sort__btn-close text-secondary-500" onclick="catalogSort.closeListPopup()">
                    <svg width="24" height="24">
                        <use xlink:href="<?= Icon::get('close') ?>"></use>
                    </svg>
                </button>
            </li>

            <?php
            foreach ($configOptions as $item) { ?>
                <li class="d-flex justify-content-between align-items-center">
                    <button class="sort__list-item-btn d-block flex-grow-1 fw-medium <?=
                    $item['FIELD'] == $currentSort['FIELD'] && $item['ORDER'] == $currentSort['ORDER']
                        ? 'text-primary'
                        : 'text-dark' ?>"
                            onclick="catalogSort.setSortParams('<?= $item['FIELD'] ?>', '<?= $item['ORDER'] ?>')"
                    >
                        <?= $item['NAME'] ?>
                    </button>
                </li>
                <?php
            } ?>
        </ul>
    </div>

    <script>
        window.catalogSort = new BX.Sotbit.B2C.Sort(<?= Json::encode($configOptions) ?>);
    </script>

<?php
return $currentSort;
