<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

/**
 * @var Request $request ;
 */

use Bitrix\Main\{Application, Config\Option, Localization\Loc, Page\Asset, Request, Web\Json};
use matthieumastadenis\couleur\{ColorFactory};
use Sotbit\B2C\{Helper\Config, Public\Image};

global $APPLICATION;

$asset = Asset::getInstance();

$APPLICATION->ShowCSS(false, false);
$APPLICATION->ShowHeadStrings(); // core, kernel, plugins if loaded via Extension::load
$APPLICATION->ShowHeadScripts();

$useMinifiedAssets = Option::get('main', 'use_minified_assets', 'N') === 'Y';

$asset->addJs(SITE_TEMPLATE_PATH . '/assets/js/common/script' . ($useMinifiedAssets ? '.min' : '') . '.js');
$asset->addJs(SITE_TEMPLATE_PATH . '/assets/js/layout/header' . ($useMinifiedAssets ? '.min' : '') . '.js');
$asset->addJs(SITE_TEMPLATE_PATH . '/assets/custom/' . SITE_ID . '/custom.js');
?>

<script>
    <?php
    if (Config::isDemoSite()) { ?>
    window.addEventListener('message', (event) => {
        if (event?.data.device) {
            BX.onCustomEvent('demoAdaptiveDeviceChange', event.data);
        }
    });
    <?php } ?>

    BX.ready(function () {
        BX.Sotbit.B2C.templatePath = '<?= ($request->isHttps() ? 'https://' : 'http://')
        . $request->getHttpHost()
        . SITE_TEMPLATE_PATH ?>';
        BX.Sotbit.B2C.loaderSvg = `<?= Image::getLoader() ?>`;
        BX.Sotbit.B2C.useMinOrderPrice = Boolean('<?= Config::useMinOrderPrice() ?>');
        BX.message(<?= Json::encode(Loc::loadLanguageFile(__FILE__)) ?>);
    });
</script>

<!-- PWA -->
<link rel="manifest" href="/app.webmanifest">
<!-- PWA end -->

<style>
    <?php include (Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/assets/css/style' . ($useMinifiedAssets ? '.min' : '') . '.css'); ?>
    :root {
    <?php
        $primaryHexCode = Config::get('COLOR_PRIMARY');
        $primaryHex = ColorFactory::newHexRgb($primaryHexCode);
        $gradientStart = ColorFactory::newHexRgb($primaryHexCode)
        ->toHsl()
        ->change('+29.11', '-8.92', '-5.1')
        ->toHexRgb();
        $gradientEnd = ColorFactory::newHexRgb($primaryHexCode)
        ->toHsl()
        ->change('-35.78', '+7.51', '-4.32')
        ->toHexRgb();

    ?> --primary: <?= $primaryHex ?>;
        --primary-hover: <?= ColorFactory::newHexRgb(Config::get('COLOR_HOVER')) ?>;
        --primary-active: <?= ColorFactory::newHexRgb(Config::get('COLOR_ACTIVE')) ?>;
        --primary-light: <?= ColorFactory::newHexRgb($primaryHexCode)->change(opacity: '-90%') ?>;
        --gradient-start: <?= $gradientStart ?>;
        --gradient-end: <?= $gradientEnd ?>;
        --gradient-start-transparent: <?= $gradientStart->change(opacity: '-90%') ?>;
        --gradient-end-transparent: <?= $gradientEnd->change(opacity: '-90%') ?>;
        --loader-1: <?= $primaryHex ?>;
        --loader-2: <?= (clone $primaryHex)->toHsl()->change(lightness: '+10', opacity: '-30')->toHexRgb() ?>;
        --loader-3: <?= (clone $primaryHex)->toHsl()->change(lightness: '+20', opacity: '-50')->toHexRgb() ?>;
        --loader-4: <?= (clone $primaryHex)->toHsl()->change(lightness: '+30', opacity: '-70')->toHexRgb() ?>;

    <?php
        $selfHostedFontName = Config::get('FONT');
        $useGoogleFont = Config::get('USE_GOOGLE_FONTS') === 'Y';
        $googleFontName = Config::get('GOOGLE_FONT_NAME');
    ?> --font-family: <?= $useGoogleFont ? $googleFontName : $selfHostedFontName ?>;
        --font-family-fallback: <?= $selfHostedFontName ?>;
    }
</style>

<style>
    <?php include (Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/assets/custom/' . SITE_ID . '/custom.css'); ?>
</style>

<?php
if ($useGoogleFont) { ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode(
        $googleFontName
    ) ?>:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&display=swap"
          rel="stylesheet" type="text/css" as="font">
    <?php
} else {
    $selfHostedFontNameNoWhitespace = str_replace(' ', '', $selfHostedFontName);

    $asset->addCss(
        SITE_TEMPLATE_PATH . "/assets/fonts/$selfHostedFontNameNoWhitespace/font" . ($useMinifiedAssets ? '.min' : '') . '.css'
    );
}
?>
