/* put your custom scripts here */

BX.addCustomEvent('onAjaxSuccess', function(){
   function applyPhoneMask(selector) {
        var input = document.querySelector(selector);
        if (input) {
            IMask(input, {
                mask: '+{7}(000)000-00-00'
            });
        }
    }
    applyPhoneMask('#soa-property-57');
});
