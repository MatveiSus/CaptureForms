BX.Sotbit.B2C.classes.MobileMenu = class {
    isOpen = false;
    container = null;
    currentItemId = 0;
    currentDepth = 0;
    data = {};
    catalogLink = `${BX.message('SITE_DIR')}catalog/`;

    chevronIcon = `
        <svg width="16" height="16">
            <use xlink:href="${BX.Sotbit.B2C.templatePath}/assets/image/sprite.svg#chevron"></use>
        </svg>`;

    constructor(header) {
        this.header = header;
        this.container = document.querySelector('[data-entity="header-mobile-menu"]');

        this.prepareData();
    }

    prepareData() {
        if (this.header.catalogMenu) {
            this.data.catalog = this.header.catalogMenu.data.filter((item) => item.LINK);
        }

        for (const menuType in BX.Sotbit.B2C.layout.menuData) {
            // 'catalog' key is reserved for default catalog menu
            if (BX.Sotbit.B2C.layout.menuData.hasOwnProperty(menuType) && menuType !== 'catalog') {
                this.data[menuType] = BX.Sotbit.B2C.layout.menuData[menuType];
            }
        }
    }

    adjustPosition() {
        const bottomBarBaseHeight = 72;
        const bodyComputedStyle = getComputedStyle(document.body);
        const bottomBarHeight = bottomBarBaseHeight + parseFloat(bodyComputedStyle.getPropertyValue("--safe-area-inset-bottom"));
        const topOffset = this.header.mainMenu.getBoundingClientRect().bottom;

        this.container.style.top = `${topOffset}px`;
        this.container.style.height = `${window.innerHeight - bottomBarHeight - topOffset}px`;
    }

    open() {
        BX.Sotbit.B2C.fixBodyScroll();
        this.showStartMenu();
        this.adjustPosition();
        BX.Sotbit.B2C.showElement(this.container);
    }

    close() {
        BX.Sotbit.B2C.unfixBodyScroll();
        this.clearMenu();
        BX.Sotbit.B2C.hideElement(this.container);
    }

    showStartMenu() {
        this.clearMenu();

        for (const menuType in this.data) {
            if (this.data.hasOwnProperty(menuType)) {
                if (menuType === 'catalog') {
                    this.container.appendChild(this.createCatalogFirstItem());
                } else {
                    this.container.appendChild(this.createStartMenuSection(menuType));
                }
            }
        }
    }

    showCatalogSubmenu() {
        this.clearMenu();
        const items = this.data['catalog'].filter((item) => +item.DEPTH_LEVEL === 1);
        const menuOptions = {
            props: {
                className: 'header-mobile-menu-section m-0 mh-100',
            },
            children: [
                BX.create('a', {
                    props: {
                        className: 'd-flex gap-4 p-4 py-lg-3 fw-medium align-items-center',
                        href: this.catalogLink
                    },
                    children: [
                        BX.create('div', {
                            children: this.chevronIcon,
                            events: {
                                click: (e) => {
                                    e.preventDefault();
                                    this.showStartMenu();
                                }
                            }
                        }),
                        BX.create('span', {
                            text: BX.message('CATALOG')
                        })
                    ],
                }),
                ...items.map((item) => this.createItem('catalog', item, item.ITEM_INDEX))
            ],
        }

        this.container.appendChild(BX.create('ul', menuOptions));
    }

    showSubmenuLevel(sectionCode, parentItemId, depthLevel) {
        this.clearMenu();

        const items = this.data[sectionCode].filter((item) => +item.DEPTH_LEVEL === depthLevel + 1 && +item.PARENT_INDEX === parentItemId);
        const menuOptions = {
            props: {
                className: 'header-mobile-menu-section m-0 mh-100',
            },
            children: [
                this.createSectionHeader(sectionCode, this.data[sectionCode].find((item) => +item.ITEM_INDEX === parentItemId && +item.DEPTH_LEVEL === depthLevel)),
                ...items.map((item, index) => this.createItem(sectionCode, item, index))
            ],
        }

        this.container.appendChild(BX.create('ul', menuOptions));
    }

    clearMenu() {
        while (this.container.firstChild) {
            this.container.removeChild(this.container.firstChild);
        }
    }

    createStartMenuSection(sectionCode) {
        if (!Array.isArray(this.data[sectionCode])) {
            this.data[sectionCode] = Object.values(this.data[sectionCode]);
        }

        const firstLevelItems = this.data[sectionCode].filter((item) => +item.DEPTH_LEVEL === 1 && !item.LINK?.includes?.(this.catalogLink));

        return BX.create('ul', {
            props: {
                className: 'header-mobile-menu-section m-0 mh-100',
            },
            children: firstLevelItems.map((item) => this.createItem(sectionCode, item, item.ITEM_INDEX))
        });
    }

    createCatalogFirstItem() {
        return BX.create('a', {
            props: {
                className: 'header-mobile-menu-catalog icon-reverse d-flex justify-content-between align-items-center gap-4 p-4 py-lg-3 fw-medium text-dark',
                href: this.catalogLink
            },
            children: [
                BX.create('span', {
                    text: BX.message('CATALOG')
                }),
                BX.create('div', {
                    html: this.chevronIcon
                })
            ],
            events: {
                click: (e) => {
                    e.preventDefault();
                    this.showCatalogSubmenu();
                }
            }
        });
    }

    createItem(sectionCode, item, index) {
        const showImage = sectionCode === 'catalog'
            && this.header?.catalogMenu?.data[index]?.IMAGE
            && item.DEPTH_LEVEL === 1;

        return BX.create('li', {
            props: {
                className: `header-mobile-menu-item ${sectionCode === 'top' ? ' text-secondary-700' : ''} ${showImage ? 'header-mobile-menu-item--has-image' : ''}`,
            },
            children: [
                BX.create('a', {
                    props: {
                        className: 'd-flex p-4 py-lg-3 text-dark icon-reverse',
                        href: item.LINK
                    },
                    children: [
                        showImage && BX.create('img', {
                            props: {
                                src: this.header.catalogMenu.data[index].IMAGE,
                                className: 'header-mobile-menu-catalog-image'
                            }
                        }),
                        BX.create('span', {
                            text: item.TEXT
                        }),
                        item.IS_PARENT && BX.create('div', {
                            html: this.chevronIcon,
                            props: {
                                className: 'ms-auto'
                            }
                        })
                    ],
                    events: {
                        click: (e) => {
                            if (item.IS_PARENT) {
                                e.preventDefault();
                                this.showSubmenuLevel(sectionCode, +item.ITEM_INDEX, +item.DEPTH_LEVEL)
                            }
                        }
                    }
                })
            ]
        })
    }

    createSectionHeader(sectionCode, item) {
        return BX.create('li', {
            props: {
                className: 'd-flex gap-4 p-4 py-lg-3 fw-medium align-items-center'
            },
            children: [
                BX.create('div', {
                    html: this.chevronIcon,
                    events: {
                        click: () => {
                            if (sectionCode === 'catalog' && +item.DEPTH_LEVEL === 1) {
                                this.showCatalogSubmenu();
                            } else {
                                +item.DEPTH_LEVEL > 1
                                    ? this.showSubmenuLevel(sectionCode, +item.PARENT_INDEX, +item.DEPTH_LEVEL - 1)
                                    : this.showStartMenu()
                            }
                        }
                    }
                }),
                BX.create('a', {
                    props: {
                        className: 'fw-medium text-dark',
                        href: item.LINK
                    },
                    text: item.TEXT,
                }),
            ]
        });
    }
}

BX.Sotbit.B2C.classes.Header = class {
    isMobileMenuInitialized = false;
    /** @var BX.Sotbit.B2C.classes.HeaderCatalogMenu */
    catalogMenu = null;
    openMenuButton = null;
    topMenuHeight = 0;
    bitrixAdminPanelMinHeight = 40;
    bitrixAdminPanelMaxHeight = 147;

    constructor() {
        this.container = document.querySelector('.header');

        if (!this.container) {
            return;
        }

        this.openMenuButtons = this.container.querySelectorAll('[data-entity="header-menu-open-btn"]');

        if (!this.openMenuButtons) {
            console.error('Open header menu button not found!');
        }

        this.topMenu = this.container.querySelector('.header__top');
        this.topMenuHeight = Number(this.topMenu?.offsetHeight);
        this.mainMenu = this.container.querySelector('.header__main');
        this.isFixed = false;

        this.updateHeaderFixedState();
        this.initializeMobileMenu();
        this.addEventListeners();
    }

    initializeMobileMenu() {
        this.mobileMenu = new BX.Sotbit.B2C.classes.MobileMenu(this);
    }

    openMainMenu() {
        if (!this.mobileMenu.isOpen) {
            if (!this.isMobileMenuInitialized) {
                this.initializeMobileMenu();
            }

            this.mobileMenu.open();
        }

        this.openMenuButtons.forEach((button) => {
            button.classList.add('active');
        });
        this.mobileMenu.isOpen = true;
    }

    closeMainMenu() {
        if (this.mobileMenu.isOpen) {
            this.mobileMenu.close();
        }

        this.openMenuButtons.forEach((button) => {
            button.classList.remove('active');
        });
        this.mobileMenu.isOpen = false;
    }

    openCatalogMenu() {
        if (!this.catalogMenu) {
            this.catalogMenu = BX.Sotbit.B2C.layout.catalogMenu;
        }

        if (!this.catalogMenu.isOpen) {
            this.catalogMenu.open();
        }

        this.catalogMenu.isOpen = true;
    }

    closeCatalogMenu() {
        if (!this.catalogMenu) {
            this.catalogMenu = BX.Sotbit.B2C.layout.catalogMenu;
        }

        if (this.catalogMenu.isOpen) {
            this.catalogMenu.close();
        }

        this.catalogMenu.isOpen = false;
    }

    toggleMainMenu() {
        this.mobileMenu.isOpen ? this.closeMainMenu() : this.openMainMenu();
    }

    toggleCatalogMenu() {
        if (!this.catalogMenu) {
            this.catalogMenu = BX.Sotbit.B2C.layout.catalogMenu;
        }

        this.catalogMenu.isOpen ? this.closeCatalogMenu() : this.openCatalogMenu();
    }

    fixHeader() {
        if (this.isFixed) {
            return;
        }

        this.container.classList.add('fixed');

        if (!BX.Sotbit.B2C.isLaptop()) {
            this.container.style.top = `-${this.topMenuHeight - (BX.admin?.panel?.isFixed() ? this.getBitrixAdminPanelHeight() : 0)}px`;
        }

        this.isFixed = true;

        BX.onCustomEvent('headerStateChange', {fixed: true});
    }

    unfixHeader() {
        if (!this.isFixed) {
            return;
        }

        this.container.classList.remove('fixed');
        this.container.style.top = null;

        this.isFixed = false;

        BX.onCustomEvent('headerStateChange', {fixed: false});
    }

    updateHeaderFixedState() {
        window.scrollY > this.topMenuHeight + (!BX.admin?.panel?.isFixed() ? this.getBitrixAdminPanelHeight() : 0)
            ? this.fixHeader()
            : this.unfixHeader();
    }

    getBitrixAdminPanelHeight() {
        let bitrixAdminPanelHeight = 0;

        if (BX.admin?.panel) {
            bitrixAdminPanelHeight = BX.admin.panel.state.collapsed
                ? this.bitrixAdminPanelMinHeight
                : this.bitrixAdminPanelMaxHeight;
        }

        return bitrixAdminPanelHeight;
    }

    handleResize() {
        this.container.style.top = !BX.Sotbit.B2C.isLaptop() && this.isFixed
            ? `-${this.topMenuHeight}px`
            : null;

        this.closeMainMenu();
    }

    addEventListeners() {
        window.addEventListener('scroll', () => this.updateHeaderFixedState(), {passive: true});

        this.openMenuButtons.forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                BX.Sotbit.B2C.isLaptop() ? this.toggleMainMenu() : this.toggleCatalogMenu();
            });
        });

        window.addEventListener('resize', () => this.handleResize());
    }
}

// contacts form in header
BX.Sotbit.B2C.classes.Contacts = class {
    constructor() {
        this.container = document.querySelector('.header .contacts');
        this.header = this.container.querySelector('.contacts-header');
        this.popup = this.container.querySelector('.contacts-popup');
        this.sweetAlertInstance = null;
        this.sweetAlertResult = null;
        this.mixinSwal = null;
        this.isPopupShown = false;
        this.popupDesktopOffsetStyles = [];

        this.setPopupSideOffset();
        this.addEventListeners();
    }

    setPopupSideOffset() {
        const {left, width} = this.header.getBoundingClientRect();
        const side = left + width > window.innerWidth / 2 ? 'right' : 'left';

        this.popup.style[side] = `0px`;
    }

    async showPopup() {
        if (this.isPopupShown) {
            return;
        }

        if (BX.Sotbit.B2C.isLaptop()) {
            [this.sweetAlertResult, this.sweetAlertInstance] = await BX.Sotbit.B2C.showPopup({
                title: BX.message('CONTACTS'),
                html: BX.create('div', {
                    html: this.popup.innerHTML
                }),
                width: '100%',
                showCancelButton: false,
                position: 'bottom-end',
                backdrop: true,
                showClass: {
                    popup: `
                          animate__animated
                          animate__fadeInUp
                          animate__faster
                        `
                },
                hideClass: {
                    popup: `
                          animate__animated
                          animate__fadeOutDown
                          animate__faster
                        `
                },
                customClass: {
                    container: 'contacts-swal-container',
                    confirmButton: 'btn d-flex w-100 justify-content-center align-items-center gap-3'
                },
                confirmButtonText: `
                    <svg class="flex-shrink-0" width="24" height="24">
                        <use xlink:href="${BX.Sotbit.B2C.templatePath}/assets/image/sprite.svg#phone"></use>
                    </svg>
                    <span>${BX.message('CONTACTS_BUTTON_TEXT')}</span>
                `
            });

            this.sweetAlertResult.then(result => {
                if (result.isConfirmed) {
                    BX.Sotbit.B2C.showForm('SOTBIT_REQUEST_A_CALL', {
                        MESSAGES: {
                            SUCCESS: BX.message('FORM_SUCCESS')
                        }
                    });
                }
            });
        } else {
            this.popup.classList.add('active');
        }

        this.isPopupShown = true;
    }

    hidePopup() {
        if (!this.isPopupShown) {
            return;
        }

        if (BX.Sotbit.B2C.isLaptop()) {
            this.sweetAlertInstance && this.sweetAlertInstance.close();
            delete this.sweetAlertInstance;
        } else {
            this.popup.classList.remove('active');
        }

        this.isPopupShown = false;
    }

    addEventListeners() {
        this.header.addEventListener('click', () => {
            if (BX.Sotbit.B2C.isLaptop()) {
                this.isPopupShown ? this.hidePopup() : this.showPopup();
            }
        });

        this.header.addEventListener('mouseenter', () => {
            if (!BX.Sotbit.B2C.isLaptop()) {
                this.showPopup();
            }
        });

        this.container.addEventListener('mouseleave', () => {
            if (!BX.Sotbit.B2C.isLaptop()) {
                this.hidePopup()
            }
        });

        window.addEventListener('resize', () => {
            if (!BX.Sotbit.B2C.isLaptop()) {
                this.sweetAlertInstance && this.sweetAlertInstance.close();
                delete this.sweetAlertInstance;
            }
        });
    }
}

BX.ready(function () {
    BX.Sotbit.B2C.classes.Header && (BX.Sotbit.B2C.layout.header = new BX.Sotbit.B2C.classes.Header());
});
