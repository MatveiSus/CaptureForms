/**
 * @namespace
 * @property {Object} Sotbit
 * @property {Object} Sotbit.B2C
 * @property {Object} Sotbit.B2C.components - object for shared data, e.g. for multiple instances of one component on one page
 */
BX.namespace("Sotbit.B2C");
BX.Sotbit.B2C = {
    classes: {},
    components: {
        catalogProductSubscribe: {
            products: {},
            currentlyCheckingSubscribe: {},
            setProductStatus: function (productId, status) {
                if (typeof productId === 'object') {
                    if (productId !== null) {
                        this.products = {...this.products, ...productId};
                    }
                } else {
                    if (!productId) {
                        throw new Error('Product ID is empty');
                    }

                    this.products[productId] = Boolean(status);
                }

                BX.onCustomEvent('onCatalogProductSubscribeChange', {
                    products: this.products
                });
            },
            checkSubscribe: async function (productId) {
                if (!productId) {
                    throw new Error('Product ID is empty');
                }

                if (this.products.hasOwnProperty(productId)) {
                    return this.products[productId];
                }

                if (this.currentlyCheckingSubscribe[productId]) {
                    return;
                }

                this.currentlyCheckingSubscribe[productId] = true;

                return BX.ajax.promise({
                    method: 'POST',
                    dataType: 'json',
                    url: '/bitrix/components/bitrix/catalog.product.subscribe/ajax.php',
                    data: {
                        sessid: BX.bitrix_sessid(),
                        checkSubscribe: 'Y',
                        itemId: productId
                    }
                }).then((result) => {
                    delete this.currentlyCheckingSubscribe[productId];

                    if (result.subscribe) {
                        this.setProductStatus(productId, true);
                        return true;
                    }

                    this.setProductStatus(productId, false);
                    return true;
                });
            }
        },

        authorization: {
            popup: null,

            sendForm: async function () {
                this.getAuthForm(new FormData(this.popup.getHtmlContainer().querySelector('form')));
            },

            getAuthForm: async function (data = null) {
                if (this.popup && !data) {
                    this.showPopup();
                    return;
                }

                try {
                    BX.showWait();
                    const resultAction = await BX.ajax.runAction('sotbit:b2c.authorization.getAuthForm', {
                        data: data || {}
                    });

                    this.requestAction(resultAction.data);
                } catch (e) {
                    console.error(e);
                } finally {
                    BX.closeWait();
                }
            },

            getRegisterForm: function () {
                const formData = new FormData();
                formData.set('register', 'yes');
                this.getAuthForm(formData);
            },

            requestAction: function (result) {
                if (result.additionalParams.isAuth) {
                    window.location.reload();
                    return;
                }

                this.renderPopupContent(result.html).then(() => {
                    this.replaceLink();
                });
            },

            renderPopupContent: async function (templateResult) {
                const processedTemplate = BX.processHTML(templateResult);
                const title = processedTemplate.HTML.match(/data-title="(.*)"/)?.[1];

                if (!this.popup) {
                    const popupResult = await BX.Sotbit.B2C.showPopup({
                        title: title || null,
                        html: processedTemplate.HTML,
                        heightAuto: true,
                        width: 582,
                        showConfirmButton: false,
                        customClass: {
                            container: 'popup-auth max-height-auto'
                        }
                    });

                    this.popup = popupResult[1];
                }

                this.popup.update({
                    html: processedTemplate.HTML,
                });

                BX.ajax.processScripts(processedTemplate.SCRIPT);
            },

            replaceLink: function () {
                const form = this.popup.getHtmlContainer().querySelector('form');
                form.setAttribute('onsubmit', "javascript:BX.Sotbit.B2C.components.authorization.sendForm(); return false;");
                BX.Sotbit.B2C.initIconEyePassword(form);
            },

            showPopup: function () {
                this.popup.fire();
                this.replaceLink();
            }
        },
    },
    layout: {},

    fixBodyScroll: function () {
        document.body.classList.add('fixed');
    },

    unfixBodyScroll: function () {
        document.body.classList.remove('fixed');
    },

    /**
     * @param {"top" | "header" | "filter"| number} mode
     * @param {HTMLElement} relativeElement
     * @returns {Object} overlay
     */
    showOverlay: function (
        mode = "top",
        relativeElement = document.body
    ) {
        const overlayElement = document.createElement('div');

        overlayElement.classList.add('overlay');
        overlayElement.style.zIndex = typeof mode === 'string' ? `var(--z-index-overlay-${mode})` : mode
        relativeElement.appendChild(overlayElement);
        overlayElement.offsetWidth; // force reflow
        overlayElement.style.opacity = 1;

        return {
            element: overlayElement,
            hide: () => this.hideOverlay(overlayElement)
        }
    },

    /**
     * @param {HTMLElement} overlay
     */
    hideOverlay: function (overlay) {
        if (!overlay) {
            return;
        }

        overlay.style.opacity = 0;

        setTimeout(() => {
            overlay.remove();
        }, parseFloat(getComputedStyle(document.body).getPropertyValue("--transition")) * 1000);
    },

    /**
     * @param {string} textToCopy
     * @param {Object} options
     * @param {string} options.messageSuccess
     * @param {string} options.messageError
     */
    copyToClipboard: async function (textToCopy, options) {
        options = {
            messageSuccess: BX.message('CLIPBOARD_COPY_SUCCESS'),
            messageError: BX.message('CLIPBOARD_COPY_ERROR'),
            ...options
        };

        if (navigator.clipboard) {
            await navigator.clipboard.writeText(textToCopy);
            return this.showMessage(options.messageSuccess);
        }

        try {
            const textInput = BX.create('input', {
                style: {
                    position: 'absolute',
                    height: 0,
                },
                attrs: {
                    value: textToCopy
                }
            });
            document.body.appendChild(textInput);
            textInput.select();

            const copyResult = document.execCommand('copy');
            document.body.removeChild(textInput);

            if (!copyResult) {
                return this.showMessage(options.messageError, {
                    icon: 'error'
                });
            }
        } catch (e) {
            return this.showMessage(options.messageError, {
                icon: 'error'
            });
        }

        this.showMessage(options.messageSuccess);
    },

    /**
     * @param {HTMLElement} parentElement
     * @returns {number}
     */
    getTotalChildrenHeight: function (parentElement) {
        return [...parentElement.children]
            .reduce((previous, current) => {
                const currentElementStyle = window.getComputedStyle(current);

                if (
                    currentElementStyle.display === 'none'
                    || currentElementStyle.position === 'absolute'
                    || currentElementStyle.position === 'fixed'
                ) {
                    return previous;
                }

                return previous + current.offsetHeight + parseInt(currentElementStyle.marginTop) + parseInt(currentElementStyle.marginBottom);
            }, 0);
    },

    currentlyAnimatedElements: new Map(),

    /**
     * @param {HTMLElement} element
     * @param {Object} [options]
     * @param {number} [options.duration]
     * @param {Function} [options.callback]
     */
    showElement: function (element, options) {
        if (!element.style.opacity == 0
            && !element.classList.contains('d-none')
            && !this.currentlyAnimatedElements.has(element)) {
            return;
        }

        options = {
            duration: 300,
            ...options
        };

        element.classList.remove('d-none');

        const animation = element.animate(
            [
                {
                    opacity: 0
                },
                {
                    opacity: 1
                }
            ],
            {
                duration: options.duration
            }
        );

        animation.onfinish = () => {
            options.callback && options.callback(element);
        };

        this.currentlyAnimatedElements.set(element, animation);
    },

    /**
     * @param {HTMLElement} element
     * @param {Object} [options]
     * @param {number} [options.duration]
     * @param {Function} [options.callback]
     */
    hideElement: function (element, options) {
        if (element.style.opacity == 0
            && element.classList.contains('d-none')
            && !this.currentlyAnimatedElements.has(element)
        ) {
            return;
        }

        const currentlyAnimatedElementEasing = this.currentlyAnimatedElements.get(element);

        if (currentlyAnimatedElementEasing) {
            this.currentlyAnimatedElements.delete(element);
            currentlyAnimatedElementEasing.finish();
        }

        options = {
            duration: 300,
            ...options
        };

        const animation = element.animate([
                {
                    opacity: 1
                },
                {
                    opacity: 0
                }
            ],
            {
                duration: options.duration
            }
        );

        animation.onfinish = () => {
            element.classList.add('d-none');
            options.callback && options.callback(element);
        };
    },

    /**
     * @param {string} message
     * @param {Object} [options]
     * @param {"success" | "error"} [options.icon]
     * @param {number} [options.durationShow]
     * @param {number} [options.durationHide]
     * @param {number} [options.durationVisible]
     * @param {Function} [options.onShow]
     * @param {Function} [options.onHide]
     */
    showMessage: function (message, options) {
        options = {
            icon: 'success',
            durationShow: 500,
            durationHide: 300,
            durationVisible: 2500,
            ...options
        };

        const icons = {
            success: `<svg class="text-primary" width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                        <path d="M29.726 5.3125C30.1058 5.71343 30.0887 6.34637 29.6877 6.7262L10.6877 24.7262C10.4943 24.9095 10.2356 25.008 9.96926 24.9998C9.70288 24.9916 9.45079 24.8774 9.26895 24.6826L2.26895 17.1826C1.89211 16.7788 1.91393 16.146 2.31769 15.7692C2.72144 15.3924 3.35423 15.4142 3.73106 15.8179L10.0436 22.5814L28.3123 5.27429C28.7132 4.89446 29.3461 4.91157 29.726 5.3125Z" fill="currentColor"/>
                    </svg>
                    `,
            error: `<svg class="text-primary" width="32" height="32" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4.39705 4.55379L4.46967 4.46967C4.73594 4.2034 5.1526 4.1792 5.44621 4.39705L5.53033 4.46967L12 10.939L18.4697 4.46967C18.7626 4.17678 19.2374 4.17678 19.5303 4.46967C19.8232 4.76256 19.8232 5.23744 19.5303 5.53033L13.061 12L19.5303 18.4697C19.7966 18.7359 19.8208 19.1526 19.6029 19.4462L19.5303 19.5303C19.2641 19.7966 18.8474 19.8208 18.5538 19.6029L18.4697 19.5303L12 13.061L5.53033 19.5303C5.23744 19.8232 4.76256 19.8232 4.46967 19.5303C4.17678 19.2374 4.17678 18.7626 4.46967 18.4697L10.939 12L4.46967 5.53033C4.2034 5.26406 4.1792 4.8474 4.39705 4.55379L4.46967 4.46967L4.39705 4.55379Z" fill="currentColor"/>
                    </svg>
                    `,
            warning: `
                    <svg class="text-warning" width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                        <path d="M16 6C21.523 6 26 10.478 26 16C26 21.522 21.523 26 16 26C10.477 26 6 21.522 6 16C6 10.478 10.477 6 16 6ZM16 7.667C11.405 7.667 7.667 11.405 7.667 16C7.667 20.595 11.405 24.333 16 24.333C20.595 24.333 24.333 20.595 24.333 16C24.333 11.405 20.595 7.667 16 7.667ZM15.9987 18.5022C16.5502 18.5022 16.9973 18.9494 16.9973 19.5009C16.9973 20.0524 16.5502 20.4996 15.9987 20.4996C15.4471 20.4996 15 20.0524 15 19.5009C15 18.9494 15.4471 18.5022 15.9987 18.5022ZM15.9945 11C16.3742 10.9997 16.6882 11.2816 16.7381 11.6476L16.7451 11.7494L16.7487 16.251C16.749 16.6652 16.4135 17.0013 15.9993 17.0016C15.6196 17.0019 15.3055 16.72 15.2556 16.354L15.2487 16.2522L15.2451 11.7506C15.2447 11.3364 15.5802 11.0003 15.9945 11Z" fill="currentColor"/>
                    </svg>
                    `,
        };
        const element = BX.create('div', {
            props: {
                className: 'top-message d-flex gap-3 flex-column'
            },
            events: {
                click: (event) => {
                    if (event.target.tagName.toUpperCase() === 'A') {
                        event.stopPropagation();
                    }
                }
            },
            children: [
                BX.create('div', {
                    props: {className: 'd-flex gap-3'},
                    html: `
                        <div class="flex-shrink-0">${icons[options.icon]}</div>
                        <div class="top-message-content d-flex flex-column justify-content-center">
                            <span class="fw-medium">${message}</span>
                        </div>
                    `
                }),
                (options.subMessage ? BX.create('div', {
                    html: options.subMessage
                }) : null),
            ],
        });

        document.body.appendChild(element);

        const topOffset = this.isTablet() ? 70 : 163;
        const animation = element.animate([
            {
                transform: "translateX(-50%) translateY(0px)",
                opacity: 0
            },
            {
                transform: `translateX(-50%) translateY(${topOffset}px)`,
                opacity: 1
            }
        ], {
            duration: options.durationShow,
            easing: 'cubic-bezier(0.33, 1, 0.68, 1)' // ease out cubic
        });

        animation.onfinish = () => {
            element.style.top = `${topOffset}px`;
            options.onShow && options.onShow(element);

            element.addEventListener('click', () => {
                this.hideMessage({
                    element,
                    duration: options.durationHide,
                    callback: options.onHide
                });
            });

            setTimeout(() => {
                this.hideMessage({
                    element,
                    duration: options.durationHide,
                    callback: options.onHide
                });
            }, options.durationVisible);
        };
    },

    /**
     * @param {Object} [options]
     * @param {HTMLElement} [options.element]
     * @param {number} [options.duration]
     * @param {Function} [options.callback]
     */
    hideMessage: function (options) {
        if (!options.element) {
            const element = document.querySelector('.top-message');

            if (!element) {
                return false;
            }

            options.element = element;
        }

        const animation = options.element.animate([
            {
                opacity: 1
            },
            {
                opacity: 0
            }
        ], {
            duration: options.duration,
            easing: 'cubic-bezier(0.33, 1, 0.68, 1)' // ease out cubic
        });

        animation.onfinish = () => {
            options.callback && options.callback(element);
            options.element.remove();
        }
    },

    /**
     * @param {SweetAlertOptions} options
     * @see https://sweetalert2.github.io/ SweetAlert docs for the list of options
     * @returns Promise<[Promise<{isConfirmed: boolean, isDenied: boolean, isDismissed: boolean, dismiss: Swal.DismissReason.cancel}>|MixinSwal]>
     */
    showPopup: async function (options) {
        BX.closeWait();

        if (!window.Swal) {
            try {
                await BX.loadExt('sotbit.b2c.sweetalert2');
            } catch {
                console.error('SweetAlert2 extension is not loaded!');
            }
        }

        const centerTitle = options.centerTitle === true;
        const fixBodyScroll = options.fixBodyScroll !== false;
        // to disable SweelAlert2 "Unknown parameter" message
        delete options.centerTitle;
        delete options.fixBodyScroll;

        const popupOptions = {
            showCloseButton: true,
            width: '464px',
            showClass: {
                popup: `
                  animate__animated
                  animate__fadeIn
                  animate__faster
                `
            },
            hideClass: {
                popup: `
                  animate__animated
                  animate__fadeOut
                  animate__faster
                `
            },
            closeButtonHtml: `
                <svg width="24" height="24">
                    <use xlink:href="${BX.Sotbit.B2C.templatePath}/assets/image/sprite.svg#close"></use>
                </svg>
                `,
            heightAuto: false,
            scrollbarPadding: false,
            focusConfirm: false,
            confirmButtonText: BX.message('SWEETALERT2_CONFIRM_BUTTON_TEXT'),
            denyButtonText: BX.message('SWEETALERT2_DENY_BUTTON_TEXT'),
            cancelButtonText: BX.message('SWEETALERT2_CANCEL_BUTTON_TEXT'),
            closeButtonAriaLabel: BX.message('SWEETALERT2_CLOSE_BUTTON_ARIA_LABEL'),
            ...options,
            didOpen: (popup) => {
                if (fixBodyScroll) {
                    this.fixBodyScroll();
                }
                options.didOpen && options.didOpen(popup);
            },
            didDestroy: () => {
                if (fixBodyScroll) {
                    this.unfixBodyScroll();
                }

                options.didDestroy && options.didDestroy();
            },
        };

        const defaultCustomClass = {
            title: centerTitle ? 'center' : '',
            htmlContainer: 'custom-scrollbar',
        }

        if (popupOptions.customClass) {
            for (const key in defaultCustomClass) {
                if (defaultCustomClass.hasOwnProperty(key)) {
                    popupOptions.customClass[key] = `${popupOptions.customClass[key]} ${defaultCustomClass[key]}`;
                }
            }
        } else {
            popupOptions.customClass = defaultCustomClass;
        }

        /** @var {MixinSwal} popup */
        const popup = Swal.mixin(popupOptions);

        return [popup.fire(), popup];
    },

    /**
     * @param {string} formCode
     * @param {Object} [options]
     * @param {Object} popupOptions
     * @returns {Promise<[Object, MixinSwal]>}
     */
    showForm: function (formCode, options = {}, popupOptions = {}) {
        options = {
            SITE_ID: BX.message('SITE_ID'),
            COMPONENT_TEMPLATE: 'popup',
            ...options
        }

        BX.showWait();

        return BX.ajax.runAction('sotbit:b2c.form.get', {
            data: {
                formCode,
                options
            }
        }).then((result) => {
            BX.closeWait();

            const title = result.data.html.match(/data-title="(.*)"/)?.[1];

            return this.showPopup({
                title: title || BX.message('WEB_FORM_DEFAULT_TITLE'),
                html: result.data.html,
                showCancelButton: false,
                showConfirmButton: false,
                customClass: {
                    container: 'popup-form',
                    htmlContainer: 'custom-scrollbar'
                },
                didOpen: (modalElement) => {
                    // execute scripts from the received template
                    modalElement.querySelectorAll('#swal2-html-container script').forEach(script => {
                        try {
                            /** @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/eval */
                            eval?.(`${script.text}`);
                        } catch (error) {
                            console.warn(error);
                        }
                    });
                },
                ...popupOptions
            });
        }).catch((result) => {
            BX.closeWait();

            console.error(result.errors);
        });
    },

    /**
     * @param {HTMLFormElement} form
     * @return {boolean|Promise}
     */
    submitForm: function (form) {
        if (!form.reportValidity()) {
            return new Promise((res, rej) => {
                rej({});
            });
        }

        BX.onCustomEvent('sotbit:b2c.submit');

        return BX.ajax.runAction('sotbit:b2c.form.addAnswer', {
            data: new FormData(form)
        });
    },

    showOneClick: function (options = {}, template = '.default', popupOptions = {}) {
        options = {
            SITE_ID: BX.message('SITE_ID'),
            COMPONENT_TEMPLATE: template,
            ...options
        }

        BX.showWait();

        return BX.ajax.runAction('sotbit:b2c.order.getOneClick', {
            data: {
                options
            }
        }).then((result) => {
            BX.closeWait();
            const title = result.data.html.match(/data-title="(.*)"/)?.[1];
            return this.showPopup({
                title: title || BX.message('ONE_CLICK_DEFAULT_TITLE'),
                html: result.data.html,
                showCancelButton: false,
                showConfirmButton: false,
                customClass: {
                    container: 'popup-form one-click-form'
                },
                didOpen: (modalElement) => {
                    // execute scripts from the received template
                    modalElement.querySelectorAll('#swal2-html-container script').forEach(script => {
                        try {
                            /** @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/eval */
                            eval?.(`${script.text}`);
                        } catch (error) {
                            console.warn(error);
                        }
                    });
                },
                ...popupOptions
            });
        }).catch((result) => {
            BX.closeWait();
            console.error(result.errors);
        });
    },

    /**
     * @param {string} src
     * @param {string} alt
     * @param {Object} [attributes]
     * @param {string} [loaderSrc]
     * @returns {HTMLElement}
     */
    loadLazy: function (src, alt, attributes, containerAttributes) {
        const id = 'img_lazy_' + BX.util.getRandomString(16);
        const imageOptions = {
            props: {
                id,
                alt,
                src: '/'
            },
            dataset: {
                src
            }
        };

        for (const name in attributes) {
            if (name.startsWith('data-')) {
                // normalize data-attributes names, e.g. data-test-attribute -> testAttribute
                const dataAttributeName = name.slice(5).replace(/-./g, x => x[1].toUpperCase());

                if (attributes[name]) {
                    imageOptions.dataset[dataAttributeName] = attributes[name];
                }
            } else {
                imageOptions.props[name] = attributes[name];
            }
        }

        const containerOptions = {
            props: {}
        };

        for (const name in containerAttributes) {
            if (name.startsWith('data-')) {
                const dataAttributeName = name.slice(5).replace(/-./g, x => x[1].toUpperCase());

                if (attributes[name]) {
                    containerOptions.dataset[dataAttributeName] = attributes[name];
                }
            } else {
                containerOptions.props[name] = attributes[name];
            }
        }

        queueMicrotask(() => BX.LazyLoad.registerImage(id, (image) => {
            image.node.parentElement.querySelector('[data-loader]').remove();
            image.node.parentElement.dataset.lazyLoad = 'true';
        }));

        return BX.create('div', {
            props: {
                className: `lazy-loader ${containerAttributes?.className || ''}`,
            },
            dataset: {
                lazyLoad: 'false'
            },
            children: [
                BX.create('img', imageOptions),
                BX.Sotbit.B2C.loaderSvg
            ]
        });
    },

    /**
     * @param {HTMLInputElement} inputElement
     */
    createPhoneNumberSelect(inputElement) {
        if (!BX.PhoneNumber) {
            throw new Error('Bitrix "phone_number" extension is not loaded!');
        }

        const countrySelectElement = BX.create('div', {
            props: {
                className: 'input-flags'
            },
            children: [
                BX.create('button', {})
            ]
        });

        // wrap
        const inputContainer = inputElement.parentElement;
        const wrapperElement = BX.create('span', {
            style: {
                position: 'relative',
                display: 'block'
            }
        });

        inputContainer.insertBefore(wrapperElement, inputElement);
        wrapperElement.appendChild(countrySelectElement);
        wrapperElement.appendChild(inputElement);
    },

    /**
     * @param {HTMLElement} selectElement
     *
     * Config must be in JSON format and can be passed like this:
     * <code><select data-choices='{"key": "value"}'>...</select></code>
     */
    createCustomSelect: function (selectElement) {
        let config = {
            noChoicesText: BX.message('CHOICES_NO_CHOICES_TEXT'),
            noResultsText: BX.message('CHOICES_NO_RESULTS_TEXT'),
            removeItemButton: true,
            searchEnabled: false,
            classNames: {
                list: ['choices__list', 'custom-scrollbar']
            }
        };

        if (selectElement.dataset.choices) {
            config = {...config, ...JSON.parse(selectElement.dataset.choices)};
        }

        /** @see https://codesandbox.io/p/sandbox/choices-js-dropdown-95t9jy?file=%2Findex.html%3A35%2C18 */
        const handleShowDropdown = (choicesInstance) => {
            debugger;

            const closeDropdownOnScroll = (event) => {
                if (!event.target?.closest?.('.choices__list')) {
                    choicesInstance.hideDropdown();
                    choicesInstance.dropdown.element.removeAttribute('style');
                }
                document.removeEventListener('scroll', closeDropdownOnScroll, true);
            };

            const containerOuter = choicesInstance.containerOuter.element;
            const dropdown = choicesInstance.dropdown.element;

            dropdown.style.position = "fixed";

            const containingBlock = BX.Sotbit.B2C.getContainingBlock(dropdown) || document.documentRoot;
            const containingBlockBoundingClientRect = containingBlock.getBoundingClientRect();
            const containerOuterBoundingClientRect = containerOuter.getBoundingClientRect();

            dropdown.style.left = `${containerOuterBoundingClientRect.left - containingBlockBoundingClientRect.left}px`;
            dropdown.style.width = `${containerOuter.offsetWidth}px`;

            if (containerOuter.classList.contains('is-flipped')) {
                dropdown.style.bottom = `${Math.min(containingBlockBoundingClientRect.bottom, window.innerHeight) - containerOuterBoundingClientRect.top + 1}px`;
            } else {
                dropdown.style.top = `${containerOuterBoundingClientRect.top + Math.max(0, containingBlockBoundingClientRect.top) + containerOuter.offsetHeight}px`;
            }

            document.addEventListener('scroll', closeDropdownOnScroll, true);
        }

        const choicesInstance = new Choices(selectElement, config);

        choicesInstance.passedElement.element.addEventListener('showDropdown', () => handleShowDropdown(choicesInstance));
    },

    /**
     * @param {HTMLElement} element
     * @returns {HTMLElement | null}
     *
     * Get containing block for parameter element
     * @see https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block
     * @see https://github.com/zakplus/containing-block
     */
    getContainingBlock: function (element) {
        if (!element) {
            throw new Error('"element" parameter is required');
        }

        if (!(element instanceof Element)) {
            throw new Error('"element" parameter must be a Element instance');
        }

        const elementPosition = window.getComputedStyle(element).position;
        /** @todo list all block container elements https://www.w3.org/TR/CSS2/visuren.html */
        const blockContainerOrFormattingContext = ['block', 'inline-block', 'list-item', 'table', 'flex', 'grid'];

        let parent = element.parentElement;

        switch (elementPosition) {
            case 'static':
            case 'relative':
            case 'sticky':
                while (parent) {
                    const parentDisplayPropertyValue = window.getComputedStyle(parent).display;

                    if (blockContainerOrFormattingContext.includes(parentDisplayPropertyValue)) {
                        return parent;
                    }
                    parent = parent.parentElement;
                }
                break;
            case 'absolute':
                while (parent) {
                    const parentStyle = window.getComputedStyle(parent);
                    const position = parentStyle.position;
                    const transform = parentStyle.transform;
                    const filter = parentStyle.filter;
                    const willChange = parentStyle.willChange;

                    if (
                        position !== 'static'
                        || transform !== 'none'
                        || willChange === 'transform'
                        || willChange === 'perspective'
                        || willChange === 'filter'
                        || filter !== 'none'
                    ) {
                        return parent;
                    }

                    parent = parent.parentElement;
                }
                break;
            case 'fixed':
                while (parent) {
                    const parentStyle = window.getComputedStyle(parent);
                    const transform = parentStyle.transform;
                    const filter = parentStyle.filter;
                    const willChange = parentStyle.willChange;

                    if (
                        transform !== 'none'
                        || willChange === 'transform'
                        || willChange === 'perspective'
                        || willChange === 'filter'
                        || filter !== 'none'
                    ) {
                        return parent;
                    }

                    parent = parent.parentElement;
                }

                return document.documentElement;
            default:
                return null;
        }
    },

    isCaptchaReloading: false,

    /**
     * @param {string} captchaInputId
     */
    reloadCaptcha(captchaInputId) {
        if (this.isCaptchaReloading) {
            return;
        }

        this.isCaptchaReloading = true;

        BX.ajax.runAction('sotbit:b2c.captcha.reload').then((result) => {
            if (result.status === 'success') {
                const captchaHiddenInput = document.getElementById(captchaInputId);

                if (captchaHiddenInput) {
                    const captchaCodeOld = captchaHiddenInput.value;
                    const captchaCodeNew = result.data;

                    captchaHiddenInput.value = captchaCodeNew;

                    const captchaImageElement = document.querySelector(`img[src="/bitrix/tools/captcha.php?captcha_sid=${captchaCodeOld}"]`);

                    if (captchaImageElement) {
                        captchaImageElement.src = `/bitrix/tools/captcha.php?captcha_sid=${captchaCodeNew}`;
                    }
                }
            } else {
                console.error(result);
            }

            this.isCaptchaReloading = false;
        }).catch(() => this.isCaptchaReloading = false);
    },

    /**
     * @param {HTMLElement | function(): HTMLElement | string} element
     * @param {Object} options
     * @returns {Object}
     */
    createSlider: function (element, options = {}, library = 'Swiper') {
        if (!element) {
            throw new Error('"element" parameter is required');
        } else {
            switch (typeof element) {
                case "string":
                    const query = element;
                    element = document.querySelector(query);

                    if (!element) {
                        throw new Error(`Element not found: "${query}"`);
                    }
                    break;
                case "function":
                    element = element();

                    if (!(element instanceof Element)) {
                        throw new Error("Function return value is not an Element");
                    }
                    break;
                case "object":
                    if (!(element instanceof Element)) {
                        throw new Error('"element" parameter is not an Element');
                    }
                    break;
            }
        }

        switch (library) {
            case 'KeenSlider':
                const addSlidesDataIndex = (slider) => slider.slides.forEach((_, index) => slider.slides[index].dataset.slideIndex = index);

                /** @see https://keen-slider.io/ */
                const defaultOptions = {
                    renderMode: 'performance',
                    drag: true,
                    rubberband: false,
                    created: (slider) => {
                        addSlidesDataIndex(slider);

                        const currentSlideIndex = slider.track.details.rel;

                        slider.container.classList.add('keen-slider--initialized', 'keen-slider--active');
                        slider.slides[currentSlideIndex].classList.add('keen-slider__slide--active');
                        slider.lastIdx = {
                            abs: slider.track.details.abs,
                            rel: slider.track.details.rel
                        }
                    },
                    destroyed: (slider) => {
                        slider.container.classList.remove('keen-slider--active');
                    },
                    optionsChanged: (slider) => {
                        addSlidesDataIndex(slider);
                    },
                    updated: (slider) => {
                        addSlidesDataIndex(slider);
                    },
                    slideChanged: (slider) => {
                        slider.slides.forEach((slide) => slide.classList.remove('keen-slider__slide--active'));
                        slider.slides[slider.track.details.rel].classList.add('keen-slider__slide--active');
                    },
                    animationStarted: (slider) => {
                        slider.container.classList.add('keen-slider--animation-active');

                        slider.lastIdx = {
                            abs: slider.track.details.abs,
                            rel: slider.track.details.rel
                        };
                    },
                    animationEnded: (slider) => {
                        slider.container.classList.remove('keen-slider--animation-active');
                    },
                    animationStopped: (slider) => {
                        slider.container.classList.remove('keen-slider--animation-active');
                    }
                };

                const plugins = [];

                if (options.arrows && (options.arrows === true || options.arrows.enabled === true)) {
                    const arrows = (slider) => {
                        let arrowsElements = [];
                        let customElements = false;

                        if (options.arrows.elements?.prev && options.arrows.elements?.next) {
                            arrowsElements = [options.arrows.elements.prev, options.arrows.elements.next]
                            customElements = true;
                        } else {
                            arrowsElements = slider.container.parentElement.querySelectorAll('.keen-slider__arrow');
                        }

                        const updateArrowsState = (slider) => {
                            if (Number.isNaN(slider.track.details.progress)) {
                                slider.arrows.prev.setAttribute('disabled', 'disabled');
                                slider.arrows.next.setAttribute('disabled', 'disabled');
                                return;
                            }

                            if (!slider.options.loop) {
                                const currentSlideIndex = slider.track.details.rel;

                                currentSlideIndex === 0
                                    ? slider.arrows.prev.setAttribute('disabled', 'disabled')
                                    : slider.arrows.prev.removeAttribute('disabled');
                                currentSlideIndex === slider.track.details.maxIdx
                                    ? slider.arrows.next.setAttribute('disabled', 'disabled')
                                    : slider.arrows.next.removeAttribute('disabled');
                            }
                        }

                        slider.on('created', (slider) => {
                            slider.arrows = {};

                            if (customElements) {
                                slider.arrows.prev = options.arrows.elements.prev;
                                slider.arrows.next = options.arrows.elements.next;
                                slider.arrows.prev.addEventListener('click', () => {
                                    slider.prev();
                                    slider.emit('afterSlideChangedPrev');
                                });
                                slider.arrows.next.addEventListener('click', () => {
                                    slider.next();
                                    slider.emit('afterSlideChangedNext');
                                });
                            } else {
                                arrowsElements.forEach((arrow) => {
                                    const isNext = arrow.classList.contains('keen-slider__arrow--next');

                                    arrow.innerHTML = `
                                        <svg width="24" height="24">
                                            <use xlink:href="${BX.Sotbit.B2C.templatePath}/assets/image/sprite.svg#chevron"></use>
                                        </svg>
                                    `;

                                    isNext ? slider.arrows.next = arrow : slider.arrows.prev = arrow;

                                    arrow.addEventListener('click', isNext ? slider.next : slider.prev);
                                });
                            }

                            if (!slider.options.loop) {
                                slider.arrows.prev.setAttribute('disabled', 'disabled')
                            }

                            updateArrowsState(slider);
                        });

                        slider.on('optionsChanged', (slider) => updateArrowsState(slider));
                        slider.on('slideChanged', (slider) => updateArrowsState(slider));
                        slider.on('updated', (slider) => updateArrowsState(slider));
                    };

                    plugins.push(arrows);
                }

                if (options.pagination && (options.pagination === true || options.pagination.enabled === true)) {
                    const pagination = (slider) => {
                        const paginationContainer = options.pagination.element
                            || slider.container.parentElement.querySelector('.keen-slider__pagination');

                        let paginationInner, dotOffset, dotGap, dotWidth;

                        const updatePagination = (slider) => {
                            const slide = slider.track.details.rel;

                            [...paginationInner.children].forEach((dot, index) => {
                                    let style = `transform: translateX(${dotOffset * slide}px)`;

                                    dot.classList = 'keen-slider__dot';

                                    if (index === slide) {
                                        dot.classList.add('keen-slider__dot--active');
                                        style += ' scale(1)';
                                    } else if (index === slide - 1 || index === slide + 1) {
                                        style += ' scale(0.66)';
                                    } else if (index === slide - 2 || index === slide + 2) {
                                        style += ' scale(0.33)';
                                    } else {
                                        style += ' scale(0)';
                                    }

                                    dot.setAttribute('style', style);
                                }
                            );
                        }

                        const createPagination = (slider) => {
                            if (!paginationContainer || slider.track?.details?.slides.length < 2) {
                                return slider.pagination = false;
                            }

                            paginationInner = document.createElement('div');
                            paginationInner.className = 'keen-slider__pagination-inner';
                            paginationContainer.appendChild(paginationInner);

                            slider.track?.details?.slides?.forEach((_, index) => {
                                const dot = document.createElement('button');
                                dot.classList.add('keen-slider__dot');

                                if (!dotGap) {
                                    dotGap = parseFloat(
                                        window.getComputedStyle(paginationInner).getPropertyValue('--gap')
                                    );
                                }

                                if (index === 0) {
                                    dot.classList.add('keen-slider__dot--active');
                                }

                                dot.addEventListener("click", () => slider.moveToIdx(index))
                                paginationInner.appendChild(dot);

                                if (!dotWidth) {
                                    dotWidth = dot.offsetWidth;
                                }

                                if (!dotOffset) {
                                    dotOffset = (dotWidth + dotGap) * -1;
                                }

                                slider.emit('slideChangedPagination');
                            });

                            slider.pagination = {
                                element: paginationContainer
                            };

                            updatePagination(slider);
                        }

                        slider.on('created', (slider) => createPagination(slider));
                        slider.on('slideChanged', (slider) => updatePagination(slider));
                        slider.on('optionsChanged', (slider) => {
                            BX.ready(() => {
                                queueMicrotask(() => {
                                    paginationContainer.replaceChildren();
                                    createPagination(slider);
                                });
                            });
                        });
                        slider.on('destroyed', () => paginationContainer.replaceChildren());
                    };

                    plugins.push(pagination);
                }

                if (options.autoplay && (options.autoplay === true || options.autoplay.enabled === true)) {
                    const autoplay = (slider) => {
                        let timeout;
                        let mouseOver = false;

                        function clearNextTimeout() {
                            clearTimeout(timeout);
                        }

                        function nextTimeout() {
                            clearTimeout(timeout);

                            if (mouseOver) {
                                return;
                            }

                            timeout = setTimeout(() => {
                                slider.next();
                            }, slider.options.autoplay.interval || 3000);
                        }

                        slider.on("created", () => {
                            slider.container.addEventListener("mouseover", () => {
                                mouseOver = true;
                                clearNextTimeout();
                            });
                            slider.container.addEventListener("mouseout", () => {
                                mouseOver = false;
                                nextTimeout();
                            })
                            nextTimeout();
                        });
                        slider.on("dragStarted", clearNextTimeout);
                        slider.on("animationEnded", nextTimeout);
                        slider.on("updated", nextTimeout);
                    };

                    plugins.push(autoplay);
                }

                if (Array.isArray(options.plugins)) {
                    options.plugins.forEach((plugin) => {
                        plugins.push(plugin);
                    });
                }

                return window.KeenSlider && new KeenSlider(element, {...defaultOptions, ...options}, plugins);
            default:
                return window.Swiper && new Swiper(element, options);
        }
    },

    initIconEyePassword(container = document.body) {
        container.querySelectorAll('input[type="password"]').forEach((input) => {
            const revealButton = BX.create('button', {
                props: {
                    className: 'input-password-toggle text-secondary-500',
                    type: 'button'
                },
                html: `
                    <svg class="input-password-icon" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12.0004 9.00462C14.2095 9.00462 16.0004 10.7955 16.0004 13.0046C16.0004 15.2138 14.2095 17.0046 12.0004 17.0046C9.79122 17.0046 8.00036 15.2138 8.00036 13.0046C8.00036 10.7955 9.79122 9.00462 12.0004 9.00462ZM12.0004 10.5046C10.6196 10.5046 9.50036 11.6239 9.50036 13.0046C9.50036 14.3853 10.6196 15.5046 12.0004 15.5046C13.3811 15.5046 14.5004 14.3853 14.5004 13.0046C14.5004 11.6239 13.3811 10.5046 12.0004 10.5046ZM12.0004 5.5C16.6139 5.5 20.5965 8.65001 21.7015 13.0644C21.8021 13.4662 21.5579 13.8735 21.1561 13.9741C20.7542 14.0746 20.347 13.8305 20.2464 13.4286C19.3075 9.67796 15.9217 7 12.0004 7C8.07729 7 4.69046 9.68026 3.75322 13.4332C3.65286 13.835 3.24572 14.0794 2.84385 13.9791C2.44197 13.8787 2.19755 13.4716 2.29792 13.0697C3.40101 8.65272 7.38484 5.5 12.0004 5.5Z" fill="currentColor"/>
                    </svg>
                    <svg class="input-password-icon d-none" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.21967 2.21967C1.9534 2.48594 1.9292 2.9026 2.14705 3.19621L2.21967 3.28033L6.25424 7.3149C4.33225 8.66437 2.89577 10.6799 2.29888 13.0644C2.1983 13.4662 2.4425 13.8735 2.84431 13.9741C3.24613 14.0746 3.6534 13.8305 3.75399 13.4286C4.28346 11.3135 5.59112 9.53947 7.33416 8.39452L9.14379 10.2043C8.43628 10.9258 8 11.9143 8 13.0046C8 15.2138 9.79086 17.0046 12 17.0046C13.0904 17.0046 14.0788 16.5683 14.8004 15.8608L20.7197 21.7803C21.0126 22.0732 21.4874 22.0732 21.7803 21.7803C22.0466 21.5141 22.0708 21.0974 21.8529 20.8038L21.7803 20.7197L15.6668 14.6055L15.668 14.604L14.4679 13.4061L11.598 10.5368L11.6 10.536L8.71877 7.65782L8.72 7.656L7.58672 6.52549L3.28033 2.21967C2.98744 1.92678 2.51256 1.92678 2.21967 2.21967ZM10.2041 11.2655L13.7392 14.8006C13.2892 15.2364 12.6759 15.5046 12 15.5046C10.6193 15.5046 9.5 14.3853 9.5 13.0046C9.5 12.3287 9.76824 11.7154 10.2041 11.2655ZM12 5.5C10.9997 5.5 10.0291 5.64807 9.11109 5.925L10.3481 7.16119C10.8839 7.05532 11.4364 7 12 7C15.9231 7 19.3099 9.68026 20.2471 13.4332C20.3475 13.835 20.7546 14.0794 21.1565 13.9791C21.5584 13.8787 21.8028 13.4716 21.7024 13.0697C20.5994 8.65272 16.6155 5.5 12 5.5ZM12.1947 9.00928L15.996 12.81C15.8942 10.7531 14.2472 9.10764 12.1947 9.00928Z" fill="currentColor"/>
                    </svg>
                `,
                events: {
                    click: function () {
                        /**
                         * @this {HTMLButtonElement}
                         */
                        const [showIcon, hideIcon] = this.children;

                        if (!showIcon.classList.contains('d-none')) {   // if password is hidden - show
                            showIcon.classList.add('d-none');
                            hideIcon.classList.remove('d-none');
                            input.type = 'text'
                        } else {                                        // if password is shown - hide
                            showIcon.classList.remove('d-none');
                            hideIcon.classList.add('d-none');
                            input.type = 'password';
                        }
                    }
                }
            });
            const inputContainer = input.parentElement;
            const wrapperElement = BX.create('span', {
                style: {
                    position: 'relative',
                    display: 'block'
                }
            });

            inputContainer.insertBefore(wrapperElement, input);
            wrapperElement.appendChild(input);

            const inputStyle = window.getComputedStyle(input);
            let inputHeight = input.offsetHeight;

            inputHeight += (parseInt(inputStyle.marginTop) + parseInt(inputStyle.marginBottom));
            input.style.width = '100%';
            revealButton.style.bottom = `${Math.round(inputHeight / 2)}px`;

            wrapperElement.appendChild(revealButton);
        });
    },

    isDesktop() {
        return window.matchMedia('(min-width: 1440px)').matches;
    },

    isLaptop() {
        return window.matchMedia('(max-width: 1024px)').matches;
    },

    isTablet() {
        return window.matchMedia('(max-width: 768px)').matches;
    },

    isMobile() {
        return window.matchMedia('(max-width: 576px)').matches;
    },

    isWaiting: false
};

/* override standard loader */
BX.showWait = function () {
    if (BX.Sotbit.B2C.isWaiting) {
        return;
    }

    BX.Sotbit.B2C.isWaiting = true;
    BX.Sotbit.B2C.fixBodyScroll();

    const loader = BX.create('div', {
        props: {
            id: 'sotbit-b2c-loader',
            className: 'page-loader'
        },
        events: {
            click: () => false
        },
        html: `
            <div class="page-loader-image">
                ${BX.Sotbit.B2C.loaderSvg}
            </div>
        `
    });

    document.body.appendChild(loader);
};

BX.closeWait = function () {
    if (!BX.Sotbit.B2C.isWaiting) {
        return;
    }

    BX.Sotbit.B2C.isWaiting = false;

    document.getElementById('sotbit-b2c-loader')?.remove();
    BX.Sotbit.B2C.unfixBodyScroll();
};

BX.ready(function () {
    const setScrollbarWidth = () => document.documentElement.style
        .setProperty('--body-scrollbar-width', `${window.innerWidth - document.body.offsetWidth}px`);

    document.addEventListener('mousemove', () => setScrollbarWidth(), {once: true});
    window.addEventListener('resize', () => setScrollbarWidth());

    // lazy-load
    const lazyLoadDataAttribute = 'data-lazy-load';

    BX.LazyLoad.imageTypes.picture = 3;

    BX.LazyLoad.showImage = function (imageNode) {
        const imageNodeId = imageNode.id;

        if (!BX.Type.isStringFilled(imageNodeId)) {
            return;
        }

        const image = this.images[imageNodeId];

        if (!BX.Type.isPlainObject(image)) {
            return;
        }

        if (image.status === this.imageStatus.undefined) {
            this.initImage(image);
        }

        if (image.status !== this.imageStatus.inited) {
            return;
        }

        if (!image.node || !image.node.parentNode) {
            image.node = null;
            image.status = this.imageStatus.error;
            return;
        }

        let useSources = false;

        switch (image.type) {
            case this.imageTypes.image:
                image.node.src = image.src;

                if (image.node.dataset.defaultSource !== undefined) {
                    useSources = true;
                }
                break;
            default:
                image.node.style.backgroundImage = `url(${image.src})`;
        }

        if (image.type === this.imageTypes.image) {
            if (useSources) {
                const sources = image.node.parentElement.querySelectorAll('source');

                sources.forEach((source) => {
                    source.setAttribute('srcset', source.dataset.srcset);
                    source.dataset.srcset = '';
                });
            }

            image.node.src = image.src;
        } else {
            image.node.style.backgroundImage = `url(${image.src})`;
        }

        if (BX.Type.isFunction(image.func)) {
            image.func(image);
        }

        image.node.dataset[image.dataSrcName] = '';
        image.status = this.imageStatus.loaded;
    }

    function loadLazy(imageContainer) {
        const image = imageContainer.querySelector('img');
        const loader = imageContainer.querySelector('[data-loader]');

        if (!BX.LazyLoad.observer) {
            BX.LazyLoad.observer = new IntersectionObserver(BX.LazyLoad.onIntersection.bind(BX.LazyLoad), {
                rootMargin: '20% 0% 20% 0%',
                threshold: 0
            });
        }

        BX.LazyLoad.registerImage(image.getAttribute('id'), (image) => {
            image.node.addEventListener('load', () => {
                loader.remove();
                imageContainer.setAttribute(lazyLoadDataAttribute, 'true');
            }, {once: true});
        });
    }

    document.querySelectorAll(`[${lazyLoadDataAttribute}="false"]`).forEach((element) => loadLazy(element));

    const observer = new MutationObserver((entries) => {
        entries.forEach((entry) => {
            const parent = entry.target?.parentElement || entry.target;

            parent.querySelectorAll(`[${lazyLoadDataAttribute}="false"]`)
                .forEach((element) => loadLazy(element));
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });

    // manipulations with data-* elements
    document.querySelectorAll(`
        [data-expand],
        [data-choices]
    `).forEach((element) => {
        if (element.dataset.expand !== undefined) {
            const expandableElement = element.nextElementSibling;
            const chevron = element.querySelector('svg');

            element.addEventListener('click', () => {
                if (element.classList.contains('active')) {
                    const expandableElementAnimation = expandableElement.animate([
                            {
                                height: `${BX.Sotbit.B2C.getTotalChildrenHeight(expandableElement)}px`
                            },
                            {
                                height: 0
                            }
                        ],
                        {
                            duration: 300,
                            easing: 'cubic-bezier(0.25, 0.1, 0.25, 1)'
                        }
                    );

                    chevron.animate([
                            {
                                transform: `rotate(90deg)`
                            },
                            {
                                transform: `rotate(-90deg)`
                            }
                        ],
                        {
                            duration: 300,
                            easing: 'cubic-bezier(0.25, 0.1, 0.25, 1)'
                        }
                    );

                    expandableElementAnimation.onfinish = () => element.classList.remove("active");
                } else {
                    const expandableElementAnimation = expandableElement.animate([
                            {
                                height: 0
                            },
                            {
                                height: `${BX.Sotbit.B2C.getTotalChildrenHeight(expandableElement)}px`
                            }
                        ],
                        {
                            duration: 300,
                            easing: 'cubic-bezier(0.25, 0.1, 0.25, 1)'
                        }
                    );

                    chevron.animate([
                            {
                                transform: `rotate(-90deg)`
                            },
                            {
                                transform: `rotate(90deg)`
                            }
                        ],
                        {
                            duration: 300,
                            easing: 'cubic-bezier(0.25, 0.1, 0.25, 1)'
                        }
                    );

                    expandableElementAnimation.onfinish = () => element.classList.add("active");
                }
            });
        }

        if (element.dataset.choices !== undefined) {
            window.Choices && BX.Sotbit.B2C.createCustomSelect(element);
        }
    });

    // eye icon for password inputs
    BX.Sotbit.B2C.initIconEyePassword();

    // go to top button
    const goTopButton = document.querySelector('[data-entity="go-top-btn"]');

    if (goTopButton) {
        goTopButton.addEventListener('click', () => window.scrollTo({top: 0, behavior: 'smooth'}));
        window.addEventListener('scroll', () => {
                if (window.scrollY > window.screen.height) {
                    goTopButton.classList.add('active');
                    goTopButton.setAttribute('aria-hidden', 'false');
                } else {
                    goTopButton.classList.remove('active');
                    goTopButton.setAttribute('aria-hidden', 'true');
                }
            },
            {passive: true}
        );

        document.addEventListener('mousemove', () => {
            if (window.scrollY > window.screen.height) {
                goTopButton.classList.add('active');
                goTopButton.setAttribute('aria-hidden', 'false');
            }
        }, {once: true});
    }

    // install PWA
    let deferredPrompt = null;
    window.addEventListener('beforeinstallprompt', (event) => {
        event.preventDefault();
        deferredPrompt = event;
    });

    const installButtonIOS = document.getElementById('installPwaIos');
    const installButtonAndroid = document.getElementById('installPwaAndroid');

    function checkAfterRedirect() {
        if (window.location.search === '?redirect=true') {
            if (isIOS()) {
                showPopupIos();
            } else {
                window.history.replaceState(null, '', window.location.pathname);
                handlePwaInstall();
            }
        }
    }

    function handlePwaInstall() {
        if (deferredPrompt) {
            deferredPrompt.prompt();
        } else {
            // incompatible browser, your PWA is not passing the criteria, the user has already installed the PWA
            // TODO: show the user information on how to install the app
            alert(BX.message('INSTALLATION_INSTRUCTIONS'));
        }
    }

    checkAfterRedirect();

    document.getElementById('closePopupIos')?.addEventListener('click', hidePopup);

    if (installButtonIOS) {
        if (isMobile()) {
            if (isIOS()) {
                installButtonIOS.addEventListener('click', checkUrl);
            }
        } else {
            installButtonIOS.addEventListener('click', desktopAlert);
        }
    }

    if (installButtonAndroid && !isIOS()) {
        if (isMobile()) {
            installButtonAndroid.addEventListener('click', checkUrl);
        } else {
            installButtonAndroid.addEventListener('click', desktopAlert);
        }
    }

    function desktopAlert() {
        alert(BX.message('INSTALL_APP_AVAILABILITY'));
    }

    function checkUrl() {
        if (window.location.pathname !== '/') {
            window.location.href = '/?redirect=true';
        } else {
            if (isIOS()) {
                showPopupIos();
            } else {
                handlePwaInstall();
            }
        }
    }

    function isIOS() {
        const iOSDevices = [
            'iPad Simulator',
            'iPhone Simulator',
            'iPod Simulator',
            'iPad',
            'iPhone',
            'iPod'
        ];
        return iOSDevices.includes(navigator.platform) ||
            (navigator.userAgent.includes("Mac") && "ontouchend" in document);
    }

    function isMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    function showPopupIos() {
        document.getElementById('popup-PWA-IOS').style.display = 'flex';
    }

    function hidePopup() {
        window.history.replaceState(null, '', window.location.pathname);
        document.getElementById('popup-PWA-IOS').style.display = 'none';
    }
});
