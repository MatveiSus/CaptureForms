<?php

$MESS['WEB_FORM_DEFAULT_TITLE'] = "Веб-форма";
$MESS['ONE_CLICK_DEFAULT_TITLE'] = "Купить в один клик";
$MESS['CLIPBOARD_COPY_SUCCESS'] = "Скопировано";
$MESS['CLIPBOARD_COPY_ERROR'] = "Не удалось скопировать";
