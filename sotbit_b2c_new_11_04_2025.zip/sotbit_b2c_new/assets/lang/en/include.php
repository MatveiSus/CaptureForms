<?php

$MESS["WEB_FORM_DEFAULT_TITLE"] = "Web form";
$MESS['ONE_CLICK_DEFAULT_TITLE'] = "Buy in one click";
$MESS['CLIPBOARD_COPY_SUCCESS'] = "Copied";
$MESS['CLIPBOARD_COPY_ERROR'] = "Failed to copy";
