<?php

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) {
    die();
}

use Bitrix\Main\{Application, Engine\CurrentUser, Localization\Loc, Page\Asset, Page\AssetShowTargetType};
use Sotbit\B2C\{
    Helper\Config,
    Public\Image,
    Seo\OpenGraph,
    Seo\Canonical
};

global $APPLICATION, $USER;

$documentRoot = Application::getDocumentRoot();

if (!(defined("NEED_AUTH") && NEED_AUTH === true && !CurrentUser::get()->getId())) { ?>
    <?php
    if ($APPLICATION->GetProperty('SHOW_SIDEBAR') === 'Y') { ?>
        </section>
        </div>
    <?php
    } ?>
    </main>
<?php
} ?>

<div class="personal personal__placeholder d-none d-lg-block w-100"></div>

<?php
if (!(defined("NEED_AUTH") && NEED_AUTH === true && !CurrentUser::get()->getId())) {
    include($documentRoot . SITE_TEMPLATE_PATH . '/template_layouts/footer/templates/' . (Config::get('FOOTER_VARIANT') ?? 1) . '/template.php');
    include($documentRoot . SITE_TEMPLATE_PATH . '/include/page/localbusiness.php');

    if (OpenGraph::isActive()) {
        OpenGraph::show();
    }

    if (Canonical::isActive()) {
        Canonical::show();
    }
} ?>

<?php
if (Config::get('GO_TO_TOP_BUTTON_POSITION') !== 'NONE') {
    include($documentRoot . SITE_TEMPLATE_PATH . '/include/footer/go_to_top_btn.php');
}

$APPLICATION->ShowBodyScripts();
?>
<?if (strpos($_SERVER['HTTP_HOST'], 'gt-ps.ru') !== false) {
    include(Application::getDocumentRoot() . SITE_TEMPLATE_PATH . '/include/footer/scripts.php'); 
}?>


<?if (strpos($_SERVER['HTTP_HOST'], 'gt-ps.ru') !== false) {?>
   
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "address": {
                "@type": "PostalAddress",
                "addressLocality": "г. Москва",
                "postalCode": "127410",
                "streetAddress": "Алтуфьевское шоссе, д. 31Б"
            },
            "url": "https://gt-ps.ru/",
            "logo": {
                "@type": "ImageObject",
                "url": "/upload/sotbit_b2c/230/pxjevdxzpufwntj3yd8hd673qyjxpkfe/Artboard 1.png",
                "width": "120",
                "height": "52"
            },
            "email": "info@gt-ps.ru",
            "name": "ГидроТехПромСнаб - поставка рукавов из Европы",
            "telephone": "8 (800) 333-85-33"
        }
    </script>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "LocalBusiness",
        "address": {
            "@type": "PostalAddress",
            "addressLocality": "Москва",
            "addressRegion": "Москва",
            "postalCode": "127410" ,
            "streetAddress": "Алтуфьевское шоссе, д. 31Б"
        },
        "name": "ГидротехПромснаб интернет-магазин",
        "email": "info@gt-ps.ru",
        "openingHours": "Mo-Fr 09:00-17:00",
        "priceRange": "1000-10000RUB",
        "currenciesAccepted":  "RUB",
        "paymentAccepted": "Visa, Master Card, Discover, PayPal",
        "telephone": "8 (800) 333-85-33",
        "image": "/upload/sotbit_b2c/230/pxjevdxzpufwntj3yd8hd673qyjxpkfe/Artboard 1.png",
        "logo": "/upload/sotbit_b2c/230/pxjevdxzpufwntj3yd8hd673qyjxpkfe/Artboard 1.png",
        "url": "/"
    }
    </script>  
    <script type="text/javascript">
        BX('request-callback-form3').addEventListener('click', () => {
                BX.Sotbit.B2C.showForm('SIMPLE_FORM_7', {
                    MESSAGES: {
                        SUCCESS: '<span class="fw-bold fs-3">Спасибо!</span><br><span class="fw-medium">Заявка на заказ успешно отправлена!</span>'
                    },
                    DEFAULT_VALUES: {
                        PRODUCT_URL: window.location.href // Добавляем ссылку на текущую страницу в поле PRODUCT_URL
                    }
                });
    });</script>  
    <script>
  $(document).ready(function(){
    $('.footer-menu a').each(function () {
            var location = window.location.href;
            var link = this.href; 
            if(location == link) {
                $(this).addClass('active');
            }
        });
    $('.header-menu-top a').each(function () {
            var location = window.location.href;
            var link = this.href; 
            if(location == link) {
                $(this).addClass('active');
            }
        });
    $('.sidebar a').each(function () {
            var location = window.location.href;
            var link = this.href; 
            if(location == link) {
                $(this).addClass('active');
            }
        });
    });
    </script>

    <script type="text/javascript">
        $( document ).ready(function() {

        if( window.yandex && window.yandex.autofill && $.cookie('yaProfileFalse') != '1' ){
            window.yandex.autofill.getProfileData(['name', 'email', 'phone'])
                .then((result) => {
                    if( result.firstName != '' ){
						if( $('[data-type="name"]').length ){
							 $('[data-type="name"]').val( result.firstName + ' ' + result.lastName );
						}
                        $.cookie('yaName', result.firstName + ' ' +  result.lastName, { expires: 3, path: '/' });
                    }
                    if( result.phoneNumber != '' ){
						if( $('[data-type="phone"]').length ){
							$('[data-type="phone"]').val( result.phoneNumber );
						}
                        $('[data-type="phone"]').parent().addClass('hover');
                        $.cookie('yaPhone', result.phoneNumber, { expires: 3, path: '/' });
                    }
                    if( result.email != '' ){
						if( $('[data-type="email"]').length ){
							 $('[data-type="email"]').val( result.email );
						}
                        $.cookie('yaEmail', result.email, { expires: 3, path: '/' });
                    }
                    $.cookie('yaProfileFalse', '1', { expires: 3, path: '/' });
                },(error) => {
                    $.cookie('yaProfileFalse', '1', { expires: 3, path: '/' });
                });
        };

    }); 
          function getCookie(name) {
            let matches = document.cookie.match(new RegExp(
                "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
            ));
            return matches ? decodeURIComponent(matches[1]) : undefined;
        }
        let mcookie = getCookie("mcookie");
        if (mcookie != "no") {
            setTimeout(function(){
            BX.Sotbit.B2C.showForm('SIMPLE_FORM_8', {
                    MESSAGES: {
                        SUCCESS: '<span class="fw-bold fs-3">Спасибо!</span><br><span class="fw-medium">Заявка на заказ успешно отправлена!</span>'
                    }
                });
                    // записываем cookie на 1 день, с которой мы не показываем окно
                    let date = new Date;
                    date.setDate(date.getDate() + 1);    
                    document.cookie = "mcookie=no; path=/; expires=" + date.toUTCString();       
            }, 60000);
        }

        $('.recommend_s4 .catalog-section__container').slick({
        arrows: true,
        infinite: false,
        speed: 300,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                    dots: true,
                    arrows: false,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    dots: true,
                    arrows: false,
                    slidesToScroll: 1
                }
            }
        ]
    });
        jQuery(function($) {
          /* Detail tabs */
          const ttwTabsListTab = $('.ttw-tabs-list__tab');
          if(ttwTabsListTab !== null && ttwTabsListTab.length) {
            ttwTabsListTab.on('click', function (e) {
              e.preventDefault();
              let thisTargetID = $(this).attr('href');
              $(this).parent().addClass('ttw-tabs-list__item_active');
              $(this).parent().siblings().removeClass('ttw-tabs-list__item_active');
              $(thisTargetID).addClass('ttw-tabs-pane_active').slideDown();
              $(thisTargetID).siblings().removeClass('ttw-tabs-pane_active').slideUp();
            });
          }
          /* Detail tabs END */
        });
    </script>
<?}?>


</body>
</html>
